from gluon import *
from gluon.storage import Storage
import datetime
import fnmatch
import os
import shutil
import traceback
import json
import la_rfparser2
import la_event
import la_utils
from collections import defaultdict


def import_logs(clear_tracks=False, clear_parsed_xml=False, out=None, ignore_force_reload_list=None): # old import_track_records
    #print('--------------------import_logs start------------------------')
    #print('clear_tracks', clear_tracks, 'clear_parsed_xml', clear_parsed_xml, 'out', out)

    ignore_force_reload_list = ignore_force_reload_list or []

    current.cache.ram.clear()

    #r2la_options = current.session.r2la_options
    db = current.db

    if clear_parsed_xml:
        db.parsed_xml.truncate()

    #r2la_options.update_record(last_refresh=datetime.datetime.utcnow())
    r2la_options = db(db.r2la_options.id==1).select().first()

    auto_refresh = db(db.auto_refresh.id==1).select().first()
    auto_refresh.update_record(last_refresh=datetime.datetime.utcnow())

    force_track_records_reload = False
    all_filenames = []
    all_filenames_dict = {}
    for actual_path in r2la_options.paths:
        objects = fnmatch.filter(os.listdir(actual_path), '*.xml')
        all_filenames.extend(objects)
        all_filenames_dict[actual_path] = objects

    removed_parsed_xml_num = db(~db.parsed_xml.file_name.belongs(all_filenames)).delete()
    db(~db.track_record.file_name.belongs(all_filenames)).delete()

    clear_tracks = clear_tracks or bool(removed_parsed_xml_num)
    if clear_tracks:
        db.track.truncate()
        db.track_record.truncate()

    new_file_names_num = 0
    reloaded_files_num = 0
    for actual_path, file_names in all_filenames_dict.items():
        new_file_names = []
        for file_name in file_names:
            
            parsed_xml_exists = db(db.parsed_xml.file_name==file_name).select(db.parsed_xml.faulty,
                                                                              db.parsed_xml.track_name,
                                                                              db.parsed_xml.track_length,
                                                                              db.parsed_xml.most_laps_complited,
                                                                              db.parsed_xml.competitors,
                                                                              db.parsed_xml.player_position,
                                                                              db.parsed_xml.st_size,
                                                                              db.parsed_xml.st_mtime).first()

            if parsed_xml_exists:
                if not parsed_xml_exists.faulty:
                    st = os.stat(os.path.join(actual_path, file_name))
                    if st[6] == parsed_xml_exists.st_size and st[8] == parsed_xml_exists.st_mtime:
                        #print('file NOT cHANGED ', os.path.join(actual_path, file_name))

                        # NOTE: this does not make sense
                        track_in_db = db(db.track.name==parsed_xml_exists.track_name).select().first()
                        if r2la_options.dedi_mode:
                            if not track_in_db:
                                db.track.insert(name=parsed_xml_exists.track_name, length_m=parsed_xml_exists.track_length)
                        else:
                            if not track_in_db and parsed_xml_exists.player_position:
                                db.track.insert(name=parsed_xml_exists.track_name, length_m=parsed_xml_exists.track_length)
                        continue
                    else:
                        #print('FILE CHANGE DETECTED ', os.path.join(actual_path, file_name))
                        db(db.parsed_xml.file_name==file_name).delete()
                        if not clear_tracks and file_name not in ignore_force_reload_list:
                            force_track_records_reload = True
                        reloaded_files_num += 1
                else:
                    db(db.parsed_xml.file_name==file_name).delete()

            try:
                empty_log = None
                with open(os.path.join(actual_path, file_name), 'r', encoding="utf-8") as f:
                    try:
                        opened_file_str = f.read()
                    except UnicodeDecodeError:
                        with open(os.path.join(actual_path, file_name), 'r', encoding="cp1252") as f2:
                            opened_file_str = f2.read()
                info = la_rfparser2.importXML(xml_string=opened_file_str, player_names=[r2la_options.player_name, r2la_options.player_nick])

                if r2la_options.remove_no_drivers and not info['Competitors']:
                    empty_log = file_name
                elif r2la_options.remove_no_laps and not info['most_laps_complited']:
                    empty_log = file_name
                else:
                    st = os.stat(os.path.join(actual_path, file_name))
                    
                    db.parsed_xml.insert(file_name=file_name,
                                        st_size=st[6],
                                        st_mtime=st[8],
                                        infodict=info,
                                        last_update=info['DateTime'],
                                        session_name=info['session'],
                                        competitors=info['Competitors'],
                                        most_laps_complited=info['most_laps_complited'],
                                        rf_server_name=info['ServerName'],
                                        f_t_d=[info['FuelMult'], info['TireMult'], info['DamageMult']],
                                        track_name=info['TrackCourse'],
                                        track_length=info['TrackLength'],
                                        Dedicated=info['Dedicated'],
                                        car_name=info['player_Category'],
                                        player_position=info['player_position'],
                                        player_CarType=info['CarTypeGuess'],
                                        player_CarClass=info['player_CarClass'],
                                        player_TeamName=info['player_TeamName'],
                                        player_Category=info['player_Category'],
                                        weekend_ts=info['weekend_ts'],
                                        session_ts=info['session_ts'],
                                        home_dir=actual_path)

                    track_in_db = db(db.track.name==info['TrackCourse']).select().first()
                    if r2la_options.dedi_mode:
                        if not track_in_db:
                            db.track.insert(name=info['TrackCourse'], length_m=info['TrackLength'])
                    else:
                        if not track_in_db and (info['player_position'] or r2la_options.show_ai_records):
                            db.track.insert(name=info['TrackCourse'], length_m=info['TrackLength'])

                    new_file_names.append(file_name)

                if empty_log:
                    remove_empty_log(actual_path, empty_log)

            except:
                db.parsed_xml.insert(file_name=file_name,
                                     faulty=True,
                                     error_message=traceback.format_exc(),
                                     infodict={},
                                     last_update=creation_datetime(os.path.join(actual_path, file_name)),
                                     weekend_ts=creation_timestamp(os.path.join(actual_path, file_name)),
                                     session_ts=0,
                                     home_dir=actual_path)

        if clear_tracks:
            parsed_xmls = db((db.parsed_xml.id>0) & (db.parsed_xml.faulty==False)).select()
        else:
            parsed_xmls = db((db.parsed_xml.file_name.belongs(new_file_names)) & (db.parsed_xml.faulty==False)).select()

        for parsed_xml_exists in parsed_xmls:
            #print("--------------", parsed_xml_exists.file_name)
            info = parsed_xml_exists.infodict
            xml_date_in_range = True
            if r2la_options.records_after:
                xml_date_in_range = info['DateTime'].date() >= r2la_options.records_after_date
            
            for i in range(1, info['Competitors']+1):
                car_category_in_db = db(db.car_identifier.name==info[i]['Category']+info[i]['CarType']).select().first()
                if not car_category_in_db:
                    #print(info[i]['Category']+info[i]['CarType'], "car_category_in_db =", car_category_in_db)
                    player = info[i]
                    CategoryBool = False
                    CarTypeBool = True
                    CarClassBool = False
                    TeamNameBool = False
                    if player['Category'] in ["ASR Formula OWC 90", "ASR Formula OWC 91", "ASR Formula OWC 92", "ASR Formula OWC 93", "ASR Formula OWC 94", "ASR Formula OWC 95", "ASR Formula OWC 96", "F1RFT 2013", 'Trackday Multiplayer', 'Trackday', 'Hillclimb', 'Custom']:
                        CategoryBool = False
                        CarTypeBool = True
                        CarClassBool = False
                        TeamNameBool = True
                    elif player['Category'] == "Chevrolet":
                        if player['CarType'] == "Corvette ALMS GT2 2009":
                            CategoryBool = True
                            CarTypeBool = False
                            CarClassBool = True
                            TeamNameBool = False
                        elif player['CarType'] == "Corvette C6":
                            CategoryBool = True
                            CarTypeBool = False
                            CarClassBool = False
                            TeamNameBool = True
                        elif player['CarType'] == "Camaro GT3 2012":
                            CategoryBool = True
                            CarTypeBool = False
                            CarClassBool = True
                            TeamNameBool = False
                    elif player['Category'] in ["SkipBarber 2013", "Howston", "Group6", "Group4", "Corvette ALMS GT2 2009", "Caterham 7"]:
                        CategoryBool = False
                        CarTypeBool = False
                        CarClassBool = True
                        TeamNameBool = False
                    elif player['Category'] in ["StockCar"]:
                        CategoryBool = True
                        CarTypeBool = False
                        CarClassBool = False
                        TeamNameBool = False
                    elif player['Category'] in ["A.C. Cars"]:
                        CategoryBool = True
                        CarTypeBool = False
                        CarClassBool = True
                        TeamNameBool = False
                    elif player['Category'] in ["AMGT3"]:
                        #print(player['Category'] in ("AMGT3"))
                        CategoryBool = True
                        CarTypeBool = False
                        CarClassBool = True
                        TeamNameBool = False
                    elif player['Category'] in ["D4", "Nissan", "USF2000"]:
                        CategoryBool = True
                        CarTypeBool = True
                        CarClassBool = False
                        TeamNameBool = False
                    elif player['Category'] in ["Corvette C6"]:
                        CategoryBool = False
                        CarTypeBool = False
                        CarClassBool = False
                        TeamNameBool = True
                    elif player['Category'] == "Honda":
                        if player['CarType'] == "NSX":
                            CategoryBool = True
                            CarTypeBool = False
                            CarClassBool = False
                            TeamNameBool = True
                    elif player['Category'] in ["Endurance Series"]:
                        CategoryBool = False
                        CarTypeBool = True
                        CarClassBool = True
                        TeamNameBool = False
                    db.car_identifier.insert(CarType=player['CarType'],
                                              CarClass=player['CarClass'],
                                              TeamName=player['TeamName'],
                                              Category=player['Category'],
                                              CategoryBool=CategoryBool,
                                              CarTypeBool=CarTypeBool,
                                              CarClassBool=CarClassBool,
                                              TeamNameBool=TeamNameBool,
                                              name=player['Category']+player['CarType'])
                    #print("CategoryBool", CategoryBool, "CarTypeBool", CarTypeBool, "CarClassBool", CarClassBool, "TeamNameBool", TeamNameBool)
                #print('---------------------------------------------')
                this_is_r2la_user = False
                if r2la_options.dedi_mode:
                    create_track_record_bool = info[i]['isPlayer'] and info[i]['FastestLap']
                else:
                    this_is_r2la_user = parsed_xml_exists.player_position and parsed_xml_exists.player_position == i
                    create_track_record_bool = info[i]['FastestLap'] and ((r2la_options.show_ai_records and not info[i]['isPlayer']) or this_is_r2la_user)

                if create_track_record_bool and xml_date_in_range:

                    car_identifier = db(db.car_identifier.name==info[i]['Category']+info[i]['CarType']).select().first()
                    current_car_id = make_car_id_string(car_identifier, [info[i]['Category'], info[i]['CarType'], info[i]['CarClass'], info[i]['TeamName']])

                    track_connected = db(db.tracks_connected.name==info['TrackCourse']).select().first()

                    if track_connected:
                        track = db(db.track.name==track_connected.connected_to).select().first()
                    else:
                        track = db(db.track.name==info['TrackCourse']).select().first()

                    if not track:
                        db.track.insert(name=info['TrackCourse'], length_m=info['TrackLength'])
                        if track_connected:
                            track = db(db.track.name==track_connected.connected_to).select().first()
                        else:
                            track = db(db.track.name==info['TrackCourse']).select().first()

                    parsed_xml_exists.update_record(car_name=current_car_id)

                    record = db((db.track_record.car_str==current_car_id) & \
                                (db.track_record.track_id==track.id) & \
                                (db.track_record.driver_name==info[i]['Name'])).select().first()

                    laps = sum([1 for l in info[i]['drracelaps'] if l])

                    # info[i]['compounds_bylap'][info[i]['fastest_lap_num']-1]
                    #print('i=', i, info[i]['Name'], info[i]['compounds_bylap'], info[i]['fastest_lap_num'], info[i]['FastestLap'])
                    if not record:
                        db.track_record.insert(
                            car_str=current_car_id,
                            track_id=track.id,
                            driver_name=info[i]['Name'],
                            car_id=car_identifier.id,
                            raw_time=info[i]['FastestLap'],
                            date_time=info['DateTime'],
                            file_name=parsed_xml_exists.file_name,
                            rf_server_name=info['ServerName'],
                            CarType=info[i]['CarType'],
                            CarClass=info[i]['CarClass'],
                            TeamName=info[i]['TeamName'],
                            Category=info[i]['Category'],
                            is_ai=not this_is_r2la_user,
                            laps=laps,
                            started_laps=info[i]["Laps"],
                            compounds=info[i]['compounds_bylap'][info[i]['fastest_lap_num']-1],
                            compounds_str=info[i]['compounds_str_bylap'][info[i]['fastest_lap_num']-1],
                            session_index=info['session_index'],
                            fuel=info[i]['racesectors'][info[i]['fastest_lap_num']-1][4]
                        )
                        if this_is_r2la_user:
                            parsed_xml_exists.update_record(is_personal_best=True)

                    elif info[i]['FastestLap'] <= record.raw_time:
                        if this_is_r2la_user:
                            old_parsed_xml = db(db.parsed_xml.file_name==record.file_name).select().first()
                            old_parsed_xml.update_record(is_personal_best=False)
                            parsed_xml_exists.update_record(is_personal_best=True)

                        record.update_record(
                            car_id=car_identifier.id,
                            raw_time=info[i]['FastestLap'],
                            date_time=info['DateTime'],
                            file_name=parsed_xml_exists.file_name,
                            rf_server_name=info['ServerName'],
                            CarType=info[i]['CarType'],
                            CarClass=info[i]['CarClass'],
                            TeamName=info[i]['TeamName'],
                            Category=info[i]['Category'],
                            is_ai=not this_is_r2la_user,
                            laps=record.laps+laps,
                            started_laps=record.started_laps+info[i]["Laps"],
                            compounds=info[i]['compounds_bylap'][info[i]['fastest_lap_num']-1],
                            compounds_str=info[i]['compounds_str_bylap'][info[i]['fastest_lap_num']-1],
                            session_index=info['session_index'],
                            fuel=info[i]['racesectors'][info[i]['fastest_lap_num']-1][4]
                        )
                    else:
                        record.update_record(
                            laps=record.laps+laps,
                            started_laps=record.started_laps+info[i]["Laps"],
                        )

                    if this_is_r2la_user:
                        track.laps = track.laps + laps #sum([1 for l in info[i]['drracelaps'] if l]) #player['Laps']
                        track.driving_time = track.driving_time + sum(info[i]['drracelaps'])

                        #hotlaps = db(db.hotlaps.Category==info[i]['Category']).select(db.hotlaps.id)
                        #if hotlaps:
                        #    db(db.hotlaps.Category==info[i]['Category']).update(last_update=info['DateTime'])

                    if info['DateTime'] > track.last_update:
                        track.last_update = info['DateTime']
                        track.update_record()

        new_file_names_num += len(new_file_names)

    # Redults Viewer filter cache for form select
    track_names = [t.name for t in db(db.track.id>0).select(db.track.name, orderby=db.track.name)]
    names_rows = db(db.track_record.id>0).select(db.track_record.CarClass)
    CarClass_names = sorted(list({n.CarClass for n in names_rows}))

    db.filter_cache.truncate()
    db.filter_cache.insert(track_names=track_names, CarClass_names=CarClass_names)

    # ------

    if r2la_options.dedi_mode and new_file_names_num:
        get_dedi_hotlaps()


    if not out:
        out = {'new_files': new_file_names_num-reloaded_files_num,
               'removed_parsed_xml_num': removed_parsed_xml_num,
               'reloaded_files_num': reloaded_files_num}
    db_out = db(db.refresh_out.id==1).select().first()
    if not db_out:
        db.refresh_out.insert(data_out=out)
    else:
        db_out.update_record(data_out=out)

    if force_track_records_reload:
        import_logs(clear_tracks=True, out=out)


def auto_refresh():
    db = current.db
    auto_refresh = db(db.auto_refresh.id==1).select(cache=(current.cache.ram, 1), cacheable=True).first()
    if (datetime.datetime.utcnow() - auto_refresh.last_refresh).total_seconds() / 60 > auto_refresh.refresh_minutes:
        import_logs()


def remove_empty_log(actual_path, file_name):
    if not os.path.exists(os.path.join(actual_path, 'r2la_temp')):
        os.makedirs(os.path.join(actual_path, 'r2la_temp'))

    if not os.path.exists(os.path.join(actual_path, "r2la_temp/no_time_set")):
        os.makedirs(os.path.join(actual_path, "r2la_temp/no_time_set"))

    log_file_removal(os.path.join(actual_path, file_name), "Removed on Refresh. No competitors or lap times.")
    shutil.copy2(os.path.join(actual_path, file_name), os.path.join(actual_path, "r2la_temp/no_time_set"))
    os.unlink(os.path.join(actual_path, file_name))


def remove_logs(file_names, action=None):
    db = current.db
    if not isinstance(file_names, (list, tuple)):
        file_names = [file_names]

    for file_name in file_names:
        parsed_xml = db(db.parsed_xml.file_name == file_name).select(db.parsed_xml.home_dir).first()

        temp_path = os.path.join(parsed_xml.home_dir, 'r2la_temp')

        if not os.path.exists(temp_path):
            os.makedirs(temp_path)

        if action == "no_time":
            temp_path = os.path.join(parsed_xml.home_dir, "r2la_temp/no_time_set")
        elif action == "race":
            temp_path = os.path.join(parsed_xml.home_dir, "r2la_temp/race")
        elif action == "warmup":
            temp_path = os.path.join(parsed_xml.home_dir, "r2la_temp/warmup")
        elif action == "qual":
            temp_path = os.path.join(parsed_xml.home_dir, "r2la_temp/qual")
        elif action == "practice":
            temp_path = os.path.join(parsed_xml.home_dir, "r2la_temp/practice")
        elif action == "not_assigned":
            temp_path = os.path.join(parsed_xml.home_dir, "r2la_temp")

        if not os.path.exists(temp_path):
            os.makedirs(temp_path)

        if action is None:
            action = ""
        log_file_removal(os.path.join(parsed_xml.home_dir, file_name), "Removed by user ('Remove "+action+" log(s)').")
        shutil.copy2(os.path.join(parsed_xml.home_dir, file_name), temp_path)
        os.unlink(os.path.join(parsed_xml.home_dir, file_name))

    import_logs(clear_tracks=True)


def log_file_removal(file_name, reason):
    if os.path.isfile("r2la_removed_files.log"):
        with open("r2la_removed_files.log", 'a', encoding='utf-8') as f:
            f.write(datetime.datetime.now().strftime("%d/%m/%Y, %H:%M:%S")+", "+file_name+", "+reason+"\n")
    else:
        with open("r2la_removed_files.log", 'w', encoding='utf-8') as f:
            f.write(datetime.datetime.now().strftime("%d/%m/%Y, %H:%M:%S")+", "+file_name+", "+reason+"\n")


def create_event(file_name, championship_row=None, race_row=None, no_tables=False):
    #print ("---------create_event----"+file_name)
    db = current.db
    db2 = current.db2

    parsed_xml = db(db.parsed_xml.file_name == file_name).select().first()

    if parsed_xml.infodict['session'] == 'Race':
        # info['combined_qualylaps'] [Q2] [Q3] added to parsed_xml.infodict if qual2/3 found
        qual_info = search_for_qual(parsed_xml)
    else:
        qual_info = None

    race_info = parsed_xml.infodict

    for i in range(1, race_info['Competitors']+1):
        car_id = db(db.car_identifier.name==race_info[i]['Category']+race_info[i]['CarType']).select().first()
        if car_id:
            race_info[i]['car_id'] = make_car_id_string(car_id, [race_info[i]['Category'], race_info[i]['CarType'], race_info[i]['CarClass'], race_info[i]['TeamName']])
        else:
            race_info[i]['car_id'] = race_info[i]['CarType']

    if qual_info:
        for i in range(1, qual_info['Competitors']+1):
            car_id = db(db.car_identifier.name==qual_info[i]['Category']+qual_info[i]['CarType']).select().first()
            if car_id:
                qual_info[i]['car_id'] = make_car_id_string(car_id, [qual_info[i]['Category'], qual_info[i]['CarType'], qual_info[i]['CarClass'], qual_info[i]['TeamName']])
            else:
                qual_info[i]['car_id'] = qual_info[i]['CarType']

    if not race_row:
        race_row = Storage()
        fields = [field for field in db.race if field.name != 'id']
        for field in fields:
            race_row[field.name] = field.default
        race_row['file_name'] = file_name
        race_row['teams'] = {}
        race_row['classes'] = {}
        race_row['manual_points'] = {}
        race_row['manual_points_comments'] = {}
        race_row['penalty_points'] = {}

    if not championship_row:
        championship_row = Storage()
        fields = [field for field in db.championship if field.name != 'id']
        for field in fields:
            championship_row[field.name] = field.default
        championship_row['points'] = {}

    event = la_event.Event(race_row=race_row, championship_row=championship_row, race_info=race_info, qual_info=qual_info)
    event.calculate(no_tables=no_tables)

    event.out['player_names'] = [current.session.r2la_options.player_name,
                                 current.session.r2la_options.player_nick,
                                 la_utils.small_name(current.session.r2la_options.player_name),
                                 la_utils.small_name(current.session.r2la_options.player_nick)]

    if race_info['player_position'] and not no_tables:
        i = race_info['player_position']
        # used in def report() to search for record
        car_identifier = db(db.car_identifier.name==race_info[i]['Category']+race_info[i]['CarType']).select().first()
        if car_identifier:
            race_info['player_CarType'] = make_car_id_string(car_identifier, [race_info[i]['Category'], race_info[i]['CarType'], race_info[i]['CarClass'], race_info[i]['TeamName']])
        else:
            race_info['player_CarType'] = race_info[i]['Category']

        race_info['stints'] = get_stints(event)

        race_info['telemetry'] = {}
        telemetry_laps = db2((parsed_xml.session_ts<=db2.telemetry.ts+20) & (parsed_xml.session_ts>=db2.telemetry.ts-20)).select()
        if telemetry_laps:
            for t in telemetry_laps:
                lap_data = t.as_dict()
                min_max = {}
                for name, list_ in lap_data['info'].items():
                    max_ = max(list_)
                    min_ = min(list_)
                    min_max[name] = (min_, max_, sum(list_)/len(list_), max_-min_)
                lap_data['min_max'] = min_max
                lap_data['tid'] = t.id
                race_info['telemetry'][t.lap] = lap_data
    else:
        race_info['player_CarType'] = race_info['CarTypeGuess']
        race_info['stints'] = None
        race_info['telemetry'] = {}

    return event


def get_stints(event):
    stints = []
    info = event.race_info
    i = info['player_position']

    #if info['session'] != 'Race':
    if not info[i]['pitlaps']:
        info[i]['pitlaps'] = [1]
    elif 1 not in info[i]['pitlaps']:
        info[i]['pitlaps'].insert(0, 1)

    all_laps = [event.out['table_raceLaps'][i-1][info[i]['Name']][lap] for lap in range(0, len(event.out['table_raceLaps'][i-1][info[i]['Name']]))]
    all_s1 = [lap['s1']['time_raw'] for lap in all_laps if lap['s1']['time_raw']]
    min_all_s1 = min((all_s1 or [0]))
    all_s2 = [lap['s2']['time_raw'] for lap in all_laps if lap['s2']['time_raw']]
    min_all_s2 = min((all_s2 or [0]))
    all_s3 = [lap['s3']['time_raw'] for lap in all_laps if lap['s3']['time_raw']]
    min_all_s3 = min((all_s3 or [0]))

    last_lap = None
    for x, stint in enumerate(info[i]['pitlaps']):

        if x < len(info[i]['pitlaps']) - 1:
            nextstint = info[i]['pitlaps'][x+1]
        else:
            nextstint = len(info[i]['drracelaps']) + 1

        if nextstint - stint <= 1:
            continue

        stinttimes = [info[i]['drracelaps'][lap-1] for lap in range(stint, nextstint) if info[i]['drracelaps'][lap-1]]

        fastest_raw = min((stinttimes or [0]))
        fastest_str = la_utils.sectostr(fastest_raw)

        stint_dict = {}

        if stinttimes:
            if info['session'] == 'Race' and len(stinttimes) > 1:
                stint_dict['avg_time'] = la_utils.sectostr(sum(stinttimes[1:])/len(stinttimes[1:]))
            else:
                stint_dict['avg_time'] = la_utils.sectostr(sum(stinttimes)/len(stinttimes))
        else:
            stint_dict['avg_time'] = '-'


        stint_dict['laps'] = [event.out['table_raceLaps'][i-1][info[i]['Name']][lap]
                              for lap in range(stint-1, nextstint) if event.out['table_raceLaps'][i-1][info[i]['Name']][lap]['num'] != '']

        s1 = [lap['s1']['time_raw'] for lap in stint_dict['laps'] if lap['s1']['time_raw']]
        min_s1 = min((s1 or [0]))
        stint_dict['sum_s1'] = la_utils.sectostr(sum(s1))
        s2 = [lap['s2']['time_raw'] for lap in stint_dict['laps'] if lap['s2']['time_raw']]
        min_s2 = min((s2 or [0]))
        stint_dict['sum_s2'] = la_utils.sectostr(sum(s2))
        s3 = [lap['s3']['time_raw'] for lap in stint_dict['laps'] if lap['s3']['time_raw']]
        min_s3 = min((s3 or [0]))
        stint_dict['sum_s3'] = la_utils.sectostr(sum(s3))

        fuel_by_lap = []
        twfl_by_lap = []
        twfr_by_lap = []
        twrl_by_lap = []
        twrr_by_lap = []
        stint_times_sum = 0
        for lap_num, lap in enumerate(stint_dict['laps'], 1):

            if lap['laptime']['time'] == fastest_str:
                lap['lap_style'] = 'background-color: #C3FDB8;'
            else:
                lap['lap_style'] = ''

            if lap['s1']['time_raw'] == min_all_s1:
                lap['lap_s1_style'] = 'color: #B445FE; font-weight: bold;'
            elif lap['s1']['time_raw'] == min_s1:
                lap['lap_s1_style'] = 'color: #3d9e12; font-weight: bold;'
            else:
                lap['lap_s1_style'] = ''

            if lap['s2']['time_raw'] == min_all_s2:
                lap['lap_s2_style'] = 'color: #B445FE; font-weight: bold;'
            elif lap['s2']['time_raw'] == min_s2:
                lap['lap_s2_style'] = 'color: #3d9e12; font-weight: bold;'
            else:
                lap['lap_s2_style'] = ''

            if lap['s3']['time_raw'] == min_all_s3:
                lap['lap_s3_style'] = 'color: #B445FE; font-weight: bold;'
            elif lap['s3']['time_raw'] == min_s3:
                lap['lap_s3_style'] = 'color: #3d9e12; font-weight: bold;'
            else:
                lap['lap_s3_style'] = ''

            dev = lap['laptime']['time_raw'] - info[i]['FastestLap']

            # changing table_raceLaps colors here !!!!!!! because lists. Fixed
            lap['gap'] = '-'
            lap['times_sum'] = '-'
            lap['laptime']['stint_bg'] = lap['laptime']['bg']
            if lap['laptime']['time_raw'] != 0:
                stint_times_sum += lap['laptime']['time_raw']
                lap['times_sum'] = la_utils.sectostr(stint_times_sum)
                lap['gap'] = la_utils.sectostr(dev) if dev != 0 else '-'
                if dev <= .5:
                    lap['laptime']['stint_bg'] = '#9b62c1'
                elif .5 < dev <= 1:
                    lap['laptime']['stint_bg'] = '#F88017'
                elif 1 < dev <= 2:
                    lap['laptime']['stint_bg'] = '#FBB117'
                elif 2 < dev <= 3:
                    lap['laptime']['stint_bg'] = '#ECD672'
                elif 3 < dev:
                    lap['laptime']['stint_bg'] = '#C9C299'

            lap['lap_time_style'] = ''
            if lap['laptime']['time_raw'] == info[i]['FastestLap']:
                lap['lap_time_style'] += 'color #FFF; font-weight: bold;'

            try:
                if x == 0 and lap_num == 1 and info['session'] == 'Race':
                    lap['fuel_spent'] = 'Start'
                elif  x > 0 and lap_num == 1 and info['session'] == 'Race':
                    lap['fuel_spent'] = 'Pit out'
                elif lap_num == 1 or (info['session'] != 'Race' and lap_num == len(stint_dict['laps'])):
                    lap['fuel_spent'] = '-'
                else:
                    if float(stint_dict['laps'][lap_num-1]['fuel'].rstrip('%')) > float(stint_dict['laps'][lap_num-2]['fuel'].rstrip('%')):
                        lap['fuel_spent'] = "Refueling"
                    else:
                        lap['fuel_spent'] = round(float(stint_dict['laps'][lap_num-2]['fuel'].rstrip('%')) - float(stint_dict['laps'][lap_num-1]['fuel'].rstrip('%')), 2)
                        fuel_by_lap.append(lap['fuel_spent'])
                        lap['fuel_spent'] = str(lap['fuel_spent']) + "%"

                if info['has_tire_wear']:
                    if not last_lap or (last_lap['twfl'] < stint_dict['laps'][lap_num-1]['twfl']):
                        lap['lap_twfl'] = round((1 - stint_dict['laps'][lap_num-1]['twfl']) * 100, 1)
                    else:
                        lap['lap_twfl'] = round((last_lap['twfl'] - stint_dict['laps'][lap_num-1]['twfl']) * 100, 1)
                    if 100 > lap['lap_twfl'] > 0:
                        twfl_by_lap.append(lap['lap_twfl'])
                    else:
                        lap['lap_twfl'] = '-'

                    if not last_lap or (last_lap['twfr'] < stint_dict['laps'][lap_num-1]['twfr']):
                        lap['lap_twfr'] = round((1 - stint_dict['laps'][lap_num-1]['twfr']) * 100, 1)
                    else:
                        lap['lap_twfr'] = round((last_lap['twfr'] - stint_dict['laps'][lap_num-1]['twfr']) * 100, 1)
                    if 100 > lap['lap_twfr'] > 0:
                        twfr_by_lap.append(lap['lap_twfr'])
                    else:
                        lap['lap_twfr'] = '-'

                    if not last_lap or (last_lap['twrl'] < stint_dict['laps'][lap_num-1]['twrl']):
                        lap['lap_twrl'] = round((1 - stint_dict['laps'][lap_num-1]['twrl']) * 100, 1)
                    else:
                        lap['lap_twrl'] = round((last_lap['twrl'] - stint_dict['laps'][lap_num-1]['twrl']) * 100, 1)
                    if 100 > lap['lap_twrl'] > 0:
                        twrl_by_lap.append(lap['lap_twrl'])
                    else:
                        lap['lap_twrl'] = '-'

                    if not last_lap or (last_lap['twrr'] < stint_dict['laps'][lap_num-1]['twrr']):
                        lap['lap_twrr'] = round((1 - stint_dict['laps'][lap_num-1]['twrr']) * 100, 1)
                    else:
                        lap['lap_twrr'] = round((last_lap['twrr'] - stint_dict['laps'][lap_num-1]['twrr']) * 100, 1)
                    if 100 > lap['lap_twrr'] > 0:
                        twrr_by_lap.append(lap['lap_twrr'])
                    else:
                        lap['lap_twrr'] = '-'

                    last_lap = stint_dict['laps'][lap_num-1]

            except:
                #print (traceback.format_exc())
                lap['fuel_spent'] = '-'

        stint_dict['sum_lap'] = la_utils.sectostr(sum(stinttimes))
        possible = min_s1 + min_s2 + min_s3
        stint_dict['poss'] = la_utils.sectostr(possible)
        stint_dict['green'] = False

        if round(possible, 3) < round(fastest_raw, 3):
            stint_dict['green'] = True

        if info['session'] != 'Race':
            stint_dict['laps'][0]['laptime']['time'] = 'Pit out'
            stint_dict['laps'][-1]['fuel'] = '-'

        if event.race_info['has_tire_wear']:
            tw_est_min = 10000
            stint_dict['tw_est_hl'] = 'twfl_est'
            if twfl_by_lap:
                stint_dict['twfl_avg'] = round(sum(twfl_by_lap)/len(twfl_by_lap), 2)
                stint_dict['twfl_sum'] = round(sum(twfl_by_lap), 2)
                stint_dict['twfl_est'] = int(100/stint_dict['twfl_avg'])
                if stint_dict['twfl_est'] < tw_est_min:
                    tw_est_min = stint_dict['twfl_est']
            else:
                stint_dict['twfl_avg'] = '-'
                stint_dict['twfl_sum'] = '-'
                stint_dict['twfl_est'] = '?'

            if twfr_by_lap:
                stint_dict['twfr_avg'] = round(sum(twfr_by_lap)/len(twfr_by_lap), 2)
                stint_dict['twfr_sum'] = round(sum(twfr_by_lap), 2)
                stint_dict['twfr_est'] = int(100/stint_dict['twfr_avg'])
                if stint_dict['twfr_est'] < tw_est_min:
                    tw_est_min = stint_dict['twfr_est']
                    stint_dict['tw_est_hl'] = 'twfr_est'
            else:
                stint_dict['twfr_avg'] = '-'
                stint_dict['twfr_sum'] = '-'
                stint_dict['twfr_est'] = '?'

            if twrl_by_lap:
                stint_dict['twrl_avg'] = round(sum(twrl_by_lap)/len(twrl_by_lap), 2)
                stint_dict['twrl_sum'] = round(sum(twrl_by_lap), 2)
                stint_dict['twrl_est'] = int(100/stint_dict['twrl_avg'])
                if stint_dict['twrl_est'] < tw_est_min:
                    tw_est_min = stint_dict['twrl_est']
                    stint_dict['tw_est_hl'] = 'twrl_est'
            else:
                stint_dict['twrl_avg'] = '-'
                stint_dict['twrl_sum'] = '-'
                stint_dict['twrl_est'] = '?'

            if twrr_by_lap:
                stint_dict['twrr_avg'] = round(sum(twrr_by_lap)/len(twrr_by_lap), 2)
                stint_dict['twrr_sum'] = round(sum(twrr_by_lap), 2)
                stint_dict['twrr_est'] = int(100/stint_dict['twrr_avg'])
                if stint_dict['twrr_est'] < tw_est_min:
                    stint_dict['tw_est_hl'] = 'twrr_est'
            else:
                stint_dict['twrr_avg'] = '-'
                stint_dict['twrr_sum'] = '-'
                stint_dict['twrr_est'] = '?'

        try:
            if info['session'] != 'Race':
                laps_ind = -2
            else:
                laps_ind = -1
            if len(stint_dict['laps']) > 1 and float(stint_dict['laps'][laps_ind]['fuel'].rstrip('%')) > float(stint_dict['laps'][laps_ind-1]['fuel'].rstrip('%')):
                fuel_spent =  round(stint_dict['laps'][laps_ind-1]['fuel_spent'] + float(stint_dict['laps'][0]['fuel'].rstrip('%')) - float(stint_dict['laps'][laps_ind-1]['fuel'].rstrip('%')), 2)
            else:
                fuel_spent = round(float(stint_dict['laps'][0]['fuel'].rstrip('%')) - float(stint_dict['laps'][laps_ind]['fuel'].rstrip('%')), 2)
            stint_dict['fuel_spent'] = str(fuel_spent)+'%'
            if fuel_by_lap:
                stint_dict['fuel_avg'] = round(sum(fuel_by_lap)/len(fuel_by_lap), 2)
            else:
                stint_dict['fuel_avg'] = '-'
        except:
            stint_dict['fuel_spent'] = '-'
            stint_dict['fuel_avg'] = '-'

        stints.append(stint_dict)
    return stints


def search_for_qual(race_xml):
    info = race_xml.infodict
    db = current.db
    actual_path = race_xml.home_dir

    xmls_with_ts =  db((db.parsed_xml.weekend_ts==race_xml.weekend_ts) & \
                       (db.parsed_xml.file_name!=race_xml.file_name)).select(db.parsed_xml.file_name,
                                                                    db.parsed_xml.session_name,
                                                                    orderby=~db.parsed_xml.last_update)
    q_num = 3
    qual_info_out = None
    for xml in xmls_with_ts:
        if xml.session_name in ('Qualify', 'Qualify2', 'Qualify3'):
            if q_num == 3:
                qual_xml = db(db.parsed_xml.file_name == xml.file_name).select(db.parsed_xml.infodict).first()
                la_rfparser2.add_dns_to_race_info(race_info=info, qual_info=qual_xml.infodict)
                q_num -= 1
                qual_info_out = qual_xml.infodict
                if xml.session_name == "Qualify":
                    return qual_info_out

                if xml.session_name == 'Qualify3':
                    info['Q3'] = True
                    info['combined_qualylaps'] = {info[p]['Name']: len(qual_xml.infodict[qual_xml.infodict['finish_positions'][info[p]['Name']]]['drracelaps']) for p in range(1, info['Competitors']+1)
                                                  if info[p]['Name'] in qual_xml.infodict['racedrlist']}
            if q_num < 3:
                if xml.session_name == 'Qualify2':
                    parsed_xml = db(db.parsed_xml.file_name==xml.file_name).select().first()
                    info['Q2'] = {info[p]['Name']: '-' for p in range(1, info['Competitors']+1)}
                    if not info.get('combined_qualylaps'):
                        info['combined_qualylaps'] = defaultdict(int)
                    for p in range(1, parsed_xml.infodict['Competitors']+1):
                        info['Q2'][parsed_xml.infodict[p]['Name']] = la_utils.sectostr(parsed_xml.infodict[p]['FastestLap']) if parsed_xml.infodict[p]['FastestLap'] else '-'
                        try:
                            info['combined_qualylaps'][parsed_xml.infodict[p]['Name']] += parsed_xml.infodict[p]['Laps']
                        except:
                            info['combined_qualylaps'][parsed_xml.infodict[p]['Name']] = '-'
                    q_num -= 1

                if xml.session_name == 'Qualify':
                    parsed_xml = db(db.parsed_xml.file_name==xml.file_name).select().first()
                    info['Q1'] = {info[p]['Name']: '-' for p in range(1, info['Competitors']+1)}
                    for p in range(1, parsed_xml.infodict['Competitors']+1):
                        info['Q1'][parsed_xml.infodict[p]['Name']] = la_utils.sectostr(parsed_xml.infodict[p]['FastestLap']) if parsed_xml.infodict[p]['FastestLap'] else '-'
                        try:
                            info['combined_qualylaps'][parsed_xml.infodict[p]['Name']] += parsed_xml.infodict[p]['Laps']
                        except:
                            info['combined_qualylaps'][parsed_xml.infodict[p]['Name']] = '-'

    return qual_info_out


def get_player_best_sectors(file_names):
    logs = []
    stats = {}
    stats['laps'] = 0
    stats['time'] = 0
    db = current.db
    for file_name in file_names:
        parsed_xml = db(db.parsed_xml.file_name==file_name).select().first()

        info = parsed_xml.infodict
        p = info['player_position']
        
        row = {}
        if parsed_xml.cid:
            row['file_name'] = parsed_xml.cid.name
        else:
            row['file_name'] = file_name

        if not parsed_xml.faulty:
            row['session'] = info['session']
        else:
            row['session'] = '-'

        if info.get('player_position'):
            stats['laps'] = stats['laps'] + sum([1 for l in info[p]['drracelaps'] if l])
            stats['time'] = stats['time'] + sum(info[p]['drracelaps'])

            row['time_raw'] = info[p]['FastestLap'] if info[p]['FastestLap'] else '-'
            row['time'] = la_utils.sectostr(info[p]['FastestLap']) if info[p]['FastestLap'] else '-'
            row['sectors'] = [la_utils.sectostr(s) if s != 10000 else '-' for s in info[p]['bsectors']]
            if row['sectors'][0] != '-' and row['sectors'][1] != '-' and row['sectors'][2] != '-':
                row['possible'] = la_utils.sectostr(sum(info[p]['bsectors']))
                if round(sum(info[p]['bsectors']), 3) < round(row['time_raw'], 3):
                    row['green'] = True
            else:
                row['possible'] = '-'
            row['S1_raw'] = info[p]['bsectors'][0] if info[p]['bsectors'][0] != 10000 else '-'
            row['S2_raw'] = info[p]['bsectors'][1] if info[p]['bsectors'][1] != 10000 else '-'
            row['S3_raw'] = info[p]['bsectors'][2] if info[p]['bsectors'][2] != 10000 else '-'

            car_identifier = db(db.car_identifier.name==info[p]['Category']+info[p]['CarType']).select().first()
            if car_identifier:
                row['car'] = make_car_id_string(car_identifier, [info[p]['Category'],
                                                                 info[p]['CarType'],
                                                                 info[p]['CarClass'],
                                                                 info[p]['TeamName']])
            else:
                row['car'] = info[p]['Category']
                
        else:
            row['time_raw'] = '-'
            row['S1_raw'] = '-'
            row['S2_raw'] = '-'
            row['S3_raw'] = '-'
            row['time'] = '-'
            row['sectors'] = ['-', '-', '-']
            row['possible'] = '-'
            row['car'] = info.get('CarTypeGuess') or 'error'
            
            row['startfuel'] = '-'

        row['track'] = info.get('TrackCourse') or 'error'

        logs.append(row)

    in_out = {'time_raw':'FL', 'S1_raw':'S1', 'S2_raw':'S2', 'S3_raw':'S3'}

    for _in, _out in in_out.items():
        times = [l[_in] if l[_in] != '-' else 10000 for l in logs ]
        if times:
            fastest_ind, fastest_time = min(enumerate(times), key=lambda p: p[1])
            if fastest_time != 10000:
                logs[fastest_ind][_out] = True

    return logs, stats


def prepare_hotlaps(selected):
    db = current.db
    hotlap_car_name = (selected['Category'] if selected['CategoryBool'] else '') + \
                      (selected['CarType'] if selected['CarTypeBool'] else '') + \
                      (selected['CarClass'] if selected['CarClassBool'] else '') + \
                      (selected['TeamName'] if selected['TeamNameBool'] else '')

    all_times = []
    for track_name in selected.tracks:

        selected[track_name] = {}

        if selected.server_data.get(track_name):
            selected[track_name]['wr'] = selected.server_data[track_name]['wr']
            selected[track_name]['position'] = selected.server_data[track_name]['position']
            selected[track_name]['competitors'] = selected.server_data[track_name]['competitors']
        else:
            selected[track_name]['wr'] = 0
            selected[track_name]['position'] = 0
            selected[track_name]['competitors'] = 0

        track_in_db = db(db.track.name==track_name).select().first()
        if not track_in_db:
            continue

        track_connected = db(db.tracks_connected.name==track_name).select().first()

        if track_connected:
            track_in_db = db(db.track.name==track_connected.connected_to).select().first()

        parsed_xmls = db((db.parsed_xml.track_name==track_in_db.name) & \
                         (db.parsed_xml.last_update>selected['block_time']) & \
                         (db.parsed_xml.player_position>0) & \
                         (db.parsed_xml.competitors>0)).select()

        if not parsed_xmls:
            continue

        #print (len(parsed_xmls), selected.name, track_name)
        '''
        for p in parsed_xmls:
            print (p.file_name)
        '''
        for parsed_xml in parsed_xmls:
            if parsed_xml.infodict[parsed_xml.player_position]['FastestLap']:

                info = parsed_xml.infodict
                i = parsed_xml.player_position

                player_car_name = (info[i]['Category'] if selected['CategoryBool'] else '') + \
                                  (info[i]['CarType'] if selected['CarTypeBool'] else '') + \
                                  (info[i]['CarClass'] if selected['CarClassBool'] else '') + \
                                  (info[i]['TeamName'] if selected['TeamNameBool'] else '')

                if hotlap_car_name == player_car_name:

                    record_found = False

                    if selected[track_name].get('time'):
                        if selected[track_name]['time'] >= info[i]['FastestLap']:
                            selected[track_name]['time'] = info[i]['FastestLap']

                            record_found = True

                    else:
                        selected[track_name]['time'] = info[i]['FastestLap']
                        record_found = True

                    if record_found == True:
                        if selected[track_name].get('wr'):
                            gap = selected[track_name]['time'] - selected[track_name].get('wr')
                            if gap == 0:
                                selected[track_name]['gap'] = '-'
                            elif gap < 0:
                                selected[track_name]['gap'] = '-' + la_utils.sectostr(selected[track_name]['time']-selected[track_name].get('wr'))
                            else:
                                selected[track_name]['gap'] = la_utils.sectostr(selected[track_name]['time']-selected[track_name].get('wr'))

                        selected[track_name]['CarType'] = info['CarTypeGuess']
                        selected[track_name]['CarClass'] = info['player_CarClass']
                        selected[track_name]['TeamName'] = info['player_TeamName']
                        selected[track_name]['Category'] = info['player_Category']
                        s1 = info[i]['racesectors'][info[i]['fastest_lap_num']-1][1]
                        s2 = info[i]['racesectors'][info[i]['fastest_lap_num']-1][2]
                        s3 = info[i]['racesectors'][info[i]['fastest_lap_num']-1][3]
                        selected[track_name]['s1'] = float(s1)
                        selected[track_name]['s2'] = float(s2)
                        selected[track_name]['s3'] = float(s3)
                        selected[track_name]['compounds'] = info[i]['compounds_str_bylap'][info[i]['fastest_lap_num']-1]
                        selected[track_name]['compounds'] = "-".join(set(selected[track_name]['compounds']))
                        selected[track_name]['aids'] = la_utils.formataids(info[i]['aids'])
                        selected[track_name]['f_t_d'] = ' '.join((info['FuelMult'], info['TireMult'], info['DamageMult']))

        if selected[track_name].get('time'):
            all_times.append(selected[track_name]['time'])
            if selected.sent_times:
                if selected.sent_times.get(track_name):
                    if selected[track_name]['time'] == selected.sent_times[track_name]:
                        selected[track_name]['sent'] = True

    if all_times and len(all_times) == len(selected.tracks):
        selected.all_times = sum(all_times)
    else:
        selected.all_times = 0

    selected['overall'] = {}
    if selected.server_data.get('overall'):
        selected['overall']['wr'] = selected.server_data['overall']['wr']
        selected['overall']['position'] = selected.server_data['overall']['position']
        selected['overall']['competitors'] = selected.server_data['overall']['competitors']
        if selected.sent_times:
            if selected.sent_times.get('overall'):
                if selected.all_times == selected.sent_times['overall']:
                    selected['overall']['sent'] = True
    else:
        selected['overall']['wr'] = 0
        selected['overall']['position'] = 0
        selected['overall']['competitors'] = 0

    if selected.all_times and selected['overall'].get('wr'):
        gap = selected.all_times - selected['overall'].get('wr')
        if gap == 0:
            selected['overall']['gap'] = '-'
        elif gap < 0:
            selected['overall']['gap'] = '-' + la_utils.sectostr(selected.all_times-selected['overall'].get('wr'))
        else:
            selected['overall']['gap'] = '+' + la_utils.sectostr(selected.all_times-selected['overall'].get('wr'))


def get_dedi_hotlaps(competition_id=0):
    db = current.db
    if competition_id:
        comps = db((db.comps.id==competition_id) & (db.comps.archived==False) & (db.comps.ServerName!='')).select()
    else:
        comps = db((db.comps.archived==False) & (db.comps.ServerName!='')).select()

    for c in comps:
        if c.closed and c.id != competition_id:
            continue
        track_in_db = db(db.track.name==c['track_name']).select().first()
        if not track_in_db:
            continue

        track_connected = db(db.tracks_connected.name==c['track_name']).select().first()

        if track_connected:
            track_in_db = db(db.track.name==track_connected.connected_to).select().first()

        # take parsed_xml instead, filter by competition time period
        # print (info.infodict['DateTime'], info.infodict['timestamp'], datetime.utcfromtimestamp(float(info.infodict['timestamp'])))
        """
        query = (db.parsed_xml.track_name==track_in_db.name) & \
                (db.parsed_xml.last_update>datetime.datetime.utcfromtimestamp(float(c['start_time']))) & \
                (db.parsed_xml.last_update<datetime.datetime.utcfromtimestamp(float(c['end_time']))) & \
                (db.parsed_xml.competitors>0)
        #(db.parsed_xml.Dedicated==True) & \
        if c.ServerName != 'any':
            query &= db.parsed_xml.rf_server_name==c.ServerName
        """

        if c.ServerName != 'any':
            parsed_xmls = db((db.parsed_xml.track_name==track_in_db.name) & \
                             (db.parsed_xml.last_update>datetime.datetime.utcfromtimestamp(float(c['start_time']))) & \
                             (db.parsed_xml.last_update<datetime.datetime.utcfromtimestamp(float(c['end_time']))) & \
                             (db.parsed_xml.Dedicated==True) & \
                             (db.parsed_xml.competitors>0) & \
                             (db.parsed_xml.rf_server_name==c.ServerName)).select()
        else:
            parsed_xmls = db((db.parsed_xml.track_name==track_in_db.name) & \
                             (db.parsed_xml.last_update>datetime.datetime.utcfromtimestamp(float(c['start_time']))) & \
                             (db.parsed_xml.last_update<datetime.datetime.utcfromtimestamp(float(c['end_time']))) & \
                             #(db.parsed_xml.Dedicated==True) & \
                             (db.parsed_xml.competitors>0)).select()

        if not parsed_xmls:
            continue
        '''
        print (len(parsed_xmls), c.name)
        for p in parsed_xmls:
            print (p.file_name)
        '''
        comp_car_name = (c['Category'] if c['CategoryBool'] else '') + \
                        (c['CarType'] if c['CarTypeBool'] else '') + \
                        (c['CarClass'] if c['CarClassBool'] else '') + \
                        (c['TeamName'] if c['TeamNameBool'] else '')

        for parsed_xml in parsed_xmls:
            info = parsed_xml.infodict

            for i in range(1, info['Competitors']+1):
                if info[i]['isPlayer'] and info[i]['FastestLap']:

                    player_car_name = (info[i]['Category'] if c['CategoryBool'] else '') + \
                                      (info[i]['CarType'] if c['CarTypeBool'] else '') + \
                                      (info[i]['CarClass'] if c['CarClassBool'] else '') + \
                                      (info[i]['TeamName'] if c['TeamNameBool'] else '')

                    if comp_car_name == player_car_name:
                        if int(parsed_xml.infodict['FuelMult']) == c['FuelMult'] and int(parsed_xml.infodict['TireMult']) == c['TireMult']:
                            if not c['any_aids'] and 'Invulnerable' not in c['aids']:
                                if int(parsed_xml.infodict['DamageMult']) < c['DamageMult']:
                                    continue
                            wrong_aids = check_wrong_aids(c['aids'], info[i]['aids'])
                            if c['any_aids'] or not wrong_aids:
                                driver_exists = db(db.drivers.name==info[i]['Name']).select().first()
                                if not driver_exists:
                                    db.drivers.insert(name=info[i]['Name'])
                                    driver_exists = db(db.drivers.name==info[i]['Name']).select().first()
                                result_exists = db((db.comp_results.comp_id==c['id']) & \
                                                   (db.comp_results.driver_id==driver_exists.id)).select(db.comp_results.id,
                                                                                                         db.comp_results.lap_time,
                                                                                                         db.comp_results.attempts).first()
                                if result_exists:
                                    if info[i]['FastestLap'] >= result_exists.lap_time:
                                        continue

                                if info[i]['FastestLap'] in info[i]['drracelaps']:
                                    lap_ind = info[i]['drracelaps'].index(info[i]['FastestLap'])
                                    s1 = info[i]['racesectors'][lap_ind][1]
                                    s2 = info[i]['racesectors'][lap_ind][2]
                                    s3 = info[i]['racesectors'][lap_ind][3]
                                    compounds = "-".join(set(info[i]['compounds_str_bylap'][lap_ind]))
                                else:
                                    s1 = 1000
                                    s2 = 1000
                                    s3 = 1000
                                    compounds = "-"

                                if result_exists:
                                    result_exists.update_record(lap_time=info[i]['FastestLap'],
                                                                s1=s1,
                                                                s2=s2,
                                                                s3=s3,
                                                                compounds=compounds,
                                                                aids=info[i]['aids'],
                                                                Category=info[i]['Category'],
                                                                CarType=info[i]['CarType'],
                                                                CarClass=info[i]['CarClass'],
                                                                TeamName=info[i]['TeamName'],
                                                                VehicleNumber=info[i]['VehicleNumber'],
                                                                attempts=result_exists.attempts+1,
                                                                upload_timestamp=info['session_ts'],
                                                                file_name=parsed_xml.file_name)
                                else:
                                    db.comp_results.insert(comp_id=c.id,
                                                            driver_id=driver_exists.id,
                                                            lap_time=info[i]['FastestLap'],
                                                            s1=s1,
                                                            s2=s2,
                                                            s3=s3,
                                                            compounds=compounds,
                                                            aids=info[i]['aids'],
                                                            Category=info[i]['Category'],
                                                            CarType=info[i]['CarType'],
                                                            CarClass=info[i]['CarClass'],
                                                            TeamName=info[i]['TeamName'],
                                                            VehicleNumber=info[i]['VehicleNumber'],
                                                            attempts=1,
                                                            upload_timestamp=info['session_ts'],
                                                            file_name=parsed_xml.file_name)


def prepare_race_export(with_races=False):
    db = current.db
    request = current.request
    response = current.response

    if request.vars.cid and request.vars.rid:
        championship = db(db.championship.id==request.vars.cid).select().first()
        race = db(db.race.id==request.vars.rid).select().first()
        event = create_event(race.file_name, championship, race)

        races = db(db.race.championship_id==request.vars.cid).select(db.race.id, orderby=db.race.id)
        races = [r.id for r in races]
    else:
        event = create_event(request.vars.file_name)

    track_connected = db(db.tracks_connected.name==event.race_info['TrackCourse']).select().first()
    if track_connected:
        track = db(db.track.name==track_connected.connected_to).select().first()
    else:
        track = db(db.track.name==event.race_info['TrackCourse']).select().first()

    if track:
        record = db((db.track_record.track_id==track.id) & (db.track_record.car_str==event.race_info['player_CarType'])).select().first()
        if record:
            track_record = la_utils.sectostr(record.raw_time)
        else:
            track_record = "-"
    else:
        track_record = "-"

    static_path = os.path.join(os.getcwd(), 'applications/'+request.application+'/static')
    files_dict = {'uikit_almost_flat_min_css': 'css/uikit.almost-flat.min.css',
                  'app_css': 'css/app.css',
                  'jquery_js': 'js/jquery.js',
                  'uikit_min_js': 'js/uikit.min.js',
                  'modernizr_custom_js': 'js/modernizr.custom.js',
                  'jquery_flot_min_js': 'js/jquery.flot.min.js',
                  'jquery_flot_navigate_min_js': 'js/jquery.flot.navigate.min.js'
                  }
    files_out = {}
    for name, path in files_dict.items():
        with open(os.path.join(static_path, path), encoding="utf-8") as f:
            try:
                opened_file_str = f.read()
            except UnicodeDecodeError:
                with open(os.path.join(static_path, path), encoding="cp1252") as f2:
                    opened_file_str = f2.read()

        files_out[name] = opened_file_str

    out = dict(event=event, track=track, track_record=track_record, is_export=True, form=None,
               notrace=not event.race_info['session']=='Race',
               with_races=with_races)
    out.update(files_out)

    from gluon.contrib.minify import htmlmin
    mainhtml = htmlmin.minify(response.render('export/export_report.html' if not with_races else 'export/export_report_without_extend.html', out))

    if request.vars.cid and request.vars.rid:
        file_name = championship.name + ' Race ' + str(races.index(race.id)+1) + " " + race.name + ".html"
    else:
        file_name = datetime.datetime.strftime(event.race_info['DateTime'], '%Y_%m_%d_%H_%M') + '.' + event.race_info['TrackCourse'] + ".html"

    return file_name, mainhtml


def get_player_json():
    rf2_path = current.session.r2la_options.paths[0]
    rf2_path = rf2_path.rstrip('UserData\Log\Results')

    with open(os.path.join(rf2_path, "UserData\player\Player.json"), encoding="utf-8") as f:
        try:
            opened_file_str = f.read()
        except UnicodeDecodeError:
            with open(os.path.join(rf2_path, "UserData\player\Player.json"), encoding="cp1252") as f2:
                opened_file_str = f2.read()

    player_json = json.load(opened_file_str) #, encoding='ISO-8859-1')
    #print (player_file['Game Options']['CURNT Race Laps'])
    return player_json


def check_wrong_aids(allowed, players):
    players = [a.split('=')[0] if "=" in a else a for a in players]
    ALWAYS_ALLOWED = ['Unknown','Lift','Blip','AutoBlip','AutoLift']
    allowed = allowed + ALWAYS_ALLOWED
    wrong_aids = set(players) - set(allowed)
    return wrong_aids


def make_car_id_string(car, infodict_ids):
    s = ''
    if car.CategoryBool:
        s = s + infodict_ids[0] + " "
    if car.CarTypeBool:
        s = s + infodict_ids[1] + " "
    if car.CarClassBool:
        s = s + infodict_ids[2] + " "
    if car.TeamNameBool:
        s = s + infodict_ids[3]
    s = s.rstrip()
    if not s:
        s = infodict_ids[0]
    return s


def creation_datetime(filename):
    return datetime.datetime.fromtimestamp(os.path.getctime(filename))


def creation_timestamp(filename):
    return os.path.getctime(filename)
