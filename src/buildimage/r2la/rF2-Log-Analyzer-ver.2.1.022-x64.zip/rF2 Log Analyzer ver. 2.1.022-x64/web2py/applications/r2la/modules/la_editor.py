from gluon import *
from gluon.storage import Storage
import traceback
import os
import datetime
import xml.etree.ElementTree as etree 


class Editor:
    def __init__(self):
        self.file_name = None

    def open_file(self, file_name):
        self.file_name = file_name
        db = current.db
        parsed_xml_exists = db(db.parsed_xml.file_name==self.file_name).select(db.parsed_xml.home_dir).first()
        if not parsed_xml_exists:
            return

        self.home_dir = parsed_xml_exists.home_dir

        with open(os.path.join(self.home_dir, self.file_name), encoding="utf-8") as f:
            try:
                opened_file_str = f.read()
            except UnicodeDecodeError:
                with open(os.path.join(self.home_dir, self.file_name), encoding="cp1252") as f2:
                    opened_file_str = f2.read()

        string = opened_file_str
        self.temp_part = string[:90]
        prepared_xml_string = str(string)[39:]
        self.root = etree.fromstring(prepared_xml_string)

        RaceResults = self.root.find('RaceResults')

        possible_sessions = ['Race', 'Race2', 'Race3', 'Qualify', 'Qualify2', 'Qualify3',
                             'Practice1', 'Practice2', 'Practice3', 'Practice4', 'TestDay', 'Warmup', 'TimeTrial']
        session_name = [RaceResults.find(s) for s in possible_sessions if RaceResults.find(s) is not None][0].tag
        self.session = RaceResults.find(session_name)

        noname_driver_index = 1
        for driver_tag in self.session.findall('Driver'):
            name_element = driver_tag.find('Name')
            if not name_element.text:
                name_element.text = "Noname Driver" + str(noname_driver_index)
                noname_driver_index += 1

    def save_file(self, clone=False, event=None):
        if not self.file_name:
            return

        if clone:
            f_name = self.file_name.rstrip('.xml')+"E.xml"

            for driver_tag in self.session.findall('Driver'):
                name_tag = driver_tag.find('Name')
                #name_tag_index = driver_tag.index(name_tag)
                #driver_tag.insert(name_tag_index, etree.XML("<NameOriginal>"+name_tag.text+"</NameOriginal>"))
                pos = event.race_info['finish_positions'][name_tag.text]
                position_tag = driver_tag.find('Position')
                position_tag.text = str(pos)

            if event.race_info['session'] in ('Qualify', 'Qualify2', 'Qualify3'):
                time_string_tag = self.session.find('TimeString')
                new_date_time = event.race_info['DateTime'] + datetime.timedelta(seconds=1)
                time_string_tag.text = new_date_time.strftime('%Y/%m/%d %H:%M:%S')

        else:
            f_name = self.file_name

        with open(os.path.join(self.home_dir, f_name), 'w', encoding="utf-8") as f:
            out = etree.tostring(self.root, method="html", encoding="unicode")
            out = self.temp_part + out
            f.write(out)

    def create_fake_xml_from_competition(self, comp_results):
        db = current.db
        comp = db(db.comps.id==comp_results[0].comp_id).select().first()

        header = """<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE rF [
<!ENTITY rFEnt "rFactor Entity">
]>
"""
        root = etree.Element("rFactorXML", attrib={"version": "1.0"})
        RaceResults = etree.Element("RaceResults")
        root.append(RaceResults)
        RaceResults.append(etree.fromstring("<Setting>Race Weekend</Setting>"))
        RaceResults.append(etree.fromstring("<PlayerFile>player</PlayerFile>"))
        RaceResults.append(etree.fromstring("<DateTime>"+str(comp.end_time)+"</DateTime>"))
        RaceResults.append(etree.fromstring("<TimeString>"+datetime.datetime.utcfromtimestamp(comp.end_time).strftime('%Y/%m/%d %H:%M:%S')+"</TimeString>"))
        RaceResults.append(etree.XML("<Mod>All Tracks Cars</Mod>"))
        RaceResults.append(etree.Element("Season"))
        RaceResults.append(etree.fromstring("<TrackVenue>"+comp.track_name+"</TrackVenue>"))
        RaceResults.append(etree.fromstring("<TrackCourse>"+comp.track_name+"</TrackCourse>"))
        RaceResults.append(etree.fromstring("<TrackEvent>"+comp.track_name+"</TrackEvent>"))
        RaceResults.append(etree.fromstring("<TrackLength>1000</TrackLength>"))
        RaceResults.append(etree.fromstring("<GameVersion>1.1110</GameVersion>"))
        RaceResults.append(etree.fromstring("<Dedicated>0</Dedicated>"))
        RaceResults.append(etree.fromstring("<RaceLaps>1</RaceLaps>"))
        RaceResults.append(etree.fromstring("<RaceTime>0</RaceTime>"))
        RaceResults.append(etree.fromstring("<MechFailRate>1</MechFailRate>"))
        RaceResults.append(etree.fromstring("<DamageMult>"+str(comp.DamageMult)+"</DamageMult>"))
        RaceResults.append(etree.fromstring("<FuelMult>"+str(comp.FuelMult)+"</FuelMult>"))
        RaceResults.append(etree.fromstring("<TireMult>"+str(comp.TireMult)+"</TireMult>"))
        #RaceResults.append(etree.fromstring("<VehiclesAllowed>|GTE|LMP2</VehiclesAllowed>"))
        RaceResults.append(etree.fromstring("<ParcFerme>3</ParcFerme>"))
        RaceResults.append(etree.fromstring("<FixedSetups>0</FixedSetups>"))
        RaceResults.append(etree.fromstring("<FreeSettings>11</FreeSettings>"))
        RaceResults.append(etree.fromstring("<FixedUpgrades>0</FixedUpgrades>"))
        Practice = etree.Element("Practice1")
        RaceResults.append(Practice)
        Practice.append(etree.fromstring("<DateTime>"+str(comp.end_time)+"</DateTime>"))
        Practice.append(etree.fromstring("<TimeString>"+datetime.datetime.utcfromtimestamp(comp.end_time).strftime('%Y/%m/%d %H:%M:%S')+"</TimeString>"))
        Practice.append(etree.fromstring("<Laps>1</Laps>"))
        Practice.append(etree.fromstring("<Minutes>10</Minutes>"))
        Practice.append(etree.Element("Stream"))
        Practice.append(etree.fromstring("<MostLapsCompleted>1</MostLapsCompleted>"))

        compounds_set = set()
        for r in comp_results:
            if "-" in r.compounds:
                front_compound, rear_compound = r.compounds.split("-")
            else:
                front_compound = rear_compound = r.compounds
            compounds_set.add(front_compound)
            compounds_set.add(rear_compound)

        compounds_list = list(compounds_set)

        for i, r in enumerate(comp_results, 1):
            Driver = etree.Element("Driver")
            Driver.append(etree.fromstring("<Name>"+r.driver_id.name+"</Name>"))
            Driver.append(etree.fromstring("<Connected>1</Connected>"))
            #Driver.append(etree.fromstring("<Connected>1</Connected>"))
            Driver.append(etree.fromstring("<VehFile>VehFile.VEH</VehFile>"))
            Driver.append(etree.fromstring("<UpgradeCode>00000000 00000000 00000000 00000000</UpgradeCode>"))

            VehName = etree.Element("VehName")
            VehName.text = r.CarType+" #"+r.VehicleNumber
            Driver.append(VehName)

            Category = etree.Element("Category")
            Category.text = r.Category
            Driver.append(Category)

            CarType = etree.Element("CarType")
            CarType.text = r.CarType
            Driver.append(CarType)

            CarClass = etree.Element("CarClass")
            CarClass.text = r.CarClass
            Driver.append(CarClass)

            VehicleNumber = etree.Element("CarNumber")
            VehicleNumber.text = r.VehicleNumber
            Driver.append(VehicleNumber)

            TeamName = etree.Element("TeamName")
            TeamName.text = r.TeamName
            Driver.append(TeamName)

            Driver.append(etree.fromstring("<isPlayer>1</isPlayer>"))
            Driver.append(etree.fromstring("<ServerScored>1</ServerScored>"))
            Driver.append(etree.fromstring("<Position>"+str(i)+"</Position>"))
            Driver.append(etree.fromstring("<ClassPosition>"+str(i)+"</ClassPosition>"))
            Driver.append(etree.fromstring("<Points>0</Points>"))
            Driver.append(etree.fromstring("<ClassPoints>0</ClassPoints>"))
            Driver.append(etree.fromstring("<LapRankIncludingDiscos>"+str(i)+"</LapRankIncludingDiscos>"))

            if "-" in r.compounds:
                front_compound, rear_compound = r.compounds.split("-")
            else:
                front_compound = rear_compound = r.compounds

            if front_compound not in compounds_list:
                compounds_list.append(front_compound)
            if rear_compound not in compounds_list:
                compounds_list.append(rear_compound)

            if compounds_list:
                front_compound_index = compounds_list.index(front_compound)
                rear_compound_index = compounds_list.index(rear_compound)
            else:
                front_compound_index = 0
                rear_compound_index = 0
                front_compound = "0"
                rear_compound = "0"

            Lap = etree.Element("Lap", attrib={
                "num": "1",
                "p": str(i),
                "et": "--.---",
                "fuel": "1",
                "twfl": "1",
                "twfr": "1",
                "twrl": "1",
                "twrr": "1",
                "fcompound": str(front_compound_index)+","+front_compound,
                "rcompound": str(rear_compound_index)+","+rear_compound,
                "s1": str(r.s1),
                "s2": str(r.s2),
                "s3": str(r.s3),
                })
            Lap.text = str(r.lap_time)
            Driver.append(Lap)

            Driver.append(etree.fromstring("<BestLapTime>"+str(r.lap_time)+"</BestLapTime>"))
            Driver.append(etree.fromstring("<Laps>1</Laps>"))
            Driver.append(etree.fromstring("<Pitstops>0</Pitstops>"))
            Driver.append(etree.fromstring("<FinishStatus>Finished Normally</FinishStatus>"))
            Driver.append(etree.fromstring('<ControlAndAids startLap="1" endLap="2">'+(r.aids or "PlayerControl")+'</ControlAndAids>'))

            Practice.append(Driver)

        #driver_tag.insert(driver_tag.index(laps_tag), etree.XML("<FinishTime>"+str(finish_time)+"</FinishTime>"))

        with open(os.path.join(current.session.r2la_options.paths[0], (comp.name+'_.xml').replace("#", "")), 'w', encoding="utf-8") as f:
            out = etree.tostring(root,method="html", encoding="unicode")
            out = header + out
            f.write(out)

    def change_name(self, pos, old_name, new_name):
        for driver_tag in self.session.findall('Driver'):
            name_tag = driver_tag.find('Name')
            if name_tag.text == old_name:
                name_tag.text = new_name
                break

    def change_team_name(self, driver_name, new_value):
        for driver_tag in self.session.findall('Driver'):
            name_tag = driver_tag.find('Name')
            if name_tag.text == driver_name:
                team_name_tag = driver_tag.find('TeamName')
                team_name_tag.text = new_value
                break

    def change_car_class(self, driver_name, new_value):
        for driver_tag in self.session.findall('Driver'):
            name_tag = driver_tag.find('Name')
            if name_tag.text == driver_name:
                car_class_tag = driver_tag.find('CarClass')
                car_class_tag.text = new_value
                break

    def change_finish_status(self, name, finish_status):
        for driver_tag in self.session.findall('Driver'):
            name_tag = driver_tag.find('Name')
            if name_tag.text == name:
                status_tag = driver_tag.find('FinishStatus')
                if finish_status == 'Finished':
                    finish_status = 'Finished Normally'
                if finish_status in ('DQ', 'Finished Normally'):
                    status_tag.text = finish_status
                else:
                    status_tag.text = 'DNF'
                    status_tag_index = list(driver_tag).index(status_tag)
                    driver_tag.insert(status_tag_index+1, etree.XML("<DNFReason>"+finish_status+"</DNFReason>"))
                break

    def change_laps(self, name, laps):
        for driver_tag in self.session.findall('Driver'):
            name_tag = driver_tag.find('Name')
            if name_tag.text == name:
                laps_tag = driver_tag.find('Laps')
                laps_tag.text = str(laps)
                break

    def change_finish_time(self, name, finish_time):
        for driver_tag in self.session.findall('Driver'):
            name_tag = driver_tag.find('Name')
            if name_tag.text == name:
                if not finish_time:
                    finish_time = 0
                finish_time_tag = driver_tag.find('FinishTime')
                if finish_time_tag is None:
                    laps_tag = driver_tag.find('Laps')
                    driver_tag.insert(list(driver_tag).index(laps_tag), etree.XML("<FinishTime>"+str(finish_time)+"</FinishTime>"))
                else:
                    finish_time_tag.text = str(finish_time)
                break

    def change_position_tag(self, name, position):
        for driver_tag in self.session.findall('Driver'):
            name_tag = driver_tag.find('Name')
            if name_tag.text == name:
                position_tag = driver_tag.find('Position')
                position_tag.text = str(position)
                break

    def add_r2la_penalty(self, name, time):
        for driver_tag in self.session.findall('Driver'):
            name_tag = driver_tag.find('Name')
            if name_tag.text == name:
                r2la_penalty_tag = driver_tag.find('r2la_penalty')
                if r2la_penalty_tag is None:
                    out_tag = etree.XML("<r2la_penalty>"+str(time)+"</r2la_penalty>")
                    driver_tag.insert(list(driver_tag).index(name_tag), out_tag)
                else:
                    r2la_penalty_tag.text = r2la_penalty_tag.text+","+str(time)
                break

    def change_position(self, name, new_position, event):
        last_pos = event.race_info['Competitors_no_dns']
        pos = event.race_info['finish_positions'][name]
        if new_position > pos:
            # all positions below this move up 1 spot
            for i in range(pos+1, new_position+1):
                self.change_position_tag(name=event.race_info[i]['Name'], position=i-1)
            self.change_position_tag(name=event.race_info[pos]['Name'], position=new_position)
        else:
            # moving up
            for i in range(new_position, pos):
                self.change_position_tag(name=event.race_info[i]['Name'], position=i+1)
            self.change_position_tag(name=event.race_info[pos]['Name'], position=new_position)
