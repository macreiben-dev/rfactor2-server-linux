class Class:
    def __init__(self, drivers):
        self.drivers = drivers

    def getClassRaceInfo(self, event):
        finish_positions = [event.race_info['finish_positions'][name] for name in self.drivers if event.race_info['finish_positions'].get(name)]
        finish_positions.sort()
        self.raceinfo = {i: event.race_info[p] for i, p in enumerate(finish_positions, 1)}
        return self.raceinfo

    def get_class_pole(self, event):
        start_positions = {name: event.race_info['start_positions'][name] for name in self.drivers if event.race_info['start_positions'].get(name)}
        if start_positions:
            start_positions = sorted(start_positions, key=start_positions.get)
            return event.race_info[event.race_info['finish_positions'][start_positions[0]]  ]
        else:
            return None

    def get_class_start_positions(self, event):
        start_positions = {name: event.race_info['start_positions'][name] for name in self.drivers if event.race_info['start_positions'].get(name)}
        out = {}
        p = 1
        for name in sorted(start_positions, key=start_positions.get):
            out[name] = p
            p += 1
        return out

    def getClassRaceInfo_on_lap(self, event, lap):

        lap_positions = {event.race_info['finish_positions'][name]: event.race_info[event.race_info['finish_positions'][name]]['positions'][lap-1] for name in self.drivers if event.race_info['finish_positions'].get(name) and len(event.race_info[event.race_info['finish_positions'][name]]['positions'])>=lap}

        race_info_on_lap = {lap_pos: event.race_info[fin_pos] for fin_pos, lap_pos in lap_positions.items()}

        #for p, info in race_info_on_lap.items():
        #    print(p, info['Name'])

        return race_info_on_lap


    """
    def getRacePos(self, name, event):
        #if not hasattr(self, 'raceinfo'): self.getClassRaceInfo(event)
        self.getClassRaceInfo(event)
        for i in range(1, len(self.raceinfo)+1):
            if name==self.raceinfo[i]['Name']: return i
        return 0

    def clearDrivers(self):
        self.drivers=[]

    def addDriver(self, name):
        self.drivers.append(name)

    def removeDriver(self, name):
        self.drivers.remove(name)

    def getPole(self, event):
        start_pos=[int(event.results.info[p]['StartPosition']) for p in self.positions]
        min_pos=min(start_pos)
        ind=start_pos.index(min_pos)
        name=self.drivers[ind]
        pos=event.results.info['finish_positions'][name]
        return {'time':event.results.info[pos]['QualificationTime'], 'name':event.results.info[pos]['Name']}
    """
