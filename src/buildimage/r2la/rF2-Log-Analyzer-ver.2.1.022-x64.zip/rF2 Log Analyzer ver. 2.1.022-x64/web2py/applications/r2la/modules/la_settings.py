from gluon import *
import os
import fnmatch
import datetime
import traceback
import json
import la_core

def save_settings():
    try:
        root = get_root()

        settings_path = os.path.join(root, "r2la_settings.json")

        db = current.db

        data = {}
        data['tracks_connected'] = db(db.tracks_connected.id>0).select(db.tracks_connected.name, db.tracks_connected.connected_to).as_list()
        data['championships'] = db(db.championship.id>0).select(orderby=db.championship.id).as_list()
        data['races'] = db(db.race.id>0).select(orderby=db.race.id).as_list()
        data['classes'] = db(db.classes.id>0).select(orderby=db.classes.id).as_list()
        data['teams'] = db(db.team.id>0).select(orderby=db.team.id).as_list()
        data['user_points_presets'] = db(db.user_points_preset.id>0).select(orderby=db.user_points_preset.id).as_list()
        data['paths'] = current.session.r2la_options.paths
        data['custom_js_links'] = current.session.r2la_options.custom_js_links
        data['track_country'] = db(db.track_country.id>0).select().as_list()

        data['timetrials'] = db(db.timetrial.id>0).select(orderby=db.timetrial.id).as_list()
        data['tt_events'] = db(db.tt_event.id>0).select(orderby=db.tt_event.id).as_list()

        with open(settings_path, 'w', encoding='utf-8') as f:
            f.write(json.dumps(data, ensure_ascii=False, sort_keys=True, indent=4))

    except:
        print (traceback.format_exc())


def load_settings():
    db = current.db
    try:
        root = get_root()

        settings_path = os.path.join(root, "r2la_settings.json")
        if os.path.exists(settings_path):
            with open(settings_path, encoding="utf-8") as f:
                try:
                    opened_file_str = f.read()
                except UnicodeDecodeError:
                    with open(settings_path, encoding="cp1252") as f2:
                        opened_file_str = f2.read()
            
            settings = json.loads(opened_file_str)

            if settings.get('tracks_connected'):
                db.tracks_connected.truncate()
                
                need_to_import_logs = False
                for t in settings['tracks_connected']:
                    t1 = db(db.track.name==t['name']).select(db.track.id).first()
                    t2 = db(db.track.name==t['connected_to']).select(db.track.id).first()
                    if t1 and t2:
                        need_to_import_logs = True
                        db.tracks_connected.insert(name=t['name'], connected_to=t['connected_to'])
                    else:
                        print("Track connection not imported. Track '"+t['name']+"' or '"+t['connected_to']+"' not found.")
                
                if need_to_import_logs:
                    la_core.import_logs(clear_tracks=True)

            if settings.get('user_points_presets'):
                db.user_points_preset.truncate()
                for i in settings['user_points_presets']:
                    if 'championships_pts_fastest_lap' in i['points']:
                        i['points']['championship_pts_fastest_lap'] = i['points'].pop('championships_pts_fastest_lap')
                    if 'championships_pts_for_all' in i['points']:
                        i['points']['championship_pts_for_all'] = i['points'].pop('championships_pts_for_all')
                    if 'championships_pts_lead_max_laps' in i['points']:
                        i['points']['championship_pts_lead_max_laps'] = i['points'].pop('championships_pts_lead_max_laps')
                    if 'championships_pts_lead_one_lap' in i['points']:
                        i['points']['championship_pts_lead_one_lap'] = i['points'].pop('championships_pts_lead_one_lap')
                    if 'championships_pts_pole' in i['points']:
                        i['points']['championship_pts_pole'] = i['points'].pop('championships_pts_pole')

                    db.user_points_preset.insert(name=i['name'], points=i['points'])

            if settings.get('track_country'):
                load_countries()
                for i in settings['track_country']:
                    del i['id']
                    if not db(db.track_country.track==i['track']).select().first():
                        db.track_country.insert(**i)

            if settings.get('classes'):
                db.classes.truncate()
                for i in settings['classes']:
                    db.classes.insert(name=i['name'])

            if settings.get('teams'):
                db.team.truncate()
                for i in settings['teams']:
                    db.team.insert(name=i['name'])

            cids = {}
            if settings.get('championships'):
                db.championship.truncate()
                for i in settings['championships']:
                    old = i['id']
                    del i['id']
                    i['points'] = {int(k): v for k, v in i['points'].items()}
                    cids[old] = db.championship.insert(**i)

            if settings.get('races'):
                db.race.truncate()
                for i in settings['races']:
                    del i['id']
                    i['championship_id'] = cids[i['championship_id']]
                    db.race.insert(**i)

            load_champ_ids()
            '''
            if settings.get('paths'):
                r2la_options = db(db.r2la_options.id==1).select().first()
                r2la_options.update_record(paths=settings['paths'])

            if settings.get('custom_js_links'):
                r2la_options = db(db.r2la_options.id==1).select().first()
                r2la_options.update_record(custom_js_links=settings['custom_js_links'])
            '''

            tids = {}
            if settings.get('timetrials'):
                db.timetrial.truncate()
                for i in settings['timetrials']:
                    old = i['id']
                    del i['id']
                    tids[old] = db.timetrial.insert(**i)

            if settings.get('tt_events'):
                db.tt_event.truncate()
                for i in settings['tt_events']:
                    del i['id']
                    i['timetrial_id'] = tids[i['timetrial_id']]
                    db.tt_event.insert(**i)

            save_settings()

    except:
        print (traceback.format_exc())


def load_champ_ids():
    db = current.db
    races = db(db.race.id>0).select()
    for race in races:
        if race.file_name:
            parsed_xml = db(db.parsed_xml.file_name==race.file_name).select().first()
            if parsed_xml:
                parsed_xml.update_record(cid=race.championship_id)


def load_countries():
    countries = []
    flags_path = os.path.join(os.getcwd(), 'applications/'+current.request.application+'/static/images/flags')
    file_names = fnmatch.filter(os.listdir(flags_path), '*.png')
    countries = [f[:-4] for f in file_names]

    current.db.country.truncate()
    for name in countries:
        current.db.country.insert(name=name)

    current.db.track_country.truncate()
    track_countries = [
        {'United-States': [
            'Toban RP -- Short',
            'Toban RP -- Short Reverse',
            'Toban RP -- Medium',
            'Toban RP -- Medium Reverse',
            'Toban RP -- Long',
            'Toban RP -- Long Reverse',
            'Toban RP -- 24h',
            'Sebring 12h Course',
            'Sebring 12h Course League Edition',
            'Sebring Club Course',
            'Sebring Modified Course',
            'Palm Springs Road Course B',
            'Palm Springs Road Course A',
            'Palm Springs Speedway',
            'Palm Beach Intl Road Course',
            'Palm Beach Intl Kart Track',
            'Mountain Peak -- Legends Oval',
            'Mountain Peak -- Road Course',
            'Mountain Peak -- Speedway',
            'Mountain Peak Karting -- Long',
            'Mountain Peak Karting -- Oval',
            'Mountain Peak Karting -- Reverse',
            'Mountain Peak Karting -- Short',
            'Mills Inner Loop A',
            'Mills Inner Loop B',
            'Mills Inner Loop C',
            'Mills Outer Loop A',
            'Mills Outer Loop B',
            'Mills Outer Loop C',
            'Mid-Ohio No Chicane',
            'Mid-Ohio With Chicane',
            'Mid-Ohio Miller 200',
            'Lime Rock Park -- No Chicanes',
            'Lime Rock Park -- All Chicanes',
            'Lime Rock Park -- R/C',
            'Lime Rock Park -- Uphill Chicane',
            'Lime Rock Park -- West Bend Chicane',
            'Joesville Speedway',
            'Jacksonville Superspeedway',
            'Indianapolis -- 2014 GP',
            'Indianapolis -- 2013 GP',
            'Indianapolis -- Oval',
            'Indianapolis -- 2007 GP',
            'Indianapolis -- Brickyard',
            'Indianapolis Grand Prix',
            'Indianapolis Grand Prix 2007',
            'Indianapolis Road Course',
            'Eagle Creek Speedway',
            'Circuit of the Americas -- Grand Prix',
            'Circuit of the Americas -- Track Day',
            'Brookdale Speedway',
            'AtlantaMP -- Race Track',
            'AtlantaMP -- Kart Layout A',
            'AtlantaMP -- Kart Layout B',
            'AtlantaMP -- Kart Layout B +',
            'AtlantaMP -- Kart Layout C',
            'Apple Valley Speedway',
            'Apple Valley Interior Course',
            'Apple Valley Sports Car Course',
            'Alabama Superspeedway',
            'Louisiana -- Indy Grand Prix',
            'NolaMP -- A - Course',
            'NolaMP -- B - Course',
            'NolaMP -- C - Course',
            'NolaMP -- D - Course',
            'NolaMP -- KART - A',
            'NolaMP -- KART - B',
            'NolaMP -- KART - C',
            'NolaMP -- KART - D',
            'NolaMP -- KART - E',
            'Sebring -- Full Layout',
            'Sebring -- 12 Hour Road Course',
            'Sebring -- School',
            'Sebring -- Johnson Club',
            'Portland International Raceway Chicane',
            'Road Atlanta 2017',
            'Watkins Glen Chicane',
            'Lester Formula E',
            'Lester -- LesterGP',
            'Lester -- LesterSprint',
            'Portland Full Course',
            'Portland Sprint Course',
            'Bridgehampton',
            'New York Formula E',
            'Daytona International Road Course',
            'Daytona International Speedway',
            'Laguna Seca',
            'Long Beach GP Street Circuit',
            ]},
        {'United-Kingdom': [
            'TigerMoth -- R1',
            'TigerMoth -- R2',
            'TigerMoth -- R3',
            'TigerMoth -- TT -- Training',
            'TigerMoth -- TestTrack',
            'Silverstone -- National Layout',
            'Silverstone -- Endurance',
            'Silverstone -- Historic Chicane Circuit',
            'Silverstone -- GT Layout',
            'Silverstone -- International Layout',
            'Silverstone GP [1975]',
            'Croft -- Road Course',
            'Oulton Park International',
            'Brands Hatch GP',
            'Brands Hatch Indy',
            'Donington GP',
            'Donington National',
            'Silverstone National',
            'Silverstone International',
            'Silverstone Historic Chicane',
            'Silverstone Grand Prix',
            'Silverstone Endurance',
            'London Formula E',
            'Croft',
            'Thruxton',
            ]},
        {'Brazil': [
            'SaoPaulo GP',
            'Interlagos',
            'Autodromo Guapore',
            ]},
        {'Italy': [
            'Mores -- Short Layout',
            '1966 Brianza',
            'Brianza 10K',
            'Brianza Junior',
            'Monza Grand Prix',
            'RaceRfactor Monza 2014',
            'Imola 2001',
            'Imola 1988',
            'Imola 2018',
            'Imola 1972',
            'Adria Full Circuit',
            'Rome',
            'Monza',
            'Monza Curva Grande',
            'Monza Junior',
            'Rome Formula E',
            ]},
        {'Canada': [
            'Monreal GP',
            'Mosport Park',
            'Canadian Tire Motorsport Park (after 2013)',
            'RaceRfactor Montreal 2013',
            ]},
        {'Monaco': [
            '1966 Monte Carlo',
            'Monaco',
            'Monaco Formula E',
            "Circuit d'Azur",
            ]},
        {'Japan': [
            'Matsusaka West Circuit',
            'Matsusaka East Circuit',
            'Matsusaka Grand Prix Circuit',
            'Matsusaka International Circuit',
            'Matsusaka Intl -- Old Chicane',
            'Matsusaka Intl -- West Chicane',
            'Matsusaka Motorcycle Circuit',
            'Matsusaka West - West Chicane',
            'Matsusaka Intl - Old Chicane',
            'Okayama 2017',
            ]},
        {'Malaysia': [
            'Malaysian South Loop',
            'Malaysian North Loop',
            'Malaysia North Loop',
            'Malaysia South Loop',
            'Malaysian Full Loop',
            ]},
        {'Australia': [
            'Longford 1967 (historic grid)',
            'Longford 1967',
            'Bathurst',
            'Barbagallo',
            'Adelaide Street Circuit',
            ]},
        {'Scotland': [
            'Loch Drummond -- Long Layout',
            'Loch Drummond -- Short Layout'
            ]},
        {'France': [
            'LeMans91',
            'Nogaro',
            'Le Mans 24h',
            'Rouen-Les-Essarts 1955-70',
            'Rouen-Les-Essarts 1974-94',
            '24 Heures du Mans 2018',
            '24 Heures du Mans 2020',
            '24 Heures du Mans 2022',
            ]},
        {'Belgium': [
            'Belgium',
            'Spa Francorchamps',
            'Spa-Francorchamps',
            'Spa-Francorchamps Endurance',
            ]},
        {'Portugal': [
            'Portugal GT Layout',
            'Portugal GP Layout',
            'Autdromo Internacional do Algarve Circuit 1',
            'Autdromo Internacional do Algarve Circuit 6'
            ]},
        {'Germany': [
            'Nuerburg Ring GP',
            'Nuerburg Ring Sprint',
            'HockenheimRing GP',
            'Norisring',
            'Nurburgring -- Grand Prix',
            'Nurburgring -- Grand Prix No Chicane',
            'Nurburgring -- 24h',
            'Nurburgring -- 24h Support',
            'Nurburgring -- Combined',
            'Nurburgring -- Endurance Series',
            'Nurburgring -- Nordschleife',
            'Nurburgring -- Sprint',
            'Nurburgring -- Sprint No Chicane',
            'Berlin Formula E',
        ]},
        {'Netherlands': [
            'Zandvoort',
            'Zandvoort GP Chicane',
            'Zandvoort GP',
            'Zandvoort 67',
            'Zandvoort 65',
            'Zandvoort Club',
            'Zandvoort National',
            'Zandvoort East',
            'Zandvoort 2020',
            'Maastricht 24h',
        ]},
        {'Hong-Kong': [
            'Hong Kong Formula E',
        ]},
        {'Hungary': [
            'Hungaroring 2017',
        ]},
        {'Austria': [
            'Red Bull Ring GP',
        ]},
        {'Turkey': [
            'Istanbul Grand Prix Circuit',
        ]},
        {'Finland': [
            'Botniaring Short',
            'Botniaring Long',
            'Botniaring Long w/chicane',
        ]},
        {'Thailand': [
            'Buriram International Circuit',
        ]},
        {'New-Zealand': [
            'Manfeild GP Circuit',
            'Highlands Motorsport Park',
            'Teretonga Park',
            'Hampton Downs National',
            'Pukekohe Park',
            'Pukekohe Park Raceway',
        ]},
        {'Ecuador': [
            'Autodromo Yahuarocha',
            'Autodromo Yahuarocha Reverse',
        ]},
        {'Saudi-Arabia': [
            'Diriyah Formula E',
        ]},
        {'Bahrain': [
            'Bahrain GP 2014',
            'Bahrain',
            'Bahrain Endurance',
            'Bahrain Outer',
            'Bahrain Paddock',
        ]},
    ]

    for tc_dict in track_countries:
        country, tracks = list(tc_dict.items())[0]
        for track in tracks:
            current.db.track_country.insert(track=track, country=country)


def get_root():
    # returns path to dir that contains web2py
    # os.getcwd() - returns path to web2py dir
    return os.path.dirname(os.getcwd())