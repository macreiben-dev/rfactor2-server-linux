import datetime
import traceback
import itertools
import collections
import xml.etree.ElementTree as etree 
import re
#import unicodedata

hardcoded_categories = {'Palatov Motorsport': 1}


# OrderedSet from http://code.activestate.com/recipes/576694/
# Created by Raymond Hettinger and licensed under MIT.
class OrderedSet(collections.abc.MutableSet):
    def __init__(self, iterable=None):
        self.end = end = []
        end += [None, end, end]         # sentinel node for doubly linked list
        self.map = {}                   # key --> [key, prev, next]
        if iterable is not None:
            self |= iterable

    def __len__(self):
        return len(self.map)

    def __contains__(self, key):
        return key in self.map

    def add(self, key):
        if key not in self.map:
            end = self.end
            curr = end[1]
            curr[2] = end[1] = self.map[key] = [key, curr, end]

    def discard(self, key):
        if key in self.map:
            key, prev, next = self.map.pop(key)
            prev[2] = next
            next[1] = prev

    def __iter__(self):
        end = self.end
        curr = end[2]
        while curr is not end:
            yield curr[0]
            curr = curr[2]

    def __reversed__(self):
        end = self.end
        curr = end[1]
        while curr is not end:
            yield curr[0]
            curr = curr[1]

    def pop(self, last=True):
        if not self:
            raise KeyError('set is empty')
        key = self.end[1][0] if last else self.end[2][0]
        self.discard(key)
        return key

    def __repr__(self):
        if not self:
            return '%s()' % (self.__class__.__name__,)
        return '%s(%r)' % (self.__class__.__name__, list(self))

    def __eq__(self, other):
        if isinstance(other, OrderedSet):
            return len(self) == len(other) and list(self) == list(other)
        return set(self) == set(other)


def importXML(xml_string, qual_info=None, player_names=None):
    player_names = player_names or []
    """
    In: xml_qual, xml_race - strings (f.read()),
        player_names - [rf2_path.player_name, rf2_path.player_nick]
    Out: info - dictionary

    info['ServerName'] - string or ''
    info['Mod'] - string or None
    info['Game_version'] - string or None
    info['Track_name'] - string or None
    info['Track_length'] - string or None
    info['session'] = string, one of 'Race', 'Qualify', 'Practice1', 'TestDay', 'Warmup'
    info['MechFailRate'] - string or None
    info['DamageMult'] - string or None
    info['FuelMult'] - string or None
    info['TireMult'] - string or None

    info['DateTime'] - datetime converted from <TimeString>2013/11/07 20:26:23</TimeString>
    info['timestamp'] - string, timestamp

    info['racechat'] - list of strings
    info['incidents'] - list of strings

    info['qualydict'] - dict == info['qualydict']

    info['racedrlist'] - list of strings, driver names by finish position

    info['most_laps_complited'] - int, <MostLapsCompleted>
    info[1...N] - driver data dict, according to finish position
    """

    # http://lxml.de/parsing.html
    # lxml.etree.fromstring accepts Unicode
    # but rfactor2 outputs in .xml non UTF-8 characters for some reason, but declares itself valid UTF-8
    # so [39:] is here to skip this declaration.
    """
    iso_pattern = re.compile("ISO-8859-1")
    if iso_pattern.search(xml_string, endpos=150):
        # for automobilista or other logs with ISO-8859-1
        prepared_xml_string = str(xml_string)[44:]
    else:
        # default logs with UTF-8
        prepared_xml_string = str(xml_string)[39:]
    #xml_qual = unicodedata.normalize('NFKD', unicode(xml_qual))[39:]
    """
    prepared_xml_string = xml_string
    # rfactor2 sometimes puts junk symbol at the end of .xml
    try:
        xmllog = etree.fromstring(prepared_xml_string)
    except: # etree.XMLSyntaxError:
        #print (traceback.format_exc())
        xmllog = etree.fromstring(prepared_xml_string[:-1])

    info = {}
    RaceResults = xmllog.find('RaceResults')

    # do not change this list oreder
    possible_sessions = [
        'Race', 'Race2', 'Race3', 'Qualify', 'Qualify2', 'Qualify3',
        'Practice1', 'Practice2', 'Practice3', 'Practice4', 'TestDay', 'Warmup', 'TimeTrial'
    ]
    session = [RaceResults.find(s) for s in possible_sessions if RaceResults.find(s) is not None][0].tag

    info['session_index'] = possible_sessions.index(session)

    ServerName = RaceResults.find('ServerName')
    if ServerName is not None:
        info['ServerName'] = ServerName.text
    else:
        info['ServerName'] = ''

    info['Mod'] = RaceResults.find('Mod').text
    info['GameVersion'] = RaceResults.find('GameVersion').text
    info['has_tire_wear'] = False
    try:
        if int(info['GameVersion'].split('.')[1]) > 1014:
            info['has_tire_wear'] = True
    except:
        pass
    info['TrackCourse'] = RaceResults.find('TrackCourse').text # Track_name
    info['TrackLength'] = RaceResults.find('TrackLength').text
    info['Dedicated'] = int(RaceResults.find('Dedicated').text)


    if session in ('Race2', 'Race3'):
        info['session'] = 'Race'
    else:
        info['session'] = session
    info['MechFailRate'] = RaceResults.find('MechFailRate').text
    info['DamageMult'] = RaceResults.find('DamageMult').text
    info['FuelMult'] = RaceResults.find('FuelMult').text
    info['TireMult'] = RaceResults.find('TireMult').text

    info['weekend_ts'] = RaceResults.find('DateTime').text

    current_session = RaceResults.find(session)
    info['DateTime'] = datetime.datetime.strptime(current_session.find('TimeString').text, '%Y/%m/%d %H:%M:%S')
    info['session_ts'] = current_session.find('DateTime').text # timestamp

    FormationAndStart = current_session.find('FormationAndStart')
    if FormationAndStart is not None:
        info['FormationAndStart'] = int(FormationAndStart.text)
    else:
        info['FormationAndStart'] = 0
    '''
    0 - Standing
    1 - Formation/Standing
    2 - Rolling
    4 - Fast Rolling
    '''

    info['most_laps_complited'] = int(current_session.find('MostLapsCompleted').text)

    session_Laps = current_session.find('Laps')
    if session_Laps is not None:
        info['session_Laps'] = int(session_Laps.text)
    else:
        info['session_Laps'] = 0
    session_Minutes = current_session.find('Minutes')
    if session_Minutes is not None:
        info['session_Minutes'] = int(session_Minutes.text)
    else:
        info['session_Minutes'] = 0

    Stream = current_session.find('Stream')

    info['racechat'] = [str(datetime.timedelta(seconds=float(chat.get('et'))))[:9] + " " + chat.text \
                        for chat in Stream.findall('Chat') if chat.text]

    incidents = Stream.findall('Incident')
    driver_immovable_count = collections.Counter()
    info['incidents'] = []
    for inc in incidents:
        if "reported" in inc.text and "Immovable" in inc.text:
            inc_driver = inc.text.split("reported")[0]
            if driver_immovable_count[inc_driver] < 100:
                driver_immovable_count[inc_driver] += 1
                info['incidents'].append(str(datetime.timedelta(seconds=float(inc.get('et'))))[:9] + " " + inc.text)
        else:
            info['incidents'].append(str(datetime.timedelta(seconds=float(inc.get('et'))))[:9] + " " + inc.text)

    #info['incidents'] = [str(datetime.timedelta(seconds=float(inc.get('et'))))[:9] + " " + inc.text \
    #                     for inc in Stream.findall('Incident')]

    info['penalties'] = [str(datetime.timedelta(seconds=float(p.get('et'))))[:9] + " " + p.text.split(',')[0] + " for" + p.text.split('for', 1)[1].split('.')[0] \
                         if "for" in p.text else str(datetime.timedelta(seconds=float(p.get('et'))))[:9] + " " + p.text.split(',')[0] \
                         for p in Stream.findall('Penalty')]

    #info['qualydict'] = qualydict

    player_position = 0
    racedrdict = {}
    racedrlist = []

    '''
    discarded_records = []
    found_minus_one = False
    for driver_tag in current_session.findall('Driver'):
        Name = driver_tag.find('Name').text
        if Name in racedrlist:
            if session in ['Practice1', 'TestDay']:
                discarded_records.append((Name, driver_tag))
            continue
        racedrlist.append(Name)
        Position = int((driver_tag.find('Position')).text)

        if found_minus_one == True and Position > 0:
            Position = racedrlist.index(Name) + 1
        if Position < 0:
            found_minus_one = True
            Position = racedrlist.index(Name) + 1

        racedrdict[Position] = (Name, driver_tag)

        last_position = Position

    if session in ['Practice1', 'TestDay']:
        for r in discarded_records:
            last_position += 1
            racedrdict[last_position] = r
    '''
    found_minus_one = False
    noname_driver_index = 1
    same_driver_names = set()
    for driver_tag in current_session.findall('Driver'):
        name_element = driver_tag.find('Name')
        if not name_element.text:
            name_element.text = "Noname Driver" + str(noname_driver_index)
            noname_driver_index += 1
        Name = name_element.text
        '''
        tPosition = int((driver_tag.find('Position')).text)
        if tPosition < 1:
            print (info['DateTime'], info['session'])
        '''
        if Name in racedrlist:
            same_driver_names.add(Name)
            continue
        racedrlist.append(Name)
        Position = int((driver_tag.find('Position')).text)

        if found_minus_one == True and Position > 0:
            Position = racedrlist.index(Name) + 1
        if Position < 0:
            found_minus_one = True
            Position = racedrlist.index(Name) + 1

        racedrdict[Position] = (Name, driver_tag)


    racedrlist = [racedrdict[pos][0] for pos in sorted(racedrdict)]
    driver_objects = [racedrdict[pos][1] for pos in sorted(racedrdict)]

    info['racedrlist'] = racedrlist

    if len(driver_objects) > 0:
        Laps1 = int(driver_objects[0].find('Laps').text)

    fast_laps = 0
    raceduration = True
    i = -1
    human_drivers_num = 0
    for i, xmldriver in enumerate(driver_objects):
        Name = xmldriver.find('Name').text

        if Name in player_names:
            player_position = i + 1

        CarType = xmldriver.find('CarType').text or 'EmptyCarType'
        CarClass = xmldriver.find('CarClass').text or ''
        TeamName = xmldriver.find('TeamName').text or ''
        isPlayer = int(xmldriver.find('isPlayer').text)
        human_drivers_num += isPlayer

        ind = xmldriver.find('Category')
        if ind is not None:
            category0 = ind.text.split(',')[0]
            c_ind = hardcoded_categories[category0] if category0 in hardcoded_categories else 0
            Category = ind.text.split(',')[c_ind].strip()
        else:
            Category = CarType

        VehicleNumber = xmldriver.find('CarNumber').text or ''
        VehName = xmldriver.find('VehName').text

        ind = xmldriver.find('FinishStatus').text
        if ind == 'Finished Normally':
            FinishStatus = 'Finished'
        elif ind == 'DNF':
            FinishStatus = xmldriver.find('DNFReason').text
        elif ind == 'DQ':
            FinishStatus = 'DQ'
        elif ind == 'None':
            FinishStatus = 'DNF'

        Laps = int(xmldriver.find('Laps').text)
        if Laps < 0:
            Laps = 1

        ind = xmldriver.find('FinishTime')
        if ind is not None:
            RaceDuration = float(ind.text)
            # fix for <FinishTime>-340282346638528860000000000000000000000.0000</FinishTime>
            if float(RaceDuration) < 0:
                RaceDuration = None
        else:
            RaceDuration = None

        LapsGap = Laps1 - Laps

        ind = xmldriver.find('GridPos')
        if ind is not None:
            StartPosition = int(xmldriver.find('GridPos').text)
        else:
            StartPosition = 0

        FinishPosition = int(xmldriver.find('Position').text)

        ind = xmldriver.find('BestLapTime')
        if ind is not None and Laps > 0:
            fast_laps += 1
            FastestLap = float(ind.text)
            FastestLapText = ind.text
        else:
            FastestLap = None
            FastestLapText = ''

        #QualificationTime = None

        Pitstops = int(xmldriver.find('Pitstops').text)

        ind = xmldriver.find('PenaltyMass')
        if ind is not None:
            PenaltyMass = round(float(ind.text), 1)
        else:
            PenaltyMass = 0

        drracelaps = []
        LapsLed = 0
        pitin_pitout = []
        lap_elements = xmldriver.findall('Lap')
        fastest_lap_num = 0
        for lap_num, lap in enumerate(lap_elements, 1):
            if lap.text:
                if lap.text != '--.----':
                    drracelaps.append(float(lap.text))
                    if FastestLapText == lap.text:
                        fastest_lap_num = lap_num
                else:
                    drracelaps.append(0)

                if lap.get('p') == '1':
                    LapsLed += 1

                if session != "Race":
                    if lap_num == 0 and lap.text != '--.----':
                        pitin_pitout.append(1)
                    if lap.text == '--.----':
                        pitin_pitout.append(int(lap.get('num')))
                if lap.get('pit') == '1':
                    pitin_pitout.append(int(lap.get('num')))
                    if int(lap.get('num')) < Laps:
                        pitin_pitout.append(int(lap.get('num'))+1)
            else:
                drracelaps.append(0)

        drracesectors = [[lap.text or 0,
                          float(lap.get('s1') or 0),
                          float(lap.get('s2') or 0),
                          float(lap.get('s3') or 0),
                          float(lap.get('fuel') or 0),
                          float(lap.get('twfl') or 0),
                          float(lap.get('twfr') or 0),
                          float(lap.get('twrl') or 0),
                          float(lap.get('twrr') or 0),
                          float(lap.get('et') or 0) if lap.get('et') != '--.---' else 0] for lap in lap_elements]

        positions = [int(lap.get('p') or 0) for lap in lap_elements]

        # new format - fcompound="0,Bias-Ply" rcompound="0,Bias-Ply"
        # old format - fcompound="0" rcompound="0"
        compounds_bylap = [(lap.get('fcompound').split(',')[0], lap.get('rcompound').split(',')[0]) \
                           if (lap.get('fcompound') and lap.get('rcompound')) else ('0','0') for lap in lap_elements] or [("0", "0")]
        compounds = list(OrderedSet(itertools.chain.from_iterable(compounds_bylap)))
        try:
            compounds_str_bylap = [(lap.get('fcompound').split(',')[1], lap.get('rcompound').split(',')[1]) \
                                   if (lap.get('fcompound') and lap.get('rcompound')) else ('', '') for lap in lap_elements] or [('-', '-')]
            compounds_str = list(OrderedSet(itertools.chain.from_iterable(compounds_str_bylap)))
        except:
            compounds_str = [str(c) for c in compounds]
            compounds_str_bylap = compounds_bylap

        raceaids = set()
        for aids in xmldriver.findall('ControlAndAids'):
            for aid in aids.text.split(','):
                if aid not in ['PlayerControl', 'UnknownControl']:
                    raceaids.add(aid)
        raceaids = list(raceaids)

        if i == 0 and RaceDuration == None:
            raceduration = False

        if i==0:
            if not raceduration:
                lapslist = []
                for lap in drracesectors:
                    try:
                        lapslist.append(float(lap[0]))
                    except:
                        lapslist.append(0)
                RaceDuration = round(sum(lapslist), 4)
            RaceDuration1 = RaceDuration
            TimeGap = 0
        else:
            if RaceDuration:
                TimeGap = round(float(RaceDuration)-float(RaceDuration1), 4)
            else:
                TimeGap = -round(float(RaceDuration1), 4)

        swap_data = xmldriver.findall('Swap')
        swaps = {}
        swapped_drivers = set()
        if swap_data:
            for swap in swap_data:
                if swap.text:
                    swaps[int(swap.get('startLap') or 0)] = (int(swap.get('endLap') or 0), swap.text)
                    swapped_drivers.add(swap.text)

        r2la_penalties_tag = xmldriver.find('r2la_penalty')
        if r2la_penalties_tag is not None:
            r2la_penalties = [float(p) for p in r2la_penalties_tag.text.split(',')]
        else:
            r2la_penalties = []

        info[i+1] = {'Pos': i+1,
                     'Name': Name,
                     'TeamName': TeamName,
                     'Category': Category,
                     'CarType': CarType,
                     'CarClass': CarClass,
                     'VehicleNumber': VehicleNumber,
                     'FinishStatus': FinishStatus,
                     'Laps': Laps,
                     'RaceDuration': RaceDuration,
                     'TimeGap': TimeGap,
                     'LapsGap': LapsGap,
                     'StartPosition': StartPosition,
                     'FinishPosition': FinishPosition,
                     'LapsLed': LapsLed,
                     'FastestLap': FastestLap,
                     'fastest_lap_num': fastest_lap_num,
                     'QualificationTime': None,
                     'Pitstops': Pitstops,
                     'PenaltyMass': PenaltyMass,
                     'drracelaps': drracelaps,
                     'racesectors': drracesectors,
                     'aids': raceaids,
                     'pitlaps': pitin_pitout,
                     'positions': positions,
                     'VehName': VehName,
                     'compounds_bylap': compounds_bylap,
                     'compounds': compounds,
                     'compounds_str': compounds_str,
                     'compounds_str_bylap': compounds_str_bylap,
                     'isPlayer': isPlayer,
                     'swaps': swaps,
                     'swapped_drivers': swapped_drivers,
                     'r2la_penalties': r2la_penalties,
                     }

    #info['human_drivers_num'] = human_drivers_num

    #add all drivers that are in qualydrlist but not in racelist. this is DNS
    #copmetitors count must include all drivers from qual and race. watch for DNS
    
    info['same_driver_names'] = same_driver_names

    if i >= 0:
        info['Competitors'] = i + 1
    else:
        info['Competitors'] = 0

    info['Competitors_no_dns'] = info['Competitors']

    if info['Competitors'] > 0:
        info['ai_percentage'] = round((info['Competitors']-human_drivers_num) / info['Competitors'] * 100)

        #fix for most_laps_complited 0
        info['most_laps_complited'] = max([info[ind]['Laps'] for ind in range(1, info['Competitors']+1)])

        if player_position:
            info['player_Category'] = info[player_position]['Category']
            info['CarTypeGuess'] = info[player_position]['CarType']
            info['player_CarClass'] = info[player_position]['CarClass']
            info['player_TeamName'] = info[player_position]['TeamName']
        else:
            info['player_Category'] = info[1]['Category']
            info['CarTypeGuess'] = info[1]['Category']
            info['player_CarClass'] = info[1]['CarClass']
            info['player_TeamName'] = ''
        info['RaceDuration'] = info[1]['RaceDuration']
        info['player_position'] = player_position
    else:
        info['ai_percentage'] = 0
        info['player_Category'] = ''
        info['CarTypeGuess'] = ''
        info['player_CarClass'] = ''
        info['player_TeamName'] = ''
        info['RaceDuration'] = 0
        info['player_position'] = 0

    info['finish_positions'] = {}
    info['start_positions'] = {}

    for ind in range(1, info['Competitors']+1):
        info['finish_positions'][info[ind]['Name']] = ind
        info['start_positions'][info[ind]['Name']] = info[ind]['StartPosition']
        fast_laps += info[ind]['fastest_lap_num']

    if not fast_laps:
        info['most_laps_complited'] = 0

    # find session best sectors. findRaceBSectors
    sector1 = {}
    sector2 = {}
    sector3 = {}
    s1list = [10000]
    s2list = [10000]
    s3list = [10000]
    for i in range(1, info['Competitors']+1):
        name = info[i]['Name']
        if not info[i]['racesectors']:
            sector1[name] = 10000
            sector2[name] = 10000
            sector3[name] = 10000
            info[i]['bsectors'] = [10000, 10000, 10000]
            continue
        drs1 = [10000]
        drs2 = [10000]
        drs3 = [10000]
        for lap in info[i]['racesectors']:
            if lap[0] != '--.----':
                drs1.append(lap[1]) if lap[1] else drs1.append(10000)
                drs2.append(lap[2]) if lap[2] else drs2.append(10000)
                drs3.append(lap[3]) if lap[3] else drs3.append(10000)
        min1 = min(drs1)
        min2 = min(drs2)
        min3 = min(drs3)
        info[i]['bsectors'] = [min1, min2, min3]
        sector1[name] = min1
        s1list.append(min1)
        sector2[name] = min2
        s2list.append(min2)
        sector3[name] = min3
        s3list.append(min3)
    info['sector1'] = sector1
    info['sector2'] = sector2
    info['sector3'] = sector3
    info['bsectors'] = [min(s1list), min(s2list), min(s3list)]

    return info


def add_dns_to_race_info(race_info, qual_info):
    race_dr_num = race_info['Competitors']

    for name in qual_info['racedrlist']:
        if name not in race_info['racedrlist']:
            race_info['racedrlist'].append(name)
            race_dr_num += 1
            race_info['finish_positions'][name] = race_dr_num
            race_info['start_positions'][name] = race_dr_num
            race_info[race_dr_num] = {'Pos':race_dr_num,
                         'Name':name,
                         'Category': qual_info[qual_info['finish_positions'][name]]['Category'],
                         'TeamName': qual_info[qual_info['finish_positions'][name]]['TeamName'],
                         'CarType':qual_info[qual_info['finish_positions'][name]]['CarType'],
                         'CarClass':qual_info[qual_info['finish_positions'][name]]['CarClass'],
                         'VehicleNumber':qual_info[qual_info['finish_positions'][name]]['VehicleNumber'],
                         'isPlayer':qual_info[qual_info['finish_positions'][name]]['isPlayer'],
                         'FinishStatus':'DNS',
                         'Laps':0,
                         'RaceDuration':None,
                         'TimeGap':-1, # round(float(RaceDuration1), 4),
                         'LapsGap': race_info[1]['Laps'],
                         'StartPosition': race_dr_num, #qual_info['finish_positions'][name],
                         'FinishPosition': race_dr_num,
                         'LapsLed':0,
                         'FastestLap':None,
                         'fastest_lap_num': 0,
                         'QualificationTime': qual_info[qual_info['finish_positions'][name]]['FastestLap'],
                         'Pitstops':0,
                         'PenaltyMass':0,
                         'drracelaps':[],
                         'racesectors':[],
                         'aids':[],
                         'pitlaps':[],
                         'positions':[],
                         'VehName': qual_info[qual_info['finish_positions'][name]]['VehName'],
                         'compounds_bylap':[],
                         'compounds':[],
                         'compounds_str':[],
                         'compounds_str_bylap':[],
                         'swaps': [],
                         'swapped_drivers': [],
                         'bsectors': [10000, 10000, 10000]}
            race_info['sector1'][name] = 10000
            race_info['sector2'][name] = 10000
            race_info['sector3'][name] = 10000
    race_info['Competitors'] = race_dr_num

    for i in range(1, race_info['Competitors']+1):
        if race_info[i]['Name'] in qual_info['racedrlist']:
            qual_pos = qual_info['finish_positions'][race_info[i]['Name']]
            race_info[i]['QualificationTime'] = qual_info[qual_pos]['FastestLap']
