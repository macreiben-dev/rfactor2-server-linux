import collections
from la_class import Class
import la_utils
from gluon import current

CLASS_NAMES = ['main', 'class1', 'class2', 'class3', 'class4']

class Event:
    def __init__(self, race_row, championship_row, race_info, qual_info=None):
        self.race_info = race_info
        # qual_info is None if no qualy session found
        self.qual_info = qual_info
        self.race = race_row
        self.champ = championship_row
        self.out = {}

        self.drivers = None
        self.teams = None
        self.classes = None

    def getTeam(self, driver_name):
        if self.race_info['finish_positions'].get(driver_name):
            team = self.race_info[self.race_info['finish_positions'][driver_name]]['team_name']
            if team == '':
                return None
            else:
                return team
        else:
            return None

    def getClass(self, driver_name):
        for class_name in self.classes:
            if driver_name in self.classes[class_name].drivers:
                return class_name
        return None

    def calculate(self, no_tables=False):
        self.teams = collections.defaultdict(list)
        self.classes = collections.defaultdict(list)

        fastest_lap_time = self.race_info[1]['FastestLap'] or 0
        fastest_lap_pos = 1

        self.driver_CarType= {}

        for i in range(1, self.race_info['Competitors']+1):
            self.driver_CarType[self.race_info[i]['Name']] = self.race_info[i]['CarType']

            if self.champ.teams_options not in ['Off', 'Manual']:
                self.teams[self.race_info[i][self.champ.teams_options]].append(self.race_info[i]['Name'])
                self.race_info[i]['team_name'] = self.race_info[i][self.champ.teams_options]
            elif self.champ.teams_options == "Manual":
                self.race_info[i]['team_name'] = ''
                for tname, drivers in self.race.teams.items():
                    if self.race_info[i]['Name'] in drivers:
                        self.race_info[i]['team_name'] = tname
                        self.teams[tname].append(self.race_info[i]['Name'])
                        break
            else:
                self.race_info[i]['team_name'] = ''

            if self.champ.class_options not in ['Off', 'Manual']:
                self.classes[self.race_info[i][self.champ.class_options]].append(self.race_info[i]['Name'])
                self.race_info[i]['class_name'] = self.race_info[i][self.champ.class_options]
            elif self.champ.class_options == 'Manual':
                self.race_info[i]['class_name'] = ''
                for clname, drivers in self.race.classes.items():
                    if self.race_info[i]['Name'] in drivers:
                        self.race_info[i]['class_name'] = clname
                        self.classes[clname].append(self.race_info[i]['Name'])
                        break
            else:
                self.race_info[i]['class_name'] = ''

            # find fastest lap
            if self.race_info[i]['FastestLap'] and self.race_info[i]['FastestLap'] < fastest_lap_time:
                fastest_lap_time = self.race_info[i]['FastestLap']
                fastest_lap_pos = i

        self.out['FastestLap'] = {
            'name': self.race_info[fastest_lap_pos]['Name'],
            'time': fastest_lap_time,
            'position': fastest_lap_pos}

        self.classes = {class_name: Class(self.classes[class_name]) for class_name in self.classes}
        self.class_start_positions = {class_name: self.classes[class_name].get_class_start_positions(event=self) for class_name in self.classes.keys()}

        self.calculateConsistency()
        self.assign_points()

        self.out['podium'] = [self.race_info[1]['Name'] if self.race_info.get(1) else '',
                              self.race_info[2]['Name'] if self.race_info.get(2) else '',
                              self.race_info[3]['Name'] if self.race_info.get(3) else '']
        if not no_tables:
            self.create_tables()

    def create_tables(self):
        self.calculateRaceResultsTable()
        if self.qual_info:
            self.calculateQualResultsTable()
            self.calculateQualHistory()
            self.calculateQualSectors()
            self.calculateQualLaps()
        self.calculateRaceFlaps()
        self.calculateRaceHistory()
        self.calculateRaceSectors()
        self.calculateRaceLaps()
        self.calculateRacePitStops()
        self.calculateRaceFuel()
        self.calculateIncidents()

        self.calculateGraphs()

    def assign_points(self):

        if self.race.points_preset_name != "":
            db = current.db
            points_preset_row = db(db.user_points_preset.name==self.race.points_preset_name).select().first()

            current_pts_finish_on_lead_lap = float(points_preset_row.points.get('championship_pts_finish_on_lead_lap', 0))
            current_pts_pole = float(points_preset_row.points.get('championship_pts_pole', 0))
            current_pts_lead_one_lap = float(points_preset_row.points.get('championship_pts_lead_one_lap', 0))
            current_pts_lead_max_laps = float(points_preset_row.points.get('championship_pts_lead_max_laps', 0))
            current_pts_fastest_lap = float(points_preset_row.points.get('championship_pts_fastest_lap', 0))
            current_pts_consistency = float(points_preset_row.points.get('championship_pts_consistency', 0))
            current_pts_consistency_max_position = int(points_preset_row.points.get('championship_pts_consistency_max_position', 0))
            current_pts_for_all = float(points_preset_row.points.get('championship_pts_for_all', 0))
            current_points = {int(p): float(points_preset_row.points['pts_'+str(p)] or 0) for p in range(1,51)}
            current_pts_start = float(points_preset_row.points.get('championship_pts_start', 0))
            current_pts_finish_leader_distance = float(points_preset_row.points.get('championship_pts_finish_leader_distance', 0))
            current_pts_finish_leader_distance_percent = int(points_preset_row.points.get('championship_pts_finish_leader_distance_percent', 0))
            current_pts_for_all_includes_dns = points_preset_row.points.get('championship_pts_for_all_includes_dns', True)
            current_pts_finish_leader_distance_must_finish = points_preset_row.points.get('championship_pts_finish_leader_distance_must_finish', False)
            current_pts_fastest_lap_position = int(points_preset_row.points.get('championship_pts_fastest_lap_position', 0))
            current_pts_for_gained_position = float(points_preset_row.points.get('championship_pts_for_gained_position', 0))
        else:
            current_pts_finish_on_lead_lap = self.champ.pts_finish_on_lead_lap
            current_pts_pole = self.champ.pts_pole
            current_pts_lead_one_lap = self.champ.pts_lead_one_lap
            current_pts_lead_max_laps = self.champ.pts_lead_max_laps
            current_pts_fastest_lap = self.champ.pts_fastest_lap
            current_pts_consistency = self.champ.pts_consistency
            current_pts_consistency_max_position = self.champ.pts_consistency_max_position
            current_pts_for_all = self.champ.pts_for_all
            current_points = self.champ.points
            current_pts_start = self.champ.pts_start
            current_pts_finish_leader_distance = self.champ.pts_finish_leader_distance
            current_pts_finish_leader_distance_percent = self.champ.pts_finish_leader_distance_percent
            current_pts_for_all_includes_dns = self.champ.pts_for_all_includes_dns
            current_pts_finish_leader_distance_must_finish = self.champ.pts_finish_leader_distance_must_finish
            current_pts_fastest_lap_position = self.champ.pts_fastest_lap_position
            current_pts_for_gained_position = self.champ.pts_for_gained_position


        lapsledlist = []
        self.out['pole'] = {'time': None, 'name': None}
        self.drivers = []
        for i in range(1, self.race_info['Competitors']+1):
            self.drivers.append(self.race_info[i]['Name'])
            self.race_info[i]['pts'] = 0
            self.race_info[i]['class_pts'] = 0
            self.race_info[i]['class_pos'] = 0
            self.race_info[i]['pts_dict'] = {'real': {}, 'fake': {}, 'manual': {}}
            self.race_info[i]['class_pts_dict'] = {'real': {}, 'fake': {}, 'manual': {}}

            # pts for finish on the lead lap
            if self.race_info[i]['Laps'] == self.race_info[1]['Laps']:
                self.race_info[i]['pts'] += current_pts_finish_on_lead_lap
                self.race_info[i]['pts_dict']['real']['Finishing on the lead lap'] = current_pts_finish_on_lead_lap

            # find Pole and add pts for Pole Position
            if not self.race.noqual:
                if self.race_info[i]['StartPosition'] == 1:
                    self.race_info[i]['pts'] += current_pts_pole
                    self.race_info[i]['pts_dict']['real']['Pole position'] = current_pts_pole
                    self.out['pole'] = {'time': self.race_info[i]['QualificationTime'], 'name': self.race_info[i]['Name']}

            # add pts for Lead One Lap
            if self.race_info[i]['LapsLed'] > 0:
                self.race_info[i]['pts'] += current_pts_lead_one_lap
                self.race_info[i]['pts_dict']['real']['Leading one lap'] = current_pts_lead_one_lap
            lapsledlist.append(self.race_info[i]['LapsLed'])

            # add pts for gaining positions
            if current_pts_for_gained_position > 0:
                gained_positions = self.race_info[i]['StartPosition'] - self.race_info[i]['FinishPosition']
                if self.race_info[i]['FinishStatus'] == 'Finished' and gained_positions > 0:
                    self.race_info[i]['pts'] += current_pts_for_gained_position * gained_positions
                    self.race_info[i]['pts_dict']['real']['Gaining '+str(gained_positions)+' positions ('+str(current_pts_for_gained_position)+' per position)'] = current_pts_for_gained_position * gained_positions



        # add pts for Leading Max Laps. If more than 1 driver has even number of lead laps, give pts to all.
        maxll = max(lapsledlist)
        max_indexes = [i for i, laps_led in enumerate(lapsledlist) if laps_led == maxll]
        for i in max_indexes:
            self.out['LedMaxlaps'] = {'name': self.race_info[i+1]['Name'], 'laps': str(maxll)}
            self.race_info[i+1]['pts'] += current_pts_lead_max_laps
            self.race_info[i+1]['pts_dict']['real']['Leading max laps'] = current_pts_lead_max_laps


        # PTS for consistency
        if current_pts_consistency:
            for i, row in enumerate(self.out['table_raceConsistency']['raceDevFromSelf'], 1):
                if i > current_pts_consistency_max_position or row['dev'] == '-':
                    break

                pos = self.race_info['finish_positions'][row['name']]
                self.race_info[pos]['pts'] += current_pts_consistency
                self.race_info[pos]['pts_dict']['real']['Consistency (#'+str(i)+')'] = current_pts_consistency

                self.race_info[pos]['class_pts'] += current_pts_consistency
                self.race_info[pos]['class_pts_dict']['real']['Consistency position (#'+str(i)+')'] = current_pts_consistency


        # PTS for finish positions:
        self.out['inpoints'] = []
        leader_laps_for_classification = self.race_info[1]['Laps'] * self.champ.pts_distance / 100
        for pos in sorted(current_points):
            if pos > self.race_info['Competitors']:
                break

            # assign class points from overall standings option here

            if self.race_info[pos]['Laps'] >= leader_laps_for_classification:
                if not self.champ.pts_must_finish or (self.champ.pts_must_finish and self.race_info[pos]['FinishStatus'] == 'Finished'):
                    self.race_info[pos]['pts'] += current_points[pos] * self.race.pts_multiplier
                    self.race_info[pos]['pts_dict']['real']['Finishing in position #'+str(pos)] = current_points[pos] * self.race.pts_multiplier
                    if current_points[pos] > 0:
                        self.out['inpoints'].append(self.race_info[pos]['Name'])

                    if self.champ.overall_pts_for_class:
                        self.race_info[pos]['class_pts'] += current_points[pos] * self.race.pts_multiplier


            # old code from log analyzer v.1
            #elif champ.halfpts and self.race_info[pos]['Laps'] >= self.race_info[1]['Laps'] * 0.5:
            #    self.race_info[pos]['pts'] = current_points[pos] / 2
            # points for qualy
            #if self.champ.qual_pts and not self.race.noqual and self.race_info[pos]['QualificationTime']:
            #    self.race_info[pos]['pts'] += current_points[self.race_info[pos]['StartPosition']]

        # add pts for Fastest Lap

        if current_pts_fastest_lap_position:
            fl_position = self.out['FastestLap']['position']
            if self.race_info[fl_position]['Laps'] >= leader_laps_for_classification and fl_position <= current_pts_fastest_lap_position:
                if not self.champ.pts_must_finish or (self.champ.pts_must_finish and self.race_info[fl_position]['FinishStatus'] == 'Finished'):
                    self.race_info[self.out['FastestLap']['position']]['pts'] += current_pts_fastest_lap
                    self.race_info[self.out['FastestLap']['position']]['pts_dict']['real']['Fastest lap'] = current_pts_fastest_lap
        else:
            self.race_info[self.out['FastestLap']['position']]['pts'] += current_pts_fastest_lap
            self.race_info[self.out['FastestLap']['position']]['pts_dict']['real']['Fastest lap'] = current_pts_fastest_lap


        # class pts
        self.out['clinpoints'] = {}
        for class_name in self.classes:
            if self.classes[class_name].drivers:
                self.out['clinpoints'][class_name] = []
                # clinfo = {class_position: race_info[overall_position], ...}
                clinfo = self.classes[class_name].getClassRaceInfo(event=self)
                leader_laps_for_bonus = clinfo[1]['Laps'] * current_pts_finish_leader_distance_percent / 100
                leader_laps_for_classification = clinfo[1]['Laps'] * self.champ.pts_distance / 100

                #class_start_positions = self.classes[class_name].get_class_start_positions(event=self)

                for pos in sorted(current_points)[:len(clinfo)]:
                    # position in overall standings
                    pos0 = clinfo[pos]['Pos']

                    if self.champ.overall_pts_for_class:
                        if self.race_info[pos0]['class_pts']:
                            self.race_info[pos0]['class_pts_dict']['real']['Finishing in position #'+str(pos)] = current_points[pos0] * self.race.pts_multiplier
                            if self.race_info[pos0]['class_pts'] > 0:
                                self.out['clinpoints'][class_name].append(self.race_info[pos0]['Name'])
                    else:
                        if clinfo[pos]['Laps'] >= leader_laps_for_classification:
                            if not self.champ.pts_must_finish or (self.champ.pts_must_finish and self.race_info[pos0]['FinishStatus'] == 'Finished'):
                                self.race_info[pos0]['class_pts'] += current_points[pos] * self.race.pts_multiplier
                                self.race_info[pos0]['class_pts_dict']['real']['Finishing in position #'+str(pos)] = current_points[pos] * self.race.pts_multiplier
                                if self.race_info[pos0]['class_pts'] > 0:
                                    self.out['clinpoints'][class_name].append(self.race_info[pos0]['Name'])

                    if clinfo[1]['Laps'] == clinfo[pos]['Laps']:
                        self.race_info[pos0]['class_pts'] += current_pts_finish_on_lead_lap
                        self.race_info[pos0]['class_pts_dict']['real']['Finishing on the lead lap'] = current_pts_finish_on_lead_lap

                    if current_pts_finish_leader_distance and clinfo[pos]['Laps'] >= leader_laps_for_bonus:
                        if not current_pts_finish_leader_distance_must_finish or (current_pts_finish_leader_distance_must_finish and self.race_info[pos0]['FinishStatus'] == 'Finished'):
                            self.race_info[pos0]['class_pts'] += current_pts_finish_leader_distance
                            self.race_info[pos0]['class_pts_dict']['real']['Completing '+str(current_pts_finish_leader_distance_percent)+'% of class leader distance ('+str(round(leader_laps_for_bonus, 1))+' laps)'] = current_pts_finish_leader_distance

                    self.race_info[pos0]['class_pos'] = pos

                    if current_pts_for_gained_position > 0:
                        gained_positions = self.class_start_positions[class_name][self.race_info[pos0]['Name']] - pos
                        if self.race_info[pos0]['FinishStatus'] == 'Finished' and gained_positions > 0:
                            self.race_info[pos0]['class_pts'] += current_pts_for_gained_position * gained_positions
                            self.race_info[pos0]['class_pts_dict']['real']['Gaining '+str(gained_positions)+' positions ('+str(current_pts_for_gained_position)+' per position)'] = current_pts_for_gained_position * gained_positions


                if not self.race.noqual:
                    class_pole = self.classes[class_name].get_class_pole(event=self)
                    if class_pole:
                        #self.classes[class_name].Pole = {'name': class_pole['Name'], 'time': class_pole['QualificationTime']}
                        self.race_info[class_pole['Pos']]['class_pts'] += current_pts_pole
                        self.race_info[class_pole['Pos']]['class_pts_dict']['real']['Pole position'] = current_pts_pole

        """
        # Bonuses for completing X laps or X minutes
        bonus_time = 10 * 60 # 10 min, in seconds



        lap = 4
        lap_positions = {i: self.race_info[i]['positions'][lap-1] for i in range(1, self.race_info['Competitors']+1) if len(self.race_info[i]['positions'])>=lap}

        #print(lap_positions)
        for fin_pos, lap_pos in lap_positions.items():
            if i <= 50:
                self.race_info[fin_pos]['pts'] += current_points[lap_pos] * self.race.pts_multiplier * 0.33
                self.race_info[fin_pos]['pts_dict']['real']['Finishing lap '+str(lap)+' in position #'+str(lap_pos)] = current_points[lap_pos] * self.race.pts_multiplier * 0.33

        #for pos in sorted(current_points):
        #    if pos > self.race_info['Competitors']:
        #        break

        for class_name in self.classes:
            if self.classes[class_name].drivers:
                # clinfo = {class_position: race_info[overall_position], ...}
                cl_lap_info = self.classes[class_name].getClassRaceInfo_on_lap(event=self, lap=4)
                if cl_lap_info:
                    for lap_pos, lap_info in cl_lap_info.items():
                        self.race_info[lap_info['Pos']]['class_pts'] += current_points[lap_pos] * self.race.pts_multiplier * 0.33
                        self.race_info[lap_info['Pos']]['class_pts_dict']['real']['Finishing lap '+str(lap)+' in position #'+str(lap_pos)] = current_points[lap_pos] * self.race.pts_multiplier * 0.33


        """



        #Contingency points, penalty points, manual override
        leader_laps_for_bonus = self.race_info[1]['Laps'] * current_pts_finish_leader_distance_percent / 100
        for i in range(1, self.race_info['Competitors']+1):

            if current_pts_start and self.race_info[i]['FinishStatus'] != 'DNS':
                self.race_info[i]['pts'] += current_pts_start
                self.race_info[i]['pts_dict']['real']['Starting the race'] = current_pts_start
                self.race_info[i]['class_pts'] += current_pts_start
                self.race_info[i]['class_pts_dict']['real']['Starting the race'] = current_pts_start

            if current_pts_finish_leader_distance and self.race_info[i]['Laps'] >= leader_laps_for_bonus:
                if not current_pts_finish_leader_distance_must_finish or (current_pts_finish_leader_distance_must_finish and self.race_info[i]['FinishStatus'] == 'Finished'):
                    self.race_info[i]['pts'] += current_pts_finish_leader_distance
                    self.race_info[i]['pts_dict']['real']['Completing '+str(current_pts_finish_leader_distance_percent)+'% of leader distance ('+str(round(leader_laps_for_bonus, 1))+' laps)'] = current_pts_finish_leader_distance

            if current_pts_for_all:
                if current_pts_for_all_includes_dns or (not current_pts_for_all_includes_dns and self.race_info[i]['FinishStatus'] != 'DNS'):
                    if self.race_info[i]['pts'] < current_pts_for_all:
                        self.race_info[i]['pts'] = current_pts_for_all
                        self.race_info[i]['pts_dict']['fake']['All drivers receive no less then this'] = current_pts_for_all
                    if self.race_info[i]['class_pts'] < current_pts_for_all:
                        self.race_info[i]['class_pts'] = current_pts_for_all
                        self.race_info[i]['class_pts_dict']['fake']['All drivers receive no less then this'] = current_pts_for_all

            if self.champ.subtract_penalty_points:
                pp = self.race.penalty_points.get(self.race_info[i]['Name'], 0)
                if pp:
                    self.race_info[i]['pts'] -= pp
                    self.race_info[i]['pts_dict']['real']['Penalty points'] = -pp
                    self.race_info[i]['class_pts'] -= pp
                    self.race_info[i]['class_pts_dict']['real']['Penalty points'] = -pp

            if self.race.manual_points and self.race.manual_points.get(self.race_info[i]['Name']) is not None:
                self.race_info[i]['pts'] = self.race.manual_points[self.race_info[i]['Name']]
                self.race_info[i]['pts_dict']['manual']['Manual override'] = self.race.manual_points[self.race_info[i]['Name']]
                self.race_info[i]['class_pts'] = self.race.manual_points[self.race_info[i]['Name']]
                self.race_info[i]['class_pts_dict']['manual']['Manual override'] = self.race.manual_points[self.race_info[i]['Name']]

    def calculateRaceResultsTable(self):
        raceResults = {}
        has_ballast = False
        self.driver_classes = {}
        self.driver_class_indexes = {}

        for i in range(1, self.race_info['Competitors']+1):
            if self.race_info[i]['PenaltyMass']:
                has_ballast = True

            raceResults[i] = {}

            """
            # this shows that adding leaders laptimes to lapped drivers is wrong
            if self.race_info[i]['drracelaps']:
                if self.race_info[i]['LapsGap']:
                    gap_sum = sum(self.race_info[1]['drracelaps'][-self.race_info[i]['LapsGap']:])
                else:
                    gap_sum = 0

                print (i, self.race_info[i]['LapsGap'], sum(self.race_info[i]['drracelaps']), gap_sum)
                raceResults[i]['estimated_race_time'] = sum(self.race_info[i]['drracelaps']) + gap_sum
            else:
                raceResults[i]['estimated_race_time'] = 0
            """
            raceResults[i]['is_player'] = self.race_info[i]['isPlayer']
            raceResults[i]['name'] = self.race_info[i]['Name']
            raceResults[i]['swapped_drivers'] = ", ".join([name for name in self.race_info[i]['swapped_drivers'] if name != self.race_info[i]['Name']])

            s_f = self.race_info[i]['StartPosition'] - self.race_info[i]['FinishPosition']
            if s_f > 0:
                raceResults[i]['st-fin'] = "+" + str(s_f)
            else:
                raceResults[i]['st-fin'] = str(s_f)

            raceResults[i]['vehnum'] = "#" + self.race_info[i]['VehicleNumber']

            raceResults[i]['pos'] = str(i)

            if self.champ.class_options != 'Off' and self.classes:
                # class_index for uk-badge highlighting in race report
                if self.race_info[i]['class_name']:
                    raceResults[i]['class_index'] = list(self.classes.keys()).index(self.race_info[i]['class_name']) + 1
                else:
                    raceResults[i]['class_index'] = 0
                raceResults[i]['class'] = self.race_info[i]['class_name'][-10:] + '|' + (
                    str(self.race_info[i].get('class_pos')) if self.race_info[i].get('class_pos') else '-') if self.race_info[i]['class_name'] else '---'

                self.driver_classes[self.race_info[i]['Name']] = self.race_info[i]['class_name']

                raceResults[i]['pts'] = str(la_utils.float_no_zero(self.race_info[i]['pts'])) + '|' +  (
                    str(la_utils.float_no_zero(self.race_info[i].get('class_pts'))) if self.race_info[i].get('class_pts') is not None else '-')
            else:
                raceResults[i]['class'] = '-'
                self.driver_classes[self.race_info[i]['Name']] = None
                raceResults[i]['pts'] = str((la_utils.float_no_zero(self.race_info[i]['pts']) or ''))
                raceResults[i]['class_index'] = 0


            self.driver_class_indexes[self.race_info[i]['Name']] = raceResults[i]['class_index']

            if self.race_info[i]['team_name']:
                raceResults[i]['team'] = self.race_info[i]['team_name']
            else:
                raceResults[i]['team'] = self.race_info[i]['TeamName']

            # 'car_id' was added in la_core.create_event
            raceResults[i]['vehicle'] = self.race_info[i]['car_id']
            raceResults[i]['startpos'] = self.race_info[i]['StartPosition']

            if self.race_info[i]['QualificationTime']:
                raceResults[i]['qualtime'] = la_utils.sectostr(self.race_info[i]['QualificationTime'])
            else:
                raceResults[i]['qualtime'] = '-'

            raceResults[i]['laps'] = str(self.race_info[i]['Laps'])

            raceResults[i]['time_gap'] = ""
            if i == 1:
                if self.race_info[i]['RaceDuration']:
                    raceResults[i]['time/ret'] = la_utils.sectostr(self.race_info[i]['RaceDuration'])
                else:
                    raceResults[i]['time/ret'] = '-'
            else:
                if not self.race_info[i]['RaceDuration']:
                    raceResults[i]['time/ret'] = self.race_info[i]['FinishStatus']
                else:
                    if self.race_info[i]['Laps'] < self.race_info[1]['Laps']:
                        raceResults[i]['time/ret'] = ("+"+str(self.race_info[i]['LapsGap'])+" lap" if self.race_info[i]['LapsGap'] == 1 else "+"+str(self.race_info[i]['LapsGap'])+" laps")
                        raceResults[i]['time_gap'] = "+" + la_utils.sectostr(self.race_info[i]['TimeGap'], 'gap')
                    else:
                        raceResults[i]['time/ret'] = "+" + la_utils.sectostr(self.race_info[i]['TimeGap'], 'gap')

            raceResults[i]['lapsled'] = str(self.race_info[i]['LapsLed']) if self.race_info[i]['LapsLed'] else ''
            if self.race_info[i]['FastestLap']:
                raceResults[i]['fastestlap'] = la_utils.sectostr(self.race_info[i]['FastestLap'])
            else:
                raceResults[i]['fastestlap'] = '-'
            raceResults[i]['pitstops'] = str(self.race_info[i]['Pitstops']) if self.race_info[i]['Pitstops'] else ''
            raceResults[i]['ballast'] = str(la_utils.float_no_zero(self.race_info[i]['PenaltyMass'])) if self.race_info[i]['PenaltyMass'] else ''
            raceResults[i]['compounds'] = ", ".join(self.race_info[i]['compounds']) if self.race_info[i]['compounds'] else ''
            raceResults[i]['compounds_str'] = ", ".join(self.race_info[i]['compounds_str']) if self.race_info[i]['compounds_str'] else ''
            raceResults[i]['compounds_list'] = [(t[0], t[1]) for t in zip(self.race_info[i]['compounds'], self.race_info[i]['compounds_str'])]

        self.out['has_ballast'] = has_ballast
        self.out['table_raceResults'] = raceResults

    def calculateQualResultsTable(self):
        #if not self.qual_info or self.race.noqual:
        #    self.out['table_qualResults'] = []
        #    return

        qualResults = []

        for i in range(1, self.qual_info['Competitors']+1):
            onerow = {}
            onerow['name'] = self.qual_info[i]['Name']

            if self.champ.class_options != 'Off' and self.classes:
                class_name = self.driver_classes.get(self.qual_info[i]['Name'])
                if class_name:
                    onerow['class'] = class_name[-10:] + '|' + str(self.class_start_positions[class_name][self.qual_info[i]['Name']])
                else:
                    onerow['class'] = '-'
            else:
                onerow['class'] = '-'


            onerow['ballast'] = str(la_utils.float_no_zero(self.qual_info[i]['PenaltyMass'])) if self.qual_info[i]['PenaltyMass'] else ''
            onerow['vehnum'] = "#" + self.qual_info[i]['VehicleNumber']

            rpos = self.race_info['finish_positions'].get(self.qual_info[i]['Name'])

            if self.race_info[rpos]['team_name']:
                onerow['team'] = self.race_info[rpos]['team_name']
            else:
                onerow['team'] = '-'

            onerow['vehicle'] = self.qual_info[i]['car_id']
            onerow['ingameteam'] = self.qual_info[i]['TeamName']

            if self.qual_info[i]['FastestLap']:
                onerow['time'] = la_utils.sectostr(self.qual_info[i]['FastestLap'])
            else:
                onerow['time'] = '-'

            if self.qual_info[i]['FastestLap'] and i != 1:
                try:
                    gap = self.qual_info[i]['FastestLap'] - self.qual_info[1]['FastestLap']
                    onerow['gap'] = la_utils.sectostr(gap)
                except:
                    onerow['gap'] = '-'
            else:
                onerow['gap'] = '-'

            onerow['laps'] = str(self.qual_info[i]['Laps'])
            onerow['aids'] = la_utils.formataids(self.qual_info[i]['aids'])

            qualResults.append(onerow)

        self.out['table_qualResults_possible'] = la_utils.sectostr(sum(self.qual_info['bsectors'])) \
                                                 if sum(self.qual_info['bsectors']) != 30000 else '-'
        self.out['table_qualResults'] = qualResults

    def calculateQualHistory(self):
        #if not self.qual_info or self.race.noqual:
        #    self.out['table_qualHistory'] = []
        #    return

        qualHistory = []
        max_laps = 0
        row = []
        for i in range(1, self.qual_info['Competitors']+1):
            row.append((la_utils.small_name(self.qual_info[i]['Name'])[:6], ''))
            if len(self.qual_info[i]['drracelaps']) > max_laps:
                max_laps = len(self.qual_info[i]['drracelaps'])
        qualHistory.append({'Lap': row})

        for i in range(0, max_laps):
            row = []
            for pos in range(1, self.qual_info['Competitors']+1):
                try:
                    if self.qual_info[pos]['drracelaps'][i]:
                        gap = self.qual_info[pos]['drracelaps'][i] - self.qual_info[1]['FastestLap']
                        if gap > 4:
                            gap = 4
                        gap = int(round(255 - gap*160/4.0))
                        if gap <= 15:
                            lcolor = '#CC0' + hex(gap)[2:] + '33'
                        else:
                            lcolor = '#CC' + hex(gap)[2:] + '33'
                        if self.qual_info[pos]['drracelaps'][i] == self.qual_info[1]['FastestLap']:
                            lcolor = '#B28FFF'
                        elif self.qual_info[pos]['drracelaps'][i] == self.qual_info[pos]['FastestLap']:
                            lcolor = '#a8d057'
                        row.append((la_utils.sectostr(self.qual_info[pos]['drracelaps'][i]), lcolor))
                    else:
                        row.append(('', '#DDD'))
                except:
                    row.append(('', '#DDD'))
            qualHistory.append({i+1: row})
        self.out['table_qualHistory'] = qualHistory

    def calculateQualSectors(self):
        #if not self.qual_info or self.race.noqual:
        #    self.out['table_qualSectors'] = []
        #    return

        sector1 = self.qual_info['sector1']
        sector2 = self.qual_info['sector2']
        sector3 = self.qual_info['sector3']

        qualS1 = []
        if sector1:
            sorted_s1 = sorted(sector1, key=sector1.get)
            name = sorted_s1[0]
            best_time = sector1[name]
            qualS1.append((la_utils.small_name(name), la_utils.sectostr(sector1[name]) if sector1[name] != 10000 else '-', '-'))
            sorted_s1.pop(0)
            if sorted_s1:
                others_list = [(la_utils.small_name(name),
                                la_utils.sectostr(sector1[name]),
                                la_utils.sectostr(sector1[name]-best_time)) if sector1[name] != 10000
                                else (la_utils.small_name(name), '-', '-') for name in sorted_s1]
                qualS1.extend(others_list)

        qualS2 = []
        if sector2:
            sorted_s2 = sorted(sector2, key=sector2.get)
            name = sorted_s2[0]
            best_time = sector2[name]
            qualS2.append((la_utils.small_name(name), la_utils.sectostr(sector2[name]) if sector2[name] != 10000 else '-', '-'))
            sorted_s2.pop(0)
            if sorted_s2:
                others_list = [(la_utils.small_name(name),
                                la_utils.sectostr(sector2[name]),
                                la_utils.sectostr(sector2[name]-best_time)) if sector2[name] != 10000
                                else (la_utils.small_name(name), '-', '-') for name in sorted_s2]
                qualS2.extend(others_list)

        qualS3 = []
        if sector3:
            sorted_s3 = sorted(sector3, key=sector3.get)
            name = sorted_s3[0]
            best_time = sector3[name]
            qualS3.append((la_utils.small_name(name), la_utils.sectostr(sector3[name]) if sector3[name] != 10000 else '-', '-'))
            sorted_s3.pop(0)
            if sorted_s3:
                others_list = [(la_utils.small_name(name),
                                la_utils.sectostr(sector3[name]),
                                la_utils.sectostr(sector3[name]-best_time)) if sector3[name] != 10000
                                else (la_utils.small_name(name), '-', '-') for name in sorted_s3]
                qualS3.extend(others_list)

        self.out['table_qualSectors'] = {'qualS1': qualS1, 'qualS2': qualS2, 'qualS3': qualS3}

    def calculateQualLaps(self):
        qualLaps = []
        qual_possible = {}
        for p in range(1, self.qual_info['Competitors']+1):
            name = self.qual_info[p]['Name']
            onerow = {name: []}
            last_lap = None
            for i, lap in enumerate(self.qual_info[p]['racesectors']):
                #if i > 0 and lap[0] == '--.----' and not lap[1] and not lap[2] and not lap[3]:
                #    continue

                onerow[name].append({'laptime': {'time': '-', 'bg': '', 'fg': ''},
                                    's1': {'time': '-', 'fg': ''},
                                    's2': {'time': '-', 'fg': ''},
                                    's3': {'time': '-', 'fg': ''},
                                    'fuel': '-', 'compounds': ('15','15'),
                                    'num':i+1, 'twfl':0, 'twfr':0, 'twrl':0, 'twrr':0})
                # laptime
                if lap[0] != '--.----':
                    onerow[name][-1]['laptime']['time'] = la_utils.sectostr(float(lap[0]))
                    if self.qual_info[p]['FastestLap'] and self.qual_info[p]['FastestLap'] == float(lap[0]):
                        onerow[name][-1]['laptime']['bg'] = '#d7fecf'
                    if float(lap[0]) == self.out['pole']['time']:
                        onerow[name][-1]['laptime']['fg'] = '#B445FE; font-weight: bold !important;'
                # sector 1
                if lap[1]:
                    onerow[name][-1]['s1']['time'] = la_utils.sectostr(lap[1])
                    if self.qual_info[p]['bsectors'][0] == lap[1]:
                        onerow[name][-1]['s1']['fg'] = '#3d9e12; font-weight: bold !important;'
                    if self.qual_info['bsectors'][0] == lap[1]:
                        onerow[name][-1]['s1']['fg'] = '#B445FE; font-weight: bold !important;'
                # sector 2
                if lap[2]:
                    onerow[name][-1]['s2']['time'] = la_utils.sectostr(lap[2])
                    if self.qual_info[p]['bsectors'][1] == lap[2]:
                        onerow[name][-1]['s2']['fg'] = '#3d9e12; font-weight: bold !important;'
                    if self.qual_info['bsectors'][1] == lap[2]:
                        onerow[name][-1]['s2']['fg'] = '#B445FE; font-weight: bold !important;'
                # sector 3
                if lap[3]:
                    onerow[name][-1]['s3']['time'] = la_utils.sectostr(lap[3])
                    if self.qual_info[p]['bsectors'][2] == lap[3]:
                        onerow[name][-1]['s3']['fg'] = '#3d9e12; font-weight: bold !important;'
                    if self.qual_info['bsectors'][2] == lap[3]:
                        onerow[name][-1]['s3']['fg'] = '#B445FE; font-weight: bold !important;'
                # fuel
                if lap[4]:
                    onerow[name][-1]['fuel'] = str(round(lap[4]*100, 2)) + "%"
                # tire wear
                onerow[name][-1]['twfl'] = lap[5]
                onerow[name][-1]['twfr'] = lap[6]
                onerow[name][-1]['twrl'] = lap[7]
                onerow[name][-1]['twrr'] = lap[8]
                if self.qual_info['has_tire_wear']:
                    if not last_lap or last_lap[5] < lap[5]:
                        onerow[name][-1]['lap_twfl'] = round((1 - lap[5]) * 100, 1)
                    else:
                        onerow[name][-1]['lap_twfl'] = round((last_lap[5] - lap[5]) * 100, 1)
                    if onerow[name][-1]['lap_twfl'] == 100:
                        onerow[name][-1]['lap_twfl'] = 0
                    onerow[name][-1]['lap_twfl'] = onerow[name][-1]['lap_twfl'] or '-'

                    if not last_lap or last_lap[6] < lap[6]:
                        onerow[name][-1]['lap_twfr'] = round((1 - lap[6]) * 100, 1)
                    else:
                        onerow[name][-1]['lap_twfr'] = round((last_lap[6] - lap[6]) * 100, 1)
                    if onerow[name][-1]['lap_twfr'] == 100:
                        onerow[name][-1]['lap_twfr'] = 0
                    onerow[name][-1]['lap_twfr'] = onerow[name][-1]['lap_twfr'] or '-'

                    if not last_lap or last_lap[7] < lap[7]:
                        onerow[name][-1]['lap_twrl'] = round((1 - lap[7]) * 100, 1)
                    else:
                        onerow[name][-1]['lap_twrl'] = round((last_lap[7] - lap[7]) * 100, 1)
                    if onerow[name][-1]['lap_twrl'] == 100:
                        onerow[name][-1]['lap_twrl'] = 0
                    onerow[name][-1]['lap_twrl'] = onerow[name][-1]['lap_twrl'] or '-'

                    if not last_lap or last_lap[8] < lap[8]:
                        onerow[name][-1]['lap_twrr'] = round((1 - lap[8]) * 100, 1)
                    else:
                        onerow[name][-1]['lap_twrr'] = round((last_lap[8] - lap[8]) * 100, 1)
                    if onerow[name][-1]['lap_twrr'] == 100:
                        onerow[name][-1]['lap_twrr'] = 0
                    onerow[name][-1]['lap_twrr'] = onerow[name][-1]['lap_twrr'] or '-'

                    last_lap = lap

                if self.qual_info[p]['compounds']:
                    onerow[name][-1]['compounds'] = (self.qual_info[p]['compounds_bylap'][i][0],
                                                     self.qual_info[p]['compounds_bylap'][i][1])
                    onerow[name][-1]['compounds_str'] = (self.qual_info[p]['compounds_str_bylap'][i][0],
                                                         self.qual_info[p]['compounds_str_bylap'][i][1])

            onerow[name].append({'laptime': {'time': '-', 'bg': '', 'fg': '#3d9e12; font-weight: bold !important;'},
                                 's1': {'time': '-', 'fg': '#3d9e12; font-weight: bold !important;'},
                                 's2': {'time': '-', 'fg': '#3d9e12; font-weight: bold !important;'},
                                 's3': {'time': '-', 'fg': '#3d9e12; font-weight: bold !important;'},
                                 'fuel': '', 'compounds': ('15','15'),
                                 'num': '', 'twfl': 0, 'twfr': 0, 'twrl': 0, 'twrr': 0})

            poss = sum(self.qual_info[p]['bsectors'])
            if poss != 30000:
                onerow[name][-1]['laptime']['time'] = la_utils.sectostr(poss)
                onerow[name][-1]['s1']['time'] = la_utils.sectostr(self.qual_info[p]['bsectors'][0])
                onerow[name][-1]['s2']['time'] = la_utils.sectostr(self.qual_info[p]['bsectors'][1])
                onerow[name][-1]['s3']['time'] = la_utils.sectostr(self.qual_info[p]['bsectors'][2])

            green = False
            if self.qual_info[p]['FastestLap'] and poss != 30000:
                if round(self.qual_info[p]['FastestLap'], 3) > round(poss, 3):
                    green = True

            qual_possible[name] = {'green': green, 'time_str': onerow[name][-1]['laptime']['time']}

            qualLaps.append(onerow)
        self.out['table_qualLaps'] = qualLaps
        self.out['qual_possible'] = qual_possible

    def calculateRaceFlaps(self):
        raceFlapsByTime = []
        raceFlapsByLap = []

        race_fastest = 10000
        best_laps = collections.defaultdict(int)
        for lap_num in range(0, self.race_info['most_laps_complited']):
            lap_fastest = 10000
            found = False
            name = ''
            time = 0
            for i in range(1, self.race_info['Competitors']+1):
                if self.race_info[i]['drracelaps'] and lap_num + 1 <= len(self.race_info[i]['drracelaps']):
                    if self.race_info[i]['drracelaps'][lap_num] > 0:
                        if self.race_info[i]['drracelaps'][lap_num] < lap_fastest and not found:
                            name = self.race_info[i]['Name']
                            time = self.race_info[i]['drracelaps'][lap_num]
                            lap_fastest = time
                        if self.race_info[i]['drracelaps'][lap_num] < race_fastest:
                            name = self.race_info[i]['Name']
                            time = self.race_info[i]['drracelaps'][lap_num]
                            race_fastest = time
                            found = True

            best_laps[name] += 1

            raceFlapsByLap.append({'name': name,
                                   'time': la_utils.sectostr(time),
                                   'lap': lap_num+1,
                                   'race_fastest': found})

        flpos = {i: self.race_info[i]['FastestLap'] if self.race_info[i]['FastestLap'] else 10000
                 for i in range(1, self.race_info['Competitors']+1)}

        for i, pos in enumerate(sorted(flpos, key=flpos.get), 1):
            onerow = {}
            onerow['name'] = self.race_info[pos]['Name']
            onerow['is_player'] = self.race_info[pos]['isPlayer']
            onerow['swapped_drivers'] = ", ".join([name for name in self.race_info[i]['swapped_drivers'] if name != self.race_info[i]['Name']])
            onerow['best_laps'] = best_laps.get(onerow['name'], 0) or ''
            onerow['vehicle'] = self.race_info[pos]['car_id']
            onerow['vehnum'] = "#" + self.race_info[pos]['VehicleNumber']
            onerow['ingameteam'] = self.race_info[pos]['TeamName']
            if self.race_info[pos]['FastestLap']:
                try:
                    onerow['lap'] = str(self.race_info[pos]['drracelaps'].index(self.race_info[pos]['FastestLap'])+1)
                except ValueError:
                    onerow['lap'] = '-'
            else:
                onerow['lap'] = '-'
            if i != 1:
                if flpos[pos] != 10000:
                    onerow['time'] = la_utils.sectostr(flpos[pos])
                    onerow['gap'] = la_utils.sectostr(flpos[pos]-flap)
                else:
                    onerow['time'] = '-'
                    onerow['gap'] = '-'
            else:
                flap = flpos[pos]
                onerow['time'] = la_utils.sectostr(flpos[pos]) if flpos[pos] != 10000 else '-'
                onerow['gap'] = '-'
            onerow['aids'] = la_utils.formataids(self.race_info[pos]['aids'])
            onerow['Laps'] = self.race_info[pos]['Laps'] or '-'
            onerow['ballast'] = str(la_utils.float_no_zero(self.race_info[pos]['PenaltyMass'])) if self.race_info[pos]['PenaltyMass'] else ''
            raceFlapsByTime.append(onerow)

        self.out['table_raceFlaps_possible'] = la_utils.sectostr(sum(self.race_info['bsectors'])) if sum(self.race_info['bsectors']) != 30000 else '-'
        self.out['table_raceFlapsByLap'] = raceFlapsByLap
        self.out['table_raceFlapsByTime'] = raceFlapsByTime

    def calculateRaceHistory(self):
        raceHistory = []
        row = [(la_utils.small_name(self.race_info[i]['Name'])[:6], '') for i in range(1, self.race_info['Competitors']+1)]
        raceHistory.append({'Lap': row})

        if self.race_info['session'] != 'Race':
            laps_list = [self.race_info[i]['Laps'] for i in range(1, self.race_info['Competitors']+1)]
            if laps_list:
                max_laps = max(laps_list)
            else:
                max_laps = 0
        else:
            max_laps = self.race_info[1]['Laps']

        if self.race_info['session'] == 'Race':
            ets = []
            for i in range(0, max_laps):
                ets.append({})
                for pos in range(1, self.race_info['Competitors']+1):
                    if i > self.race_info[pos]['Laps'] - 1:
                        continue
                    try:
                        if i < self.race_info[pos]['Laps'] - 1:
                            ets[i][self.race_info[pos]['positions'][i]] = self.race_info[pos]['racesectors'][i+1][9]
                        else:
                            ets[i][self.race_info[pos]['positions'][self.race_info[pos]['Laps']-1]] = self.race_info[pos]['racesectors'][self.race_info[pos]['Laps']-1][9] + float(self.race_info[pos]['racesectors'][self.race_info[pos]['Laps']-1][0])
                    except:
                        pass

        for i in range(0, max_laps):

            leader_et = 0
            if self.race_info['session'] == 'Race':
                leader_et = ets[i].get(1, 0)

            row = []
            for pos in range(1, self.race_info['Competitors']+1):
                #if not self.race_info[pos].get('last_to_leader'):
                self.race_info[pos]['last_to_leader'] = 0
                #if not self.race_info[pos].get('last_to_front'):
                self.race_info[pos]['last_to_front'] = 0
                #if not self.race_info[pos].get('last_to_back'):
                self.race_info[pos]['last_to_back'] = 0
                try:
                    gap = self.race_info[pos]['drracelaps'][i] - self.out['FastestLap']['time']
                    if gap > 5:
                        gap = 5
                    gap = int(round(255-gap*160/5.0))
                    if gap <= 15:
                        lcolor = '#CC0'+hex(gap)[2:]+'33'
                    else:
                        lcolor = '#CC'+hex(gap)[2:]+'33'

                    if self.race_info[pos]['drracelaps'][i] == self.out['FastestLap']['time']:
                        lcolor = '#B28FFF'
                    elif self.race_info[pos]['drracelaps'][i] == self.race_info[pos]['FastestLap']:
                        lcolor = '#a8d057'
                    elif i+1 in self.race_info[pos]['pitlaps']:
                        lcolor = '#AAA'

                    if self.race_info['session'] == 'Race':
                        if self.race_info[pos]['drracelaps'][i]:
                            lap_time = la_utils.sectostr(self.race_info[pos]['drracelaps'][i])
                        else:
                            lap_time = 'No data'
                    else:
                        lap_time = la_utils.sectostr(self.race_info[pos]['drracelaps'][i])

                    lap_position = self.race_info[pos]['positions'][i] or '-'
                    position_changed = False
                    if i == 0:
                        pos_color = '#DDD'
                    elif self.race_info[pos]['positions'][i-1] - self.race_info[pos]['positions'][i] > 0:
                        pos_color = '#83c58e'
                        position_changed = True
                    elif self.race_info[pos]['positions'][i-1] - self.race_info[pos]['positions'][i] < 0:
                        pos_color = '#ce8484'
                        position_changed = True
                    else:
                        pos_color = '#DDD'

                    to_leader = '-'
                    to_front = '-'
                    to_back = '-'
                    to_leader_color = ''
                    to_front_color = ''
                    to_back_color = ''
                    if self.race_info['session'] == 'Race':
                        if i < max_laps-1:
                            if ets[i].get(self.race_info[pos]['positions'][i]+1, 0):
                                to_back = ets[i].get(self.race_info[pos]['positions'][i]+1, 0) - self.race_info[pos]['racesectors'][i+1][9]
                                if self.race_info[pos]['last_to_back'] and to_back < self.race_info[pos]['last_to_back'] and not position_changed:
                                    to_back_color = '#ce8484'
                                self.race_info[pos]['last_to_back'] = to_back
                                to_back = la_utils.sectostr(to_back)
                            else:
                                to_back = '-'
                                self.race_info[pos]['last_to_back'] = 0

                            if self.race_info[pos]['positions'][i] == 1:
                                to_leader = '-'
                                to_front = '-'
                                self.race_info[pos]['last_to_leader'] = 0
                                self.race_info[pos]['last_to_front'] = 0
                            else:
                                if leader_et:
                                    to_leader = self.race_info[pos]['racesectors'][i+1][9] - leader_et
                                    if self.race_info[pos]['last_to_leader'] and to_leader < self.race_info[pos]['last_to_leader'] and not position_changed:
                                        to_leader_color = '#75b17f'
                                    self.race_info[pos]['last_to_leader'] = to_leader
                                    to_leader = la_utils.sectostr(to_leader)
                                else:
                                    to_leader = '-'
                                    self.race_info[pos]['last_to_leader'] = 0

                                if ets[i].get(self.race_info[pos]['positions'][i]-1, 0):
                                    to_front = self.race_info[pos]['racesectors'][i+1][9] - ets[i].get(self.race_info[pos]['positions'][i]-1, 0)
                                    if self.race_info[pos]['last_to_front'] and to_front < self.race_info[pos]['last_to_front'] and not position_changed:
                                        to_front_color = '#75b17f'
                                    self.race_info[pos]['last_to_front'] = to_front
                                    to_front = la_utils.sectostr(to_front)
                                else:
                                    to_front = '-'
                                    self.race_info[pos]['last_to_front'] = 0
                        else:
                            if ets[i].get(self.race_info[pos]['positions'][max_laps-1]+1, 0):
                                to_back = ets[i].get(self.race_info[pos]['positions'][max_laps-1]+1, 0) - self.race_info[pos]['racesectors'][max_laps-1][9] - float(self.race_info[pos]['racesectors'][max_laps-1][0])
                                if self.race_info[pos]['last_to_back'] and to_back < self.race_info[pos]['last_to_back'] and not position_changed:
                                    to_back_color = '#ce8484'
                                self.race_info[pos]['last_to_back'] = to_back
                                to_back = la_utils.sectostr(to_back)
                            else:
                                to_back = '-'
                                self.race_info[pos]['last_to_back'] = 0

                            if self.race_info[pos]['positions'][max_laps-1] == 1:
                                to_leader = '-'
                                to_front = '-'
                                self.race_info[pos]['last_to_leader'] = 0
                                self.race_info[pos]['last_to_front'] = 0
                            else:
                                if leader_et:
                                    to_leader = self.race_info[pos]['racesectors'][max_laps-1][9] + float(self.race_info[pos]['racesectors'][max_laps-1][0])-leader_et
                                    if self.race_info[pos]['last_to_leader'] and to_leader < self.race_info[pos]['last_to_leader'] and not position_changed:
                                        to_leader_color = '#75b17f'
                                    self.race_info[pos]['last_to_leader'] = to_leader
                                    to_leader = la_utils.sectostr(to_leader)
                                else:
                                    to_leader = '-'
                                    self.race_info[pos]['last_to_leader'] = 0

                                if ets[i].get(self.race_info[pos]['positions'][max_laps-1]-1, 0):
                                    to_front = self.race_info[pos]['racesectors'][max_laps-1][9] + float(self.race_info[pos]['racesectors'][max_laps-1][0])-ets[i].get(self.race_info[pos]['positions'][max_laps-1]-1, 0)
                                    if self.race_info[pos]['last_to_front'] and to_front < self.race_info[pos]['last_to_front'] and not position_changed:
                                        to_front_color = '#75b17f'
                                    self.race_info[pos]['last_to_front'] = to_front
                                    to_front = la_utils.sectostr(to_front)
                                else:
                                    to_front = '-'
                                    self.race_info[pos]['last_to_front'] = 0

                    row.append((lap_time, lcolor, lap_position, pos_color,
                                to_leader, to_leader_color, to_front, to_front_color, to_back, to_back_color))

                except:
                    #print (traceback.format_exc())
                    row.append(('', '#DDD', '', '#DDD', '', '', '', '', '', ''))
            raceHistory.append({i+1: row})
        self.out['table_raceHistory'] = raceHistory

    def calculateRaceSectors(self):
        sector1 = self.race_info['sector1']
        sector2 = self.race_info['sector2']
        sector3 = self.race_info['sector3']

        raceS1 = []
        if sector1:
            sorted_s1 = sorted(sector1, key=sector1.get)
            name = sorted_s1[0]
            best_time = sector1[name]
            raceS1.append((la_utils.small_name(name), la_utils.sectostr(sector1[name]) if sector1[name] != 10000 else '-', '-'))
            sorted_s1.pop(0)
            if sorted_s1:
                others_list = [(la_utils.small_name(name),
                                la_utils.sectostr(sector1[name]),
                                la_utils.sectostr(sector1[name]-best_time)) if sector1[name] != 10000
                                else (la_utils.small_name(name), '-', '-') for name in sorted_s1]
                raceS1.extend(others_list)

        raceS2 = []
        if sector2:
            sorted_s2 = sorted(sector2, key=sector2.get)
            name = sorted_s2[0]
            best_time = sector2[name]
            raceS2.append((la_utils.small_name(name), la_utils.sectostr(sector2[name]) if sector2[name] != 10000 else '-', '-'))
            sorted_s2.pop(0)
            if sorted_s2:
                others_list = [(la_utils.small_name(name),
                                la_utils.sectostr(sector2[name]),
                                la_utils.sectostr(sector2[name]-best_time)) if sector2[name] != 10000
                                else (la_utils.small_name(name), '-', '-') for name in sorted_s2]
                raceS2.extend(others_list)

        raceS3 = []
        if sector3:
            sorted_s3 = sorted(sector3, key=sector3.get)
            name = sorted_s3[0]
            best_time = sector3[name]
            raceS3.append((la_utils.small_name(name), la_utils.sectostr(sector3[name]) if sector3[name] != 10000 else '-', '-'))
            sorted_s3.pop(0)
            if sorted_s3:
                others_list = [(la_utils.small_name(name),
                                la_utils.sectostr(sector3[name]),
                                la_utils.sectostr(sector3[name]-best_time)) if sector3[name] != 10000
                                else (la_utils.small_name(name), '-', '-') for name in sorted_s3]
                raceS3.extend(others_list)

        self.out['table_raceSectors'] = {'raceS1': raceS1, 'raceS2': raceS2, 'raceS3': raceS3}

    def calculateRaceLaps(self):
        raceLaps = []
        race_possible = {}
        for pos in range(1, self.race_info['Competitors']+1):
            name = self.race_info[pos]['Name']
            onerow = {name: []}
            last_lap = None
            for i, lap in enumerate(self.race_info[pos]['racesectors']):
                onerow[name].append({'laptime': {'time': '-', 'time_raw': 0, 'bg': '', 'fg': ''},
                                     's1': {'time': '-', 'time_raw': 0, 'fg': '', 'bg': ''},
                                     's2': {'time': '-', 'time_raw': 0, 'fg': ''},
                                     's3': {'time': '-', 'time_raw': 0, 'fg': ''},
                                     'fuel': '-', 'inpits': {'value': '', 'bg': ''},
                                     'compounds': ('15', '15'), 'compounds_str': ('-', '-'),
                                     'num': i+1, 'twfl': 0, 'twfr': 0, 'twrl': 0, 'twrr': 0})
                if lap[0] != '--.----':
                    onerow[name][-1]['laptime']['time'] = la_utils.sectostr(float(lap[0]))
                    onerow[name][-1]['laptime']['time_raw'] = float(lap[0])
                    dev = float(lap[0]) - self.out['FastestLap']['time']
                    if float(lap[0]) == self.out['FastestLap']['time']:
                        onerow[name][-1]['laptime']['fg'] = '#FFF; font-weight: bold !important;'
                    if self.race_info[pos]['FastestLap'] == float(lap[0]):
                        onerow[name][-1]['s1']['bg']='#C3FDB8'
                    if dev <= .5:
                        onerow[name][-1]['laptime']['bg'] = '#9b62c1'
                    elif .5 < dev <= 1:
                        onerow[name][-1]['laptime']['bg'] = '#F88017'
                    elif 1 < dev <= 2:
                        onerow[name][-1]['laptime']['bg'] = '#FBB117'
                    elif 2 < dev <= 3:
                        onerow[name][-1]['laptime']['bg'] = '#ECD672'
                    elif 3 < dev:
                        onerow[name][-1]['laptime']['bg'] = '#C9C299'
                if lap[1]:
                    onerow[name][-1]['s1']['time'] = la_utils.sectostr(lap[1])
                    onerow[name][-1]['s1']['time_raw'] = lap[1]
                    if self.race_info[pos]['bsectors'][0] == lap[1]:
                        onerow[name][-1]['s1']['fg'] = '#3d9e12; font-weight: bold !important;'
                    if self.race_info['bsectors'][0] == lap[1]:
                        onerow[name][-1]['s1']['fg'] = '#B445FE; font-weight: bold !important;'
                if lap[2]:
                    onerow[name][-1]['s2']['time'] = la_utils.sectostr(lap[2])
                    onerow[name][-1]['s2']['time_raw'] = lap[2]
                    if self.race_info[pos]['bsectors'][1] == float(lap[2]):
                        onerow[name][-1]['s2']['fg'] = '#3d9e12; font-weight: bold !important;'
                    if self.race_info['bsectors'][1] == lap[2]:
                        onerow[name][-1]['s2']['fg'] = '#B445FE; font-weight: bold !important;'
                if lap[3]:
                    onerow[name][-1]['s3']['time'] = la_utils.sectostr(lap[3])
                    onerow[name][-1]['s3']['time_raw'] = lap[3]
                    if self.race_info[pos]['bsectors'][2] == lap[3]:
                        onerow[name][-1]['s3']['fg'] = '#3d9e12; font-weight: bold !important;'
                    if self.race_info['bsectors'][2] == lap[3]:
                        onerow[name][-1]['s3']['fg'] = '#B445FE; font-weight: bold !important;'
                if lap[4]:
                    onerow[name][-1]['fuel'] = str(round(lap[4]*100, 2))+"%"
                onerow[name][-1]['twfl'] = lap[5]
                onerow[name][-1]['twfr'] = lap[6]
                onerow[name][-1]['twrl'] = lap[7]
                onerow[name][-1]['twrr'] = lap[8]
                if self.race_info['has_tire_wear']:
                    if not last_lap or last_lap[5] < lap[5]:
                        onerow[name][-1]['lap_twfl'] = round((1 - lap[5]) * 100, 1)
                    else:
                        onerow[name][-1]['lap_twfl'] = round((last_lap[5] - lap[5]) * 100, 1)
                    if onerow[name][-1]['lap_twfl'] == 100:
                        onerow[name][-1]['lap_twfl'] = 0

                    if not last_lap or last_lap[6] < lap[6]:
                        onerow[name][-1]['lap_twfr'] = round((1 - lap[6]) * 100, 1)
                    else:
                        onerow[name][-1]['lap_twfr'] = round((last_lap[6] - lap[6]) * 100, 1)
                    if onerow[name][-1]['lap_twfr'] == 100:
                        onerow[name][-1]['lap_twfr'] = 0

                    if not last_lap or last_lap[7] < lap[7]:
                        onerow[name][-1]['lap_twrl'] = round((1 - lap[7]) * 100, 1)
                    else:
                        onerow[name][-1]['lap_twrl'] = round((last_lap[7] - lap[7]) * 100, 1)
                    if onerow[name][-1]['lap_twrl'] == 100:
                        onerow[name][-1]['lap_twrl'] = 0

                    if not last_lap or last_lap[8] < lap[8]:
                        onerow[name][-1]['lap_twrr'] = round((1 - lap[8]) * 100, 1)
                    else:
                        onerow[name][-1]['lap_twrr'] = round((last_lap[8] - lap[8]) * 100, 1)
                    if onerow[name][-1]['lap_twrr'] == 100:
                        onerow[name][-1]['lap_twrr'] = 0

                    last_lap = lap
                if self.race_info[pos]['compounds']:
                    onerow[name][-1]['compounds'] = (self.race_info[pos]['compounds_bylap'][i][0],
                                                     self.race_info[pos]['compounds_bylap'][i][1])
                    onerow[name][-1]['compounds_str'] = (self.race_info[pos]['compounds_str_bylap'][i][0],
                                                         self.race_info[pos]['compounds_str_bylap'][i][1])
                if i+1 in self.race_info[pos]['pitlaps']:
                    onerow[name][-1]['inpits']['value'] = 'In pitlane'
                    onerow[name][-1]['inpits']['bg'] = "#ECD672"

                if self.race_info[pos]['swaps'].get(i+1):
                    onerow[name][-1]['swap'] = {'endLap': self.race_info[pos]['swaps'][i+1][0],
                                                  'name': self.race_info[pos]['swaps'][i+1][1]}

            poss = sum(self.race_info[pos]['bsectors'])
            onerow[name].append({'laptime': {'time': '-', 'time_raw': 0, 'bg': '', 'fg': '#3d9e12; font-weight: bold !important;'},
                                 's1': {'time': '-', 'time_raw': 0, 'fg': '#3d9e12; font-weight: bold !important;', 'bg': ''},
                                 's2': {'time': '-', 'time_raw': 0, 'fg': '#3d9e12; font-weight: bold !important;'},
                                 's3': {'time': '-', 'time_raw': 0, 'fg': '#3d9e12; font-weight: bold !important;'},
                                 'fuel': '',
                                 'inpits': {'value': '', 'bg': ''},
                                 'compounds': ('15', '15'), 'compounds_str': ('-', '-'),
                                 'num': '', 'twfl': 0, 'twfr': 0, 'twrl': 0, 'twrr': 0})

            if poss != 30000:
                onerow[name][-1]['laptime']['time'] = la_utils.sectostr(poss)
                onerow[name][-1]['s1']['time'] = la_utils.sectostr(self.race_info[pos]['bsectors'][0])
                onerow[name][-1]['s1']['best'] = True
                onerow[name][-1]['s2']['time'] = la_utils.sectostr(self.race_info[pos]['bsectors'][1])
                onerow[name][-1]['s2']['best'] = True
                onerow[name][-1]['s3']['time'] = la_utils.sectostr(self.race_info[pos]['bsectors'][2])
                onerow[name][-1]['s3']['best'] = True

            green = False
            if self.race_info[pos]['FastestLap'] and poss != 30000:
                if round(self.race_info[pos]['FastestLap'], 3) > round(poss, 3):
                    green = True

            race_possible[name] = {'green': green, 'time_str': onerow[name][-1]['laptime']['time']}

            raceLaps.append(onerow)
        self.out['table_raceLaps'] = raceLaps
        self.out['race_possible'] = race_possible

    def calculateRaceFuel(self):
        raceFuel = []
        raceFuelStart = []
        raceFuelFinish = []

        fuelpos = {}
        startfuel = {}
        finishfuel = {}
        for i in range(1, self.race_info['Competitors']+1):
            fuelperlap = [lap[4]-self.race_info[i]['racesectors'][num+1][4]
                          for num, lap in enumerate(self.race_info[i]['racesectors'])
                          if num+1 < len(self.race_info[i]['racesectors']) and
                             self.race_info[i]['racesectors'][num+1][4] <= self.race_info[i]['racesectors'][num][4]]
            if fuelperlap:
                fuelpos[self.race_info[i]['Name']] = round(sum(fuelperlap)/len(fuelperlap)*100, 2)
            else:
                fuelpos[self.race_info[i]['Name']] = 1000
            if self.race_info[i]['racesectors']:
                startfuel[self.race_info[i]['Name']] = round(self.race_info[i]['racesectors'][0][4]*100, 2)
            else:
                startfuel[self.race_info[i]['Name']] = 1000
            if self.race_info[i]['FinishStatus'] == 'Finished' and self.race_info[i]['racesectors']:
                finishfuel[self.race_info[i]['Name']] = round(self.race_info[i]['racesectors'][len(self.race_info[i]['racesectors'])-1][4]*100, 2)
            else:
                finishfuel[self.race_info[i]['Name']] = 1000

            self.race_info[i]['distance'] = str(int(round(self.race_info[i]['Laps']/(self.race_info['most_laps_complited'] or 1)*100))) + "%"

        for ind, name in enumerate(sorted(fuelpos, key=fuelpos.get), 1):
            i = self.race_info['finish_positions'][name]
            onerow = {}
            onerow['num'] = ind
            onerow['name'] = name
            onerow['vehicle'] = self.race_info[i]['car_id']
            if fuelpos[name] != 1000:
                onerow['avg'] = "%.2f" % fuelpos[name]+"%"
            else:
                onerow['avg'] = '-'

            if self.race_info[i]['team_name']:
                onerow['team'] = self.race_info[i]['team_name']
            else:
                onerow['team'] = self.race_info[i]['TeamName']

            if self.race_info[i]['racesectors']:
                onerow['start'] = str(round(self.race_info[i]['racesectors'][0][4]*100, 2)) + "%"
                onerow['finish'] = str(round(self.race_info[i]['racesectors'][len(self.race_info[i]['racesectors'])-1][4]*100, 2)) + "%"
            else:
                onerow['start'] = '-'
                onerow['finish'] = '-'
            onerow['distance'] = self.race_info[i]['distance']
            raceFuel.append(onerow)

        for ind, name in enumerate(sorted(startfuel, key=startfuel.get), 1):
            i = self.race_info['finish_positions'][name]
            onerow = {}
            onerow['num'] = ind
            onerow['name'] = name
            onerow['vehicle'] = self.race_info[i]['car_id']

            if self.race_info[i]['team_name']:
                onerow['team'] = self.race_info[i]['team_name']
            else:
                onerow['team'] = self.race_info[i]['TeamName']

            if startfuel[name] != 1000:
                onerow['fuel'] = str(startfuel[name]) + "%"
            else:
                onerow['fuel'] = '-'
            raceFuelStart.append(onerow)

        for ind, name in enumerate(sorted(finishfuel, key=finishfuel.get), 1):
            i = self.race_info['finish_positions'][name]
            onerow = {}
            onerow['num'] = ind
            onerow['name'] = name
            onerow['vehicle'] = self.race_info[i]['car_id']

            if self.race_info[i]['team_name']:
                onerow['team'] = self.race_info[i]['team_name']
            else:
                onerow['team'] = self.race_info[i]['TeamName']

            if finishfuel[name] != 1000:
                onerow['fuel'] = str(finishfuel[name]) + "%"
            else:
                onerow['fuel'] = 'DNF'
            onerow['distance'] = self.race_info[i]['distance']
            raceFuelFinish.append(onerow)

        self.out['table_raceFuel'] = {'raceFuel': raceFuel, 'raceFuelStart': raceFuelStart, 'raceFuelFinish': raceFuelFinish}

        if self.race_info['has_tire_wear']:
            table_raceTW = []
            for i in range(1, self.race_info['Competitors']+1):
                onerow = {}
                onerow['vehicle'] = self.race_info[i]['car_id']

                if self.race_info[i]['team_name']:
                    onerow['team'] = self.race_info[i]['team_name']
                else:
                    onerow['team'] = self.race_info[i]['TeamName']

                onerow['distance'] = self.race_info[i]['distance']
                twfl_by_lap = []
                twfr_by_lap = []
                twrl_by_lap = []
                twrr_by_lap = []
                for lap in self.out['table_raceLaps'][i-1][self.race_info[i]['Name']]:
                    if lap['num']:
                        if lap['lap_twfl'] > 0:
                            twfl_by_lap.append(lap['lap_twfl'])
                        else:
                            lap['lap_twfl']  = '-'

                        if lap['lap_twfr'] > 0:
                            twfr_by_lap.append(lap['lap_twfr'])
                        else:
                            lap['lap_twfr'] = '-'

                        if lap['lap_twrl'] > 0:
                            twrl_by_lap.append(lap['lap_twrl'])
                        else:
                            lap['lap_twrl'] = '-'

                        if lap['lap_twrr'] > 0:
                            twrr_by_lap.append(lap['lap_twrr'])
                        else:
                            lap['lap_twrr'] = '-'

                onerow['name'] = self.race_info[i]['Name']
                tw_avg = []
                if twfl_by_lap:
                    onerow['twfl_avg'] = round(sum(twfl_by_lap)/len(twfl_by_lap), 1)
                    if onerow['twfl_avg'] == 100: onerow['twfl_avg'] = 0
                    tw_avg.append(onerow['twfl_avg'])
                else:
                    onerow['twfl_avg'] = '-'
                if twfr_by_lap:
                    onerow['twfr_avg'] = round(sum(twfr_by_lap)/len(twfr_by_lap), 1)
                    if onerow['twfr_avg'] == 100: onerow['twfr_avg'] = 0
                    tw_avg.append(onerow['twfr_avg'])
                else:
                    onerow['twfr_avg'] = '-'
                if twrl_by_lap:
                    onerow['twrl_avg'] = round(sum(twrl_by_lap)/len(twrl_by_lap), 1)
                    if onerow['twrl_avg'] == 100: onerow['twrl_avg'] = 0
                    tw_avg.append(onerow['twrl_avg'])
                else:
                    onerow['twrl_avg'] = '-'
                if twrr_by_lap:
                    onerow['twrr_avg'] = round(sum(twrr_by_lap)/len(twrr_by_lap), 1)
                    if onerow['twrr_avg'] == 100: onerow['twrr_avg'] = 0
                    tw_avg.append(onerow['twrr_avg'])
                else:
                    onerow['twrr_avg'] = '-'

                if tw_avg:
                    onerow['tw_avg'] = "%.2f" % round(sum(tw_avg)/len(tw_avg), 2)
                else:
                    onerow['tw_avg'] = 0

                table_raceTW.append(onerow)

            table_raceTW.sort(key=lambda k: float(k['tw_avg']))
            self.out['table_raceTW'] = table_raceTW

    def calculateRacePitStops(self):
        racePitStops = []
        pits = {}
        for i in range(1, self.race_info['Competitors']+1):
            name = self.race_info[i]['Name']
            pitnum = 0
            if self.race_info[i]['pitlaps'] and self.race_info[i]['racesectors']:
                keys = []
                for ind, lap in enumerate(self.race_info[i]['pitlaps']):
                    if ind % 2 == 0:
                        if lap != self.race_info[i]['Laps']:
                            pitnum += 1
                            key = name + '#' + str(pitnum)
                            keys.append(key)

                            if self.race_info[i]['racesectors'][lap-1][3] and self.race_info[i]['racesectors'][lap][1]:
                                pits[key] = {'lap': str(lap)}
                                pits[key]['time'] = self.race_info[i]['racesectors'][lap-1][3] + self.race_info[i]['racesectors'][lap][1]
                                #print(lap, self.race_info[i]['racesectors'][lap][4], self.race_info[i]['racesectors'][lap-1][4])
                                if self.race_info[i]['racesectors'][lap][4] > self.race_info[i]['racesectors'][lap-1][4]:
                                    fuel = round((self.race_info[i]['racesectors'][lap][4]-
                                                  self.race_info[i]['racesectors'][lap-1][4])*100, 2)
                                else:
                                    if lap-2 >= 0:
                                        try:
                                            fuel = round((self.race_info[i]['racesectors'][lap-1][4]-
                                                          self.race_info[i]['racesectors'][lap-2][4])*100, 2)
                                        except:
                                            fuel = 0
                                    else:
                                        fuel = 0
                                #print(fuel)
                                pits[key]['fuel'] = str(fuel) + "%" if fuel > 0 else '-'
                                pits[key]['stop'] = str(pitnum)
                                pits[key]['vehicle'] = self.race_info[i]['car_id']
                                pits[key]['vehnum'] = "#" + self.race_info[i]['VehicleNumber']
                                pits[key]['distance'] = str(int(round(lap/self.race_info[1]['Laps']*100))) + "%"
                                #print(lap, self.race_info[i]['racesectors'][lap-1][5], self.race_info[i]['racesectors'][lap][5])
                                if self.race_info[i]['compounds']:
                                    pits[key]['tires_in'] = (self.race_info[i]['compounds_bylap'][lap-1][0], self.race_info[i]['compounds_bylap'][lap-1][1])
                                    pits[key]['tires_out'] = (self.race_info[i]['compounds_bylap'][lap][0], self.race_info[i]['compounds_bylap'][lap][1])
                                    pits[key]['tires_in_str'] = (self.race_info[i]['compounds_str_bylap'][lap-1][0], self.race_info[i]['compounds_str_bylap'][lap-1][1])
                                    pits[key]['tires_out_str'] = (self.race_info[i]['compounds_str_bylap'][lap][0], self.race_info[i]['compounds_str_bylap'][lap][1])
                                else:
                                    pits[key]['tires_in'] = ('-', '-')
                                    pits[key]['tires_out'] = ('-', '-')
                                    pits[key]['tires_in_str'] = ('-', '-')
                                    pits[key]['tires_out_str'] = ('-', '-')
                            else:
                                pits[key] = {'lap': '-', 'time': 10000, 'fuel': '-', 'stops': '', 'vehnum': "#"+self.race_info[i]['VehicleNumber'],
                                             'stop': 'no data', 'vehicle': self.race_info[i]['car_id'], 'distance': '-',
                                             'tires_in': ('-', '-'), 'tires_out': ('-', '-'), 'tires_in_str': ('-', '-'), 'tires_out_str': ('-', '-')}
                for key in keys:
                    if pits[key]['stop'] != 'no data':
                        pits[key]['stops'] = str(pitnum)
            else:
                pits[name] = {'lap': '-', 'time': 10000, 'fuel': '-', 'stops': '', 'stop': '-', 'distance': '-',
                              'tires_in': ('-', '-'), 'tires_out': ('-', '-'),
                              'tires_in_str': ('-', '-'), 'tires_out_str': ('-', '-'),
                              'vehicle': self.race_info[i]['car_id'], 'vehnum': "#"+self.race_info[i]['VehicleNumber']}

        for ind, name in enumerate(sorted(pits, key=lambda name: pits[name]['time'], reverse=False)):
            if ind == 0:
                besttime = pits[name]['time']
            racePitStops.append({'name': name.split('#')[0],
                                 'lap': pits[name]['lap'],
                                 'vehicle': pits[name]['vehicle'],
                                 'vehnum': pits[name]['vehnum'],
                                 'gap': la_utils.sectostr(pits[name]['time']-besttime) if pits[name]['time'] != 10000 and ind != 0 else '-',
                                 'time': la_utils.sectostr(pits[name]['time']) if pits[name]['time'] != 10000 else '-',
                                 'fuel': pits[name]['fuel'],
                                 'distance': pits[name]['distance'],
                                 'stops': pits[name]['stop']+'/'+pits[name]['stops'] if pits[name]['stops'] else pits[name]['stop'],
                                 'tires_in': pits[name]['tires_in'],
                                 'tires_out': pits[name]['tires_out'],
                                 'tires_in_str': pits[name]['tires_in_str'],
                                 'tires_out_str': pits[name]['tires_out_str']})
        self.out['table_racePitStops'] = racePitStops

    def calculateIncidents(self):
        raceIncidents = []
        incpos = {}
        wcpos = {}
        for i in range(1, self.race_info['Competitors']+1):
            incidents = 0
            withcars = 0
            for incident in self.race_info['incidents']:
                if self.race_info[i]['Name'] in incident:
                    if 'with another vehicle' in incident:
                        if incident.count(self.race_info[i]['Name']) < 2:
                            incident_part0 = incident.split('reported contact')[0]
                            if self.race_info[i]['Name'] in incident_part0:
                                withcars += 1
                                incidents += 1
                    else:
                        incidents += 1

            incpos[i] = incidents
            wcpos[i] = withcars
        has_incidents = any(incpos.values())
        if has_incidents:
            for i, pos in enumerate(reversed(sorted(incpos, key=incpos.get)), 1):
                name = self.race_info[pos]['Name']
                onerow = {}
                onerow['name'] = name
                onerow['num'] = i
                onerow['incidents'] = str(incpos[pos]) if incpos[pos] else ''
                onerow['withcars'] = str(wcpos[pos]) if wcpos[pos] else ''
                onerow['withother'] = str(incpos[pos]-wcpos[pos]) if incpos[pos] - wcpos[pos]  else ''
                raceIncidents.append(onerow)
            self.out['table_raceIncidents'] = raceIncidents
        else:
            self.out['table_raceIncidents'] = None

        raceIncidentsContacts = []
        for line in self.race_info['incidents']:
            time, _, incident = line.partition(' ')
            if 'vehicle' in incident:
                raceIncidentsContacts.append({'time': time, 'incident': incident})
        self.out['table_raceIncidentsContacts'] = raceIncidentsContacts

    def calculateConsistency(self):
        raceDevFromLeader = []
        raceDevFromSelf = []
        dev1 = {}
        dev2 = {}

        if not self.race_info[1]['Laps']:
            self.out['table_raceConsistency'] = {'raceDevFromSelf': raceDevFromSelf, 'raceDevFromLeader': raceDevFromLeader}
            return

        for i in range(1, self.race_info['Competitors']+1):
            if self.race_info[i]['drracelaps'] and self.race_info[i]['FastestLap']:
                
                raceDevFromLeaderlist = [lap-self.out['FastestLap']['time'] for num, lap in enumerate(self.race_info[i]['drracelaps'])
                                         if lap and num+1 not in self.race_info[i]['pitlaps']
                                            and num != 0 and lap < self.race_info[i]['FastestLap']*2
                                            and lap != self.out['FastestLap']['time']]
                if raceDevFromLeaderlist:
                    d = sum(raceDevFromLeaderlist) / len(raceDevFromLeaderlist)
                    if self.race_info[i]['Laps'] / self.race_info[1]['Laps'] > self.champ.pts_distance / 100:
                        dev1[i] = round(d, 3)
                    else:
                        dev1[i] = round(d+100, 3)
                else:
                    dev1[i] = 1000
                
                raceDevFromSelflist = [lap-self.race_info[i]['FastestLap'] for num, lap in enumerate(self.race_info[i]['drracelaps'])
                                            if lap and num+1 not in self.race_info[i]['pitlaps']
                                               and num!=0 and lap < self.race_info[i]['FastestLap']*2
                                               and lap != self.race_info[i]['FastestLap']]
                if raceDevFromSelflist:
                    d = sum(raceDevFromSelflist) / len(raceDevFromSelflist)
                    if self.race_info[i]['Laps'] / self.race_info[1]['Laps'] > self.champ.pts_distance / 100:
                        dev2[i] = round(d, 3)
                    else:
                        dev2[i] = round(d+100, 3)
                else:
                    dev2[i] = 1000

            else:
                dev1[i] = 1000
                dev2[i] = 1000

        for i, ind in enumerate(sorted(dev1, key=dev1.get)):
            onerow = {}
            onerow['num'] = i + 1
            onerow['name'] = self.race_info[ind]['Name']
            if dev1[ind] < 1000:
                if self.race_info[ind]['Laps'] / self.race_info[1]['Laps'] > self.champ.pts_distance / 100:
                    onerow['dev'] = "%.3f" % dev1[ind]
                else:
                    onerow['dev'] = "%.3f" % round(dev1[ind]-100, 3)
            else:
                onerow['dev'] = '-'
            if i == 0:
                best = dev1[ind]
                onerow['gap'] = '-'
            else:
                if dev1[ind] < 1000:
                    if self.race_info[ind]['Laps'] / self.race_info[1]['Laps'] > self.champ.pts_distance / 100:
                        onerow['gap'] = "%.3f" % round(dev1[ind]-best, 3)
                    else:
                        onerow['gap'] = "%.3f" % round(dev1[ind]-100-best, 3)
                else:
                    onerow['gap'] = '-'
            onerow['distance'] = str(int(round(self.race_info[ind]['Laps']/(self.race_info[1]['Laps'] or 1)*100))) + "%"
            raceDevFromLeader.append(onerow)

        for i, ind in enumerate(sorted(dev2, key=dev2.get)):
            onerow = {}
            onerow['num'] = i + 1
            onerow['name'] = self.race_info[ind]['Name']
            if dev2[ind] < 1000:
                if self.race_info[ind]['Laps'] / self.race_info[1]['Laps'] > self.champ.pts_distance / 100:
                    onerow['dev'] = "%.3f" % dev2[ind]
                else:
                    onerow['dev'] = "%.3f" % round(dev2[ind]-100, 3)
            else:
                onerow['dev'] = '-'
            if i == 0:
                best = dev2[ind]
                onerow['gap'] = '-'
            else:
                if dev2[ind] < 1000:
                    if self.race_info[ind]['Laps'] / self.race_info[1]['Laps'] > self.champ.pts_distance / 100:
                        onerow['gap'] = "%.3f" % round(dev2[ind]-best, 3)
                    else:
                        onerow['gap'] = "%.3f" % round(dev2[ind]-100-best, 3)
                else:
                    onerow['gap'] = '-'
            onerow['distance'] = str(int(round(self.race_info[ind]['Laps']/(self.race_info[1]['Laps'] or 1)*100))) + "%"
            raceDevFromSelf.append(onerow)

        self.out['table_raceConsistency'] = {'raceDevFromSelf': raceDevFromSelf, 'raceDevFromLeader': raceDevFromLeader}

    def calculateGraphs(self):
        avgfl = [self.race_info[1]['drracelaps'][lapn] for lapn in range(0, self.race_info[1]['Laps'])
                 if self.race_info[1]['drracelaps'][lapn]]
        avgfl = sum(avgfl) / (len(avgfl) or 1)

        pydrivers = ''
        maxgap = 0
        for i in range(1, self.race_info['Competitors']+1):
            laps = ''
            avgflGap = 0

            for lapn in range(0, len(self.race_info[i]['drracelaps'])):
                if self.race_info[i]['drracelaps'][lapn] > 0:
                    avgflGap = avgflGap + avgfl - self.race_info[i]['drracelaps'][lapn]
                    if avgflGap > maxgap:
                        maxgap = avgflGap
                    laps = laps + '[' + str(lapn+1) + ', ' + str(avgflGap) + '],'
            driver = '{label: "' + str(i) + '. ' + self.race_info[i]['Name'] + '", data: [' + laps + ']},'
            pydrivers += driver
        self.out['table_Graph1'] = {'pydrivers': pydrivers, 'maxgap': maxgap, 'laps': self.race_info[1]['Laps']}

        pydrivers = ''
        for i in range(1, self.race_info['Competitors']+1):
            laps = '[0,' + str(-self.race_info[i]['StartPosition']) + '],'
            for lapn in range(0, len(self.race_info[i]['positions'])):
                laps = laps + '[' + str(lapn+1) + ', ' + str(-int(self.race_info[i]['positions'][lapn])) + '],'
            driver = '{label: "' + str(i) + '. ' + self.race_info[i]['Name'] + '", data: [' + laps + ']},'
            pydrivers += driver
        self.out['table_Graph2'] = {'pydrivers': pydrivers, 'laps': self.race_info[1]['Laps']}
