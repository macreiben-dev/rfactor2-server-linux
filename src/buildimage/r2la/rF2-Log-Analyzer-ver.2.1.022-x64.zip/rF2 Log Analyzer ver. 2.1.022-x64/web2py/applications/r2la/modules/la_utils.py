import datetime

def small_name(name):
    if name.endswith(" "):
        name = name.rstrip()

    if " " in name:
        try:
            res = name.split(' ')[0][0]+"."+name.split(' ')[-1]
        except:
            res = name
    else:
        res = name

    return res


def formataids(aids_list):
    aids = ", ".join(aids_list)
    aids = aids.replace('UnknownControl', 'Unknown')
    aids = aids.replace('AutoLift', 'Lift')
    aids = aids.replace('AutoBlip', 'Blip')
    return aids


def datetime_to_timestamp(ts):
    return int((ts - datetime.datetime(1970,1,1)).total_seconds())


def sectostr(sec, gap=None):
    sec = abs(sec) #abs(float(sec))
    if sec >= 86400:
        return str(datetime.timedelta(seconds=sec))[:-3]
    rd = str(datetime.timedelta(seconds=sec))
    ms = "%.3f" % round(float(rd[6:]), 3)
    if gap:
        return rd[2:6] + ms
    if sec >= 3600:
        return rd[:6] + ms
    if sec < 10:
        return ms
    if sec < 60:
        return rd[5:6] + ms
    if sec < 600:
        return rd[3:6] + ms
    else:
        return rd[2:6] + ms


def strfdelta(tdelta, fmt):
    d = {"D": tdelta.days} if tdelta.days else {"D": ''}
    hours, rem = divmod(tdelta.seconds, 3600)
    minutes, seconds = divmod(rem, 60)
    d["H"] = '{:02d}'.format(hours)
    d["M"] = '{:02d}'.format(minutes)
    d["S"] = '{:02d}'.format(seconds)
    return fmt.format(**d)


def hundred_no_zero(fl):
    if fl == 100 or fl == 0:
        return int(fl)
    else:
        return round(fl, 1)


def float_no_zero(fl):
    if isinstance(fl, int):
        return fl
    if fl.is_integer():
        return int(fl)
    else:
        return fl


def m_to_miles(m, scale):
    return round(m*0.000621371, scale)
