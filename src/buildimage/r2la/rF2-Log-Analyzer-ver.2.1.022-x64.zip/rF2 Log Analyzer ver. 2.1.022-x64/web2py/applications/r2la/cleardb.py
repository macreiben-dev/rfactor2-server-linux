import os
import glob
import shutil

files = glob.glob('databases/*')
for f in files:
    os.remove(f)

shutil.rmtree("sessions")
    
