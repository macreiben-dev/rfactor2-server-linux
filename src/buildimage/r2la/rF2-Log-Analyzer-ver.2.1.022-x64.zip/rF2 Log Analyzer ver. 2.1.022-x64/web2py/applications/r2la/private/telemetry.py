import mmap
import ctypes
import time
import psutil
from gluon.storage import Storage
from collections import deque, defaultdict
import traceback
import os
import json
import math

import la_utils
import datetime

from la_sharedmemory import *


SESSION_CODES = {
    0: 'TestDay',
    1: 'Practice',
    2: 'Practice2',
    3: 'Practice3',
    4: 'Practice4',
    5: 'Qualify',
    6: 'Qualify2',
    7: 'Qualify3',
    8: 'Qualify4',
    9: 'Warmup',
    10: 'Race',
    11: 'Race2',
    12: 'Race3',
    13: 'Race4',
}

RF2_TAG_STRINGS = {
    0: {
        "Scoring": "$rFactor2SMMP_Scoring$",
        "Telemetry": "$rFactor2SMMP_Telemetry$",
    },
    1: {
        "Scoring": "Global\$rFactor2SMMP_Scoring$",
        "Telemetry": "Global\$rFactor2SMMP_Telemetry$",
    },
}

EMPTY_TELEMETRY = {
    'mFrontTireCompoundName': '',
    'mRearTireCompoundName': '',
    'mRearTireCompoundIndex': 0,
    'mFrontTireCompoundIndex': 0,
    'mGear': 0,
    'mEngineRPM': 0,
    'mEngineWaterTemp': 0,
    'mEngineOilTemp': 0,
    'mUnfilteredThrottle': 0,
    'mUnfilteredBrake': 0,
    'mUnfilteredSteering': 0,
    'mUnfilteredClutch': 0,
    'mFrontRideHeight': 0,
    'mRearRideHeight': 0,
    'mFrontDownforce': 0,
    'mRearDownforce': 0,
    'mDrag': 0,
    'mFuel': 0,
    'mBrakeTemp': [0,0,0,0],
    'mTireLoad': [0,0,0,0],
    'mGripFract': [0,0,0,0],
    'mPressure': [0,0,0,0],
    'mTemperature': [0,0,0,0],
    'mSuspensionDeflection': [0,0,0,0],
    'mTireCarcassTemperature': [0,0,0,0],
    'mRideHeight': [0,0,0,0],
    'mRotation': [0,0,0,0],
    'mCamber': [0,0,0,0],
    'mToe': [0,0,0,0],
    'mWear': [0,0,0,0],
}

BEST_TIMES = {}

FAKE_DB = {}
current_ts = None
telemetry_dict = defaultdict(list)
db_dict = {}
writing_lap_num = 0
timer = la_utils.datetime_to_timestamp(datetime.datetime.utcnow())
write_to_disk = True

with open("r2la_telemetry.log", 'w', encoding='utf-8') as f:
    f.write(u"Telemetry process started...\n")


DEFAULT_TELEMETRY_SETTINGS = {
    'record_ai': 0,
}

TELEMETRY_SETTINGS = {}

try:

    settings_path = os.path.join(os.getcwd(), "applications\\r2la\\telemetry_settings.json")
    if not os.path.isfile(settings_path):
        with open(settings_path, 'w', encoding='utf-8') as f:
            f.write(json.dumps(DEFAULT_TELEMETRY_SETTINGS, indent=4, sort_keys=True))

    try:
        with open(settings_path, encoding="utf-8") as f:
            opened_settings = json.loads(f.read())
            assert opened_settings['record_ai'] in (0, 1)
            TELEMETRY_SETTINGS = opened_settings
    except:
        TELEMETRY_SETTINGS = DEFAULT_TELEMETRY_SETTINGS


    print("Telemetry process started...")
    if not TELEMETRY_SETTINGS['record_ai']:
        print("Recording player car data.")
        print("Recording will start when you will leave the pit lane.")
    else:
        print("Recording AI car data.")
        print("Recording will start when AI will leave the pit lane.")


    """
    telemetry_status = db2(db2.telemetry_status.id==1).select().first()
    if not telemetry_status:
        db2.telemetry_status.insert(
            recording=False,
        )
        telemetry_status = db2(db2.telemetry_status.id==1).select().first()
    """

    while True:
        server_processes = []

        server_processes.append({"pid": "", "name": "Local rF2"})
        server_processes.append({"pid": "", "name": "Local rF1"})

        for server_process in server_processes:

            if server_process['name'] == 'Local rF2':
                scoring_buffer = mmap.mmap(0, ctypes.sizeof(rF2Scoring), "$rFactor2SMMP_Scoring$")
                scoring = rF2Scoring.from_buffer(scoring_buffer)

                telemetry_buffer = mmap.mmap(0, ctypes.sizeof(rF2Telemetry), "$rFactor2SMMP_Telemetry$")
                telemetry = rF2Telemetry.from_buffer(telemetry_buffer)

            else:
                scoring_buffer = mmap.mmap(0, ctypes.sizeof(rfShared), "$rFactorShared$")
                rfShared_temp = rfShared.from_buffer(scoring_buffer)
                scoring = Storage()

                if rfShared_temp.session == 6:
                    temp_session = 9
                elif rfShared_temp.session == 7:
                    temp_session = 10
                else:
                    temp_session = rfShared_temp.session

                mScoringInfo = Storage(
                    mTrackName=rfShared_temp.trackName, # this is not a mistake, need bytes here, see track_name var
                    mNumVehicles=rfShared_temp.numVehicles,
                    mSession=temp_session,
                    mCurrentET=rfShared_temp.currentET,
                    mEndET=rfShared_temp.endET,
                    mMaxLaps=rfShared_temp.maxLaps,
                    mLapDist=rfShared_temp.lapDist,
                    mGamePhase=rfShared_temp.gamePhase,
                    mYellowFlagState=rfShared_temp.yellowFlagState,
                    #mSectorFlag=temp_sectorFlag,
                    #'mDarkCloud': scoring.mScoringInfo.mDarkCloud,
                    mRaining=0,
                    mAmbientTemp=rfShared_temp.ambientTemp,
                    mTrackTemp=rfShared_temp.trackTemp,
                    mMinPathWetness=0,
                    mMaxPathWetness=0,
                )

                scoring.mVehicles = []
                telemetry = Storage()
                telemetry.mNumVehicles = rfShared_temp.numVehicles or 0
                telemetry.mVehicles = []

                for _id, v in enumerate(rfShared_temp.vehicle):
                    if v.isPlayer:
                        vehicle = Storage(
                            mID=_id,
                            mDriverName=v.driverName,
                            mVehicleName=v.vehicleClass,
                            mTotalLaps=v.totalLaps,
                            mSector=v.sector,
                            mFinishStatus=v.finishStatus,
                            mLapDist=v.lapDist,
                            mBestSector1=v.bestSector1,
                            mBestSector2=v.bestSector2,
                            mBestLapTime=v.bestLapTime,
                            mLastSector1=v.lastSector1,
                            mLastSector2=v.lastSector2,
                            mLastLapTime=v.lastLapTime,
                            mCurSector1=v.curSector1,
                            mCurSector2=v.curSector2,
                            mNumPitstops=v.numPitstops or "",
                            mIsPlayer=v.isPlayer,
                            mControl=v.control,
                            mInPits=v.inPits,
                            mPlace=v.place,
                            mVehicleClass=v.vehicleClass,
                            mTimeBehindNext=v.timeBehindNext,
                            mTimeBehindLeader=v.timeBehindLeader,
                            mLapsBehindLeader=v.lapsBehindLeader,
                            mInGarageStall=0,
                            mLocalVel=v.localVel,
                        )
                        telemetry1 = Storage(
                            mID=_id,
                            mGear=rfShared_temp.gear,
                            mEngineRPM=rfShared_temp.engineRPM,
                            mEngineWaterTemp=rfShared_temp.engineWaterTemp,
                            mEngineOilTemp=rfShared_temp.engineOilTemp,
                            mUnfilteredThrottle=rfShared_temp.unfilteredThrottle,
                            mUnfilteredBrake=rfShared_temp.unfilteredBrake,
                            mUnfilteredSteering=rfShared_temp.unfilteredSteering,
                            mUnfilteredClutch=rfShared_temp.unfilteredClutch,
                            mFrontRideHeight=0,
                            mRearRideHeight=0,
                            mFrontDownforce=0,
                            mRearDownforce=0,
                            mDrag=0,
                            mFuel=rfShared_temp.fuel,
                            mWheels=[Storage(
                                mBrakeTemp=w.brakeTemp,
                                mTireLoad=w.tireLoad,
                                mGripFract=w.gripFract,
                                mPressure=w.pressure,
                                mTemperature=w.temperature,
                                mSuspensionDeflection=w.suspensionDeflection,
                                mTireCarcassTemperature=0,
                                mRideHeight=w.rideHeight,
                                mRotation=w.rotation,
                                mCamber=0,
                                mToe=0,
                                mWear=w.wear,
                            ) for w in rfShared_temp.wheel],
                        )
                    else:
                        vehicle = Storage(mID=_id,)
                        telemetry1 = Storage(mID=_id)

                    scoring.mVehicles.append(vehicle)
                    telemetry.mVehicles.append(telemetry1)

                scoring.mScoringInfo = mScoringInfo


            track_name = bytearray(scoring.mScoringInfo.mTrackName).decode(encoding="latin_1").split('\x00', 1)[0]
            #print(track_name, scoring.mScoringInfo.mCurrentET, scoring.mScoringInfo.mGamePhase)

            if not track_name:
                continue

            vehicles = []
            telemetry_vehicles = {}

            for i in range(scoring.mScoringInfo.mNumVehicles):
                if (TELEMETRY_SETTINGS['record_ai'] and scoring.mVehicles[i].mIsPlayer) or (not TELEMETRY_SETTINGS['record_ai'] and not scoring.mVehicles[i].mIsPlayer):
                    continue

                v = scoring.mVehicles[i]

                for i in range(telemetry.mNumVehicles):
                    if telemetry.mVehicles[i].mID != v.mID:
                        continue
                    telemetry_vehicles[telemetry.mVehicles[i].mID] = {
                        #'mFrontTireCompoundName': bytearray(telemetry.mVehicles[i].mFrontTireCompoundName).decode(encoding="latin_1").split('\x00', 1)[0],
                        #'mRearTireCompoundName': bytearray(telemetry.mVehicles[i].mRearTireCompoundName).decode(encoding="latin_1").split('\x00', 1)[0],
                        #'mRearTireCompoundIndex': telemetry.mVehicles[i].mRearTireCompoundIndex,
                        #'mFrontTireCompoundIndex': telemetry.mVehicles[i].mFrontTireCompoundIndex,
                        'mGear': telemetry.mVehicles[i].mGear,
                        'mEngineRPM': telemetry.mVehicles[i].mEngineRPM,
                        'mEngineWaterTemp': telemetry.mVehicles[i].mEngineWaterTemp,
                        'mEngineOilTemp': telemetry.mVehicles[i].mEngineOilTemp,
                        'mUnfilteredThrottle': telemetry.mVehicles[i].mUnfilteredThrottle*100,
                        'mUnfilteredBrake': telemetry.mVehicles[i].mUnfilteredBrake*100,
                        'mUnfilteredSteering': telemetry.mVehicles[i].mUnfilteredSteering * -100,
                        'mUnfilteredClutch': telemetry.mVehicles[i].mUnfilteredClutch*100,
                        'mFrontRideHeight': telemetry.mVehicles[i].mFrontRideHeight*1000,
                        'mRearRideHeight': telemetry.mVehicles[i].mRearRideHeight*1000,
                        'mFrontDownforce': telemetry.mVehicles[i].mFrontDownforce,
                        'mRearDownforce': telemetry.mVehicles[i].mRearDownforce,
                        'mDrag': telemetry.mVehicles[i].mDrag,
                        'mFuel': telemetry.mVehicles[i].mFuel,
                        'mBrakeTemp': [
                            telemetry.mVehicles[i].mWheels[0].mBrakeTemp,
                            telemetry.mVehicles[i].mWheels[1].mBrakeTemp,
                            telemetry.mVehicles[i].mWheels[2].mBrakeTemp,
                            telemetry.mVehicles[i].mWheels[3].mBrakeTemp,
                        ],
                        'mTireLoad': [
                            telemetry.mVehicles[i].mWheels[0].mTireLoad,
                            telemetry.mVehicles[i].mWheels[1].mTireLoad,
                            telemetry.mVehicles[i].mWheels[2].mTireLoad,
                            telemetry.mVehicles[i].mWheels[3].mTireLoad,
                        ],
                        'mGripFract': [
                            telemetry.mVehicles[i].mWheels[0].mGripFract*100,
                            telemetry.mVehicles[i].mWheels[1].mGripFract*100,
                            telemetry.mVehicles[i].mWheels[2].mGripFract*100,
                            telemetry.mVehicles[i].mWheels[3].mGripFract*100,
                        ],
                        'mPressure': [
                            telemetry.mVehicles[i].mWheels[0].mPressure,
                            telemetry.mVehicles[i].mWheels[1].mPressure,
                            telemetry.mVehicles[i].mWheels[2].mPressure,
                            telemetry.mVehicles[i].mWheels[3].mPressure,
                        ],
                        'mTemperature': [
                            sum(telemetry.mVehicles[i].mWheels[0].mTemperature)/3-273.15,
                            sum(telemetry.mVehicles[i].mWheels[1].mTemperature)/3-273.15,
                            sum(telemetry.mVehicles[i].mWheels[2].mTemperature)/3-273.15,
                            sum(telemetry.mVehicles[i].mWheels[3].mTemperature)/3-273.15,
                        ],
                        'mSuspensionDeflection': [
                            telemetry.mVehicles[i].mWheels[0].mSuspensionDeflection*1000,
                            telemetry.mVehicles[i].mWheels[1].mSuspensionDeflection*1000,
                            telemetry.mVehicles[i].mWheels[2].mSuspensionDeflection*1000,
                            telemetry.mVehicles[i].mWheels[3].mSuspensionDeflection*1000,
                        ],
                        'mTireCarcassTemperature': [
                            telemetry.mVehicles[i].mWheels[0].mTireCarcassTemperature-273.15,
                            telemetry.mVehicles[i].mWheels[1].mTireCarcassTemperature-273.15,
                            telemetry.mVehicles[i].mWheels[2].mTireCarcassTemperature-273.15,
                            telemetry.mVehicles[i].mWheels[3].mTireCarcassTemperature-273.15,
                        ],
                        'mRideHeight': [
                            telemetry.mVehicles[i].mWheels[0].mRideHeight*1000,
                            telemetry.mVehicles[i].mWheels[1].mRideHeight*1000,
                            telemetry.mVehicles[i].mWheels[2].mRideHeight*1000,
                            telemetry.mVehicles[i].mWheels[3].mRideHeight*1000,
                        ],
                        'mRotation': [
                            telemetry.mVehicles[i].mWheels[0].mRotation * -1,
                            telemetry.mVehicles[i].mWheels[1].mRotation * -1,
                            telemetry.mVehicles[i].mWheels[2].mRotation * -1,
                            telemetry.mVehicles[i].mWheels[3].mRotation * -1,
                        ],
                        'mCamber': [
                            math.degrees(telemetry.mVehicles[i].mWheels[0].mCamber),
                            math.degrees(telemetry.mVehicles[i].mWheels[1].mCamber),
                            math.degrees(telemetry.mVehicles[i].mWheels[2].mCamber),
                            math.degrees(telemetry.mVehicles[i].mWheels[3].mCamber),
                        ],
                        'mToe': [
                            math.degrees(telemetry.mVehicles[i].mWheels[0].mToe),
                            math.degrees(telemetry.mVehicles[i].mWheels[1].mToe),
                            math.degrees(telemetry.mVehicles[i].mWheels[2].mToe),
                            math.degrees(telemetry.mVehicles[i].mWheels[3].mToe),
                        ],
                        'mWear': [
                            telemetry.mVehicles[i].mWheels[0].mWear*100,
                            telemetry.mVehicles[i].mWheels[1].mWear*100,
                            telemetry.mVehicles[i].mWheels[2].mWear*100,
                            telemetry.mVehicles[i].mWheels[3].mWear*100,
                        ],
                    }
                    break



                # telemetry.mVehicles is not always in sync with mScoringInfo.mNumVehicles
                if v.mID in telemetry_vehicles:
                    telemetry_out = telemetry_vehicles[v.mID]
                else:
                    telemetry_out = EMPTY_TELEMETRY

                vehicle = {
                    'mID': v.mID,
                    'mDriverName': bytearray(v.mDriverName).decode(encoding="latin_1").split('\x00', 1)[0],
                    'mVehicleName': bytearray(v.mVehicleName).decode(encoding="latin_1").split('\x00', 1)[0],
                    'mTotalLaps': v.mTotalLaps,
                    'mSector': v.mSector,
                    'mFinishStatus': v.mFinishStatus,
                    'mLapDist': v.mLapDist,
                    #'mPathLateral': v.mPathLateral,
                    #'mTrackEdge': v.mTrackEdge,
                    'mBestSector1': v.mBestSector1,
                    'mBestSector2': v.mBestSector2,
                    'mBestLapTime': v.mBestLapTime,
                    'mLastSector1': v.mLastSector1,
                    'mLastSector2': v.mLastSector2,
                    'mLastLapTime': v.mLastLapTime,
                    'mCurSector1': v.mCurSector1,
                    'mCurSector2': v.mCurSector2,
                    'mNumPitstops': v.mNumPitstops or "",
                    #'mNumPenalties': v.mNumPenalties,
                    'mIsPlayer': v.mIsPlayer,
                    'mControl': v.mControl,
                    'mInPits': v.mInPits,
                    'mPlace': v.mPlace,
                    'mVehicleClass': bytearray(v.mVehicleClass).decode(encoding="latin_1").split('\x00', 1)[0],
                    'mTimeBehindNext': v.mTimeBehindNext,
                    #'mLapsBehindNext': v.mLapsBehindNext,
                    'mTimeBehindLeader': v.mTimeBehindLeader,
                    'mLapsBehindLeader': v.mLapsBehindLeader,
                    'mLapStartET': v.mLapStartET,
                    #'mPos', v.mPos,
                    'mLocalVel': v.mLocalVel,
                    #'mLocalAccel': v.mLocalAccel,
                    #'mOri': list(v.mOri), ?
                    #'mLocalRot': v.LocalRot,
                    #'mLocalRotAccel': v.mLocalRotAccel,
                    #'mHeadlights': v.mHeadlights,
                    #'mPitState': v.mPitState,
                    #'mServerScored': v.mServerScored,
                    #'mIndividualPhase': v.mIndividualPhase,
                    #'mQualification': v.mQualification,
                    #'mTimeIntoLap': scoring.mScoringInfo.mCurrentET-v.mLapStartET, #v.mTimeIntoLap,
                    #'mEstimatedLapTime': v.mEstimatedLapTime,
                    #'mPitGroup': bytearray(v.mPitGroup).decode(encoding="latin_1").split('\x00', 1)[0],
                    #'mFlag': v.mFlag,
                    #'mUnderYellow': v.mUnderYellow,
                    #'mCountLapFlag': v.mCountLapFlag,
                    'mInGarageStall': v.mInGarageStall,
                    #'mUpgradePack': v.mUpgradePack,
                    #'mExpansion': v.mExpansion,
                    #"mFrontTireCompoundName": telemetry_out['mFrontTireCompoundName'],
                    #"mRearTireCompoundName": telemetry_out['mRearTireCompoundName'],
                    #'mRearTireCompoundIndex': telemetry_out['mRearTireCompoundIndex'],
                    #'mFrontTireCompoundIndex': telemetry_out['mFrontTireCompoundIndex'],
                    'mGear': telemetry_out['mGear'],
                    'mEngineRPM': telemetry_out['mEngineRPM'],
                    'mEngineWaterTemp': telemetry_out['mEngineWaterTemp'],
                    'mEngineOilTemp': telemetry_out['mEngineOilTemp'],
                    'mUnfilteredThrottle': telemetry_out['mUnfilteredThrottle'],
                    'mUnfilteredBrake': telemetry_out['mUnfilteredBrake'],
                    'mUnfilteredSteering': telemetry_out['mUnfilteredSteering'],
                    'mUnfilteredClutch': telemetry_out['mUnfilteredClutch'],
                    'mFrontRideHeight': telemetry_out['mFrontRideHeight'],
                    'mRearRideHeight': telemetry_out['mRearRideHeight'],
                    'mFrontDownforce': telemetry_out['mFrontDownforce'],
                    'mRearDownforce': telemetry_out['mRearDownforce'],
                    'mDrag': telemetry_out['mDrag'],
                    'mFuel': telemetry_out['mFuel'],
                    'mBrakeTemp': telemetry_out['mBrakeTemp'],
                    'mTireLoad': telemetry_out['mTireLoad'],
                    'mGripFract': telemetry_out['mGripFract'],
                    'mPressure': telemetry_out['mPressure'],
                    'mTemperature': telemetry_out['mTemperature'],
                    'mSuspensionDeflection': telemetry_out['mSuspensionDeflection'],
                    'mTireCarcassTemperature': telemetry_out['mTireCarcassTemperature'],
                    'mRideHeight': telemetry_out['mRideHeight'],
                    'mRotation': telemetry_out['mRotation'],
                    'mCamber': telemetry_out['mCamber'],
                    'mToe': telemetry_out['mToe'],
                    'mWear': telemetry_out['mWear'],

                }
                vehicles.append(vehicle)

                break


            if scoring.mScoringInfo.mGamePhase in (0, 4) or scoring.mScoringInfo.mCurrentET < 2:
                # reset best times on session start

                #print(la_utils.datetime_to_timestamp(datetime.datetime.utcnow())-int(scoring.mScoringInfo.mCurrentET), int(scoring.mScoringInfo.mCurrentET), datetime.datetime.utcnow())

                #telemetry_dict = defaultdict(list)
                current_ts = la_utils.datetime_to_timestamp(datetime.datetime.utcnow())-int(scoring.mScoringInfo.mCurrentET)
                #print("Session switch, current_ts set to ", current_ts, int(scoring.mScoringInfo.mCurrentET))

            else:
                if current_ts is None:
                    current_ts = la_utils.datetime_to_timestamp(datetime.datetime.utcnow())-int(scoring.mScoringInfo.mCurrentET)
                    #print("current_ts was None, set to ", current_ts, int(scoring.mScoringInfo.mCurrentET))

            if vehicles:
                v = vehicles[0]
            else:
                break
            #for v in vehicles:
            #    if v['mIsPlayer']:
            #        break

            """
            time_now = la_utils.datetime_to_timestamp(datetime.datetime.utcnow())
            time_diff = time_now - timer
            if time_diff > 1:
                timer = time_now
                write_to_disk = True
            """

            #if v is not None:
            if not v['mInPits']:

                writing_lap_num = v['mTotalLaps']

                # this is true on first lap(telemetry_dict['mLapDist'] pos) out and on any position on track
                #if not (telemetry_dict['mLapDist'] and telemetry_dict['mLapDist'][-1] >= v['mLapDist']):

                if writing_lap_num not in db_dict:
                    #print('Creating db_dict[', writing_lap_num, ']')
                    db_dict[writing_lap_num] = {
                        'ts': current_ts,
                        'lap': writing_lap_num,
                        'track': track_name,
                        'vehicle': v['mVehicleName'],
                        'lap_dist': scoring.mScoringInfo.mLapDist,
                        'session_name': SESSION_CODES[scoring.mScoringInfo.mSession],
                        'info': defaultdict(list)
                    }

                    previous_lap_num = writing_lap_num - 1
                    if previous_lap_num > 0:
                        s1 = s2 = s3 = laptime = 0
                        if v['mLastSector1'] > 0:
                            s1 = v['mLastSector1']
                        s2_temp = v['mLastSector2'] - v['mLastSector1']
                        if s2_temp > 0:
                            s2 = s2_temp
                        s3_temp = v['mLastLapTime'] - v['mLastSector2']
                        if s3_temp > 0:
                            s3 = s3_temp
                        if v['mLastLapTime'] > 0:
                            laptime = v['mLastLapTime']

                        #previous_lap_data = db2((db2.telemetry.lap==previous_lap_num) & (db2.telemetry.ts==current_ts)).select().first()
                        #if previous_lap_data:
                        if previous_lap_num in db_dict:
                            db_dict[previous_lap_num]['s1'] = s1
                            db_dict[previous_lap_num]['s2'] = s2
                            db_dict[previous_lap_num]['s3'] = s3
                            db_dict[previous_lap_num]['laptime'] = laptime


                """
                lap_data = db2((db2.telemetry.lap==v['mTotalLaps']) & (db2.telemetry.ts==current_ts)).select().first()
                if not lap_data:
                    #print("new_id created with ts", current_ts, int(scoring.mScoringInfo.mCurrentET))
                    new_id = db2.telemetry.insert(
                        ts=current_ts,
                        lap=v['mTotalLaps'],
                        track=track_name,
                        vehicle=v['mVehicleName'],
                        lap_dist=scoring.mScoringInfo.mLapDist,
                        session_name=SESSION_CODES[scoring.mScoringInfo.mSession],
                    )
                    lap_data = db2(db2.telemetry.id==new_id).select().first()
                """

                # do not write next lap data after sf line is crossed
                #if not (telemetry_dict['mLapDist'] and telemetry_dict['mLapDist'][-1] > v['mLapDist']):

                speed = math.sqrt((v['mLocalVel'].x*v['mLocalVel'].x) + (v['mLocalVel'].y*v['mLocalVel'].y) + (v['mLocalVel'].z * v['mLocalVel'].z)) * 3.6
                db_dict[writing_lap_num]['info']['mLapDist'].append(v['mLapDist'])
                db_dict[writing_lap_num]['info']['speed'].append(speed)
                db_dict[writing_lap_num]['info']['mGear'].append(v['mGear'])
                db_dict[writing_lap_num]['info']['mEngineRPM'].append(v['mEngineRPM'])
                db_dict[writing_lap_num]['info']['mEngineWaterTemp'].append(v['mEngineWaterTemp'])
                db_dict[writing_lap_num]['info']['mEngineOilTemp'].append(v['mEngineOilTemp'])
                db_dict[writing_lap_num]['info']['mUnfilteredThrottle'].append(v['mUnfilteredThrottle'])
                db_dict[writing_lap_num]['info']['mUnfilteredBrake'].append(v['mUnfilteredBrake'])
                db_dict[writing_lap_num]['info']['mUnfilteredSteering'].append(v['mUnfilteredSteering'])
                db_dict[writing_lap_num]['info']['mUnfilteredClutch'].append(v['mUnfilteredClutch'])
                db_dict[writing_lap_num]['info']['mFrontRideHeight'].append(v['mFrontRideHeight'])
                db_dict[writing_lap_num]['info']['mRearRideHeight'].append(v['mRearRideHeight'])
                db_dict[writing_lap_num]['info']['mFrontDownforce'].append(v['mFrontDownforce'])
                db_dict[writing_lap_num]['info']['mRearDownforce'].append(v['mRearDownforce'])
                db_dict[writing_lap_num]['info']['mDrag'].append(v['mDrag'])
                db_dict[writing_lap_num]['info']['mFuel'].append(v['mFuel'])
                db_dict[writing_lap_num]['info']['FL_mBrakeTemp'].append(v['mBrakeTemp'][0])
                db_dict[writing_lap_num]['info']['FR_mBrakeTemp'].append(v['mBrakeTemp'][1])
                db_dict[writing_lap_num]['info']['RL_mBrakeTemp'].append(v['mBrakeTemp'][2])
                db_dict[writing_lap_num]['info']['RR_mBrakeTemp'].append(v['mBrakeTemp'][3])
                db_dict[writing_lap_num]['info']['FL_mTireLoad'].append(v['mTireLoad'][0])
                db_dict[writing_lap_num]['info']['FR_mTireLoad'].append(v['mTireLoad'][1])
                db_dict[writing_lap_num]['info']['RL_mTireLoad'].append(v['mTireLoad'][2])
                db_dict[writing_lap_num]['info']['RR_mTireLoad'].append(v['mTireLoad'][3])
                db_dict[writing_lap_num]['info']['FL_mGripFract'].append(v['mGripFract'][0])
                db_dict[writing_lap_num]['info']['FR_mGripFract'].append(v['mGripFract'][1])
                db_dict[writing_lap_num]['info']['RL_mGripFract'].append(v['mGripFract'][2])
                db_dict[writing_lap_num]['info']['RR_mGripFract'].append(v['mGripFract'][3])
                db_dict[writing_lap_num]['info']['FL_mPressure'].append(v['mPressure'][0])
                db_dict[writing_lap_num]['info']['FR_mPressure'].append(v['mPressure'][1])
                db_dict[writing_lap_num]['info']['RL_mPressure'].append(v['mPressure'][2])
                db_dict[writing_lap_num]['info']['RR_mPressure'].append(v['mPressure'][3])
                db_dict[writing_lap_num]['info']['FL_mTemperature'].append(v['mTemperature'][0])
                db_dict[writing_lap_num]['info']['FR_mTemperature'].append(v['mTemperature'][1])
                db_dict[writing_lap_num]['info']['RL_mTemperature'].append(v['mTemperature'][2])
                db_dict[writing_lap_num]['info']['RR_mTemperature'].append(v['mTemperature'][3])
                db_dict[writing_lap_num]['info']['FL_mTireCarcassTemperature'].append(v['mTireCarcassTemperature'][0])
                db_dict[writing_lap_num]['info']['FR_mTireCarcassTemperature'].append(v['mTireCarcassTemperature'][1])
                db_dict[writing_lap_num]['info']['RL_mTireCarcassTemperature'].append(v['mTireCarcassTemperature'][2])
                db_dict[writing_lap_num]['info']['RR_mTireCarcassTemperature'].append(v['mTireCarcassTemperature'][3])
                db_dict[writing_lap_num]['info']['FL_mSuspensionDeflection'].append(v['mSuspensionDeflection'][0])
                db_dict[writing_lap_num]['info']['FR_mSuspensionDeflection'].append(v['mSuspensionDeflection'][1])
                db_dict[writing_lap_num]['info']['RL_mSuspensionDeflection'].append(v['mSuspensionDeflection'][2])
                db_dict[writing_lap_num]['info']['RR_mSuspensionDeflection'].append(v['mSuspensionDeflection'][3])
                db_dict[writing_lap_num]['info']['FL_mRideHeight'].append(v['mRideHeight'][0])
                db_dict[writing_lap_num]['info']['FR_mRideHeight'].append(v['mRideHeight'][1])
                db_dict[writing_lap_num]['info']['RL_mRideHeight'].append(v['mRideHeight'][2])
                db_dict[writing_lap_num]['info']['RR_mRideHeight'].append(v['mRideHeight'][3])
                db_dict[writing_lap_num]['info']['FL_mRotation'].append(v['mRotation'][0])
                db_dict[writing_lap_num]['info']['FR_mRotation'].append(v['mRotation'][1])
                db_dict[writing_lap_num]['info']['RL_mRotation'].append(v['mRotation'][2])
                db_dict[writing_lap_num]['info']['RR_mRotation'].append(v['mRotation'][3])
                db_dict[writing_lap_num]['info']['FL_mCamber'].append(v['mCamber'][0])
                db_dict[writing_lap_num]['info']['FR_mCamber'].append(v['mCamber'][1])
                db_dict[writing_lap_num]['info']['RL_mCamber'].append(v['mCamber'][2])
                db_dict[writing_lap_num]['info']['RR_mCamber'].append(v['mCamber'][3])
                db_dict[writing_lap_num]['info']['FL_mToe'].append(v['mToe'][0])
                db_dict[writing_lap_num]['info']['FR_mToe'].append(v['mToe'][1])
                db_dict[writing_lap_num]['info']['RL_mToe'].append(v['mToe'][2])
                db_dict[writing_lap_num]['info']['RR_mToe'].append(v['mToe'][3])
                #db_dict[writing_lap_num]['info']['mTimeIntoLap'].append(v['mTimeIntoLap']) # not working?
                db_dict[writing_lap_num]['info']['FL_mWear'].append(v['mWear'][0])
                db_dict[writing_lap_num]['info']['FR_mWear'].append(v['mWear'][1])
                db_dict[writing_lap_num]['info']['RL_mWear'].append(v['mWear'][2])
                db_dict[writing_lap_num]['info']['RR_mWear'].append(v['mWear'][3])

                """
                if write_to_disk:
                    #print('Writing', v['mDriverName'], "lap #", v['mTotalLaps'], v['mLapDist'])
                    lap_data.update_record(info=telemetry_dict)

                    #telemetry_status = db2(db2.telemetry_status.id==1).select().first()
                    #telemetry_status.update_record(recording=True)
                    db2.commit()
                # ----
                """


            else:

                #print(scoring.mScoringInfo.mCurrentET, bool(db_dict))
                if db_dict:
                    print('Writing telemetry data to database...')
                    for lap_num, lap_dict in db_dict.items():
                        print('Lap #'+str(lap_num))
                        new_id = db2.telemetry.insert(
                            ts=current_ts,
                            lap=lap_num,
                            track=lap_dict['track'],
                            vehicle=lap_dict['vehicle'],
                            lap_dist=lap_dict['lap_dist'],
                            session_name=lap_dict['session_name'],
                            info=lap_dict['info'],
                            s1=lap_dict.get('s1', 0),
                            s2=lap_dict.get('s2', 0),
                            s3=lap_dict.get('s3', 0),
                            laptime=lap_dict.get('laptime', 0),
                        )

                    db2.commit()
                    print('Writing finished.')
                    db_dict = {}

            #write_to_disk = False

            #live_data_out[server_process['name']] = out


        time.sleep(.2)

except:
    message = traceback.format_exc()
    print (message)
    with open("r2la_telemetry.log", 'a', encoding='utf-8') as f:
        f.write(message)
