rF2 Log Analyzer DEDI is a mode of r2la for dedicated servers. You can host it on your dedicated server
for your community to browse and manage log files, view track records for all drivers and manage championships.

Instructions for league and server admins.

1. Unzip "rF2 Log Analyzer ver. 2.x" folder somewhere on your dedicated server.

2. First we need to start web2py server in localhost mode to set admin account and rF2 path.

3. Start rF2 Log Analyzer ver. 2.x\web2py\web2py.exe. Select "Local" server IP. Press "Start server".

4. Go to address http://127.0.0.1:8000/ in a browser on dedicated server.

5. Fill out the form. Set rFactor2 path on this dedicated server or path to your log files directly, check "DEDI mode", fill out administrator Nick/Name and password fields. Press "Start r2la" button.

6. If r2la DEDI finds your rF2 dir and starts, you can close web2py server (web2py.exe).

7. Start rF2 Log Analyzer ver. 2.x\web2py\web2py.exe again.

8. Now select "Public" server IP (choose option with your dedicated server IP).

9. As long as web2py.exe will be running other people will be able access r2la DEDI at chosen IP and port.

10. Admin (or admins) of your community must login to r2la DEDI with Nick/Name and password entered in step 5.

11. When logged in, admin will see all the buttons to manage r2la DEDI.

12. Like in r2la, admin must press "Refresh" button for r2la DEDI to pick-up new xml logs.