import ctypes


MAX_MAPPED_VEHICLES = 128
MAX_MAPPED_IDS = 512


class rF2Vec3(ctypes.Structure):
    _pack_ = 4
    _fields_ = [
        ('x', ctypes.c_double),
        ('y', ctypes.c_double),
        ('z', ctypes.c_double),
    ]

# sbyte = ctypes.c_byte
# byte = ctypes.c_ubyte

class rF2Wheel(ctypes.Structure):
    _pack_ = 4
    _fields_ = [
        ('mSuspensionDeflection', ctypes.c_double),
        ('mRideHeight', ctypes.c_double),
        ('mSuspForce', ctypes.c_double),
        ('mBrakeTemp', ctypes.c_double),
        ('mBrakePressure', ctypes.c_double),
        ('mRotation', ctypes.c_double),
        ('mLateralPatchVel', ctypes.c_double),
        ('mLongitudinalPatchVel', ctypes.c_double),
        ('mLateralGroundVel', ctypes.c_double),
        ('mLongitudinalGroundVel', ctypes.c_double),
        ('mCamber', ctypes.c_double),
        ('mLateralForce', ctypes.c_double),
        ('mLongitudinalForce', ctypes.c_double),
        ('mTireLoad', ctypes.c_double),
        ('mGripFract', ctypes.c_double),
        ('mPressure', ctypes.c_double),
        ('mTemperature', ctypes.c_double*3),
        ('mWear', ctypes.c_double),
        ('mTerrainName', ctypes.c_ubyte*16),
        ('mSurfaceType', ctypes.c_ubyte),
        ('mFlat', ctypes.c_ubyte),
        ('mDetached', ctypes.c_ubyte),
        ('mVerticalTireDeflection', ctypes.c_double),
        ('mWheelYLocation', ctypes.c_double),
        ('mToe', ctypes.c_double),
        ('mTireCarcassTemperature', ctypes.c_double),
        ('mTireInnerLayerTemperature', ctypes.c_double*3),
        ('mExpansion', ctypes.c_ubyte*24),
    ]


class rF2VehicleTelemetry(ctypes.Structure):
    _pack_ = 4
    _fields_ = [
        ('mID', ctypes.c_int),
        ('mDeltaTime', ctypes.c_double),
        ('mElapsedTime', ctypes.c_double),
        ('mLapNumber', ctypes.c_int),
        ('mLapStartET', ctypes.c_double),
        ('mVehicleName', ctypes.c_ubyte*64), # byte
        ('mTrackName', ctypes.c_ubyte*64), # byte
        ('mPos', rF2Vec3),
        ('mLocalVel', rF2Vec3),
        ('mLocalAccel', rF2Vec3),
        ('mOri', rF2Vec3*3),
        ('mLocalRot', rF2Vec3),
        ('mLocalRotAccel', rF2Vec3),
        ('mGear', ctypes.c_int),
        ('mEngineRPM', ctypes.c_double),
        ('mEngineWaterTemp', ctypes.c_double),
        ('mEngineOilTemp', ctypes.c_double),
        ('mClutchRPM', ctypes.c_double),
        ('mUnfilteredThrottle', ctypes.c_double),
        ('mUnfilteredBrake', ctypes.c_double),
        ('mUnfilteredSteering', ctypes.c_double),
        ('mUnfilteredClutch', ctypes.c_double),
        ('mFilteredThrottle', ctypes.c_double),
        ('mFilteredBrake', ctypes.c_double),
        ('mFilteredSteering', ctypes.c_double),
        ('mFilteredClutch', ctypes.c_double),
        ('mSteeringShaftTorque', ctypes.c_double),
        ('mFront3rdDeflection', ctypes.c_double),
        ('mRear3rdDeflection', ctypes.c_double),
        ('mFrontWingHeight', ctypes.c_double),
        ('mFrontRideHeight', ctypes.c_double),
        ('mRearRideHeight', ctypes.c_double),
        ('mDrag', ctypes.c_double),
        ('mFrontDownforce', ctypes.c_double),
        ('mRearDownforce', ctypes.c_double),
        ('mFuel', ctypes.c_double),
        ('mEngineMaxRPM', ctypes.c_double),
        ('mScheduledStops', ctypes.c_ubyte), # byte
        ('mOverheating', ctypes.c_ubyte), # byte
        ('mDetached', ctypes.c_ubyte), # byte
        ('mHeadlights', ctypes.c_ubyte), # byte
        ('mDentSeverity', ctypes.c_ubyte*8), # byte
        ('mLastImpactET', ctypes.c_double),
        ('mLastImpactMagnitude', ctypes.c_double),
        ('mLastImpactPos', rF2Vec3),
        ('mEngineTorque', ctypes.c_double),
        ('mCurrentSector', ctypes.c_int),
        ('mSpeedLimiter', ctypes.c_ubyte), # byte
        ('mMaxGears', ctypes.c_ubyte), # byte
        ('mFrontTireCompoundIndex', ctypes.c_ubyte), # byte
        ('mRearTireCompoundIndex', ctypes.c_ubyte), # byte
        ('mFuelCapacity', ctypes.c_double),
        ('mFrontFlapActivated', ctypes.c_ubyte), # byte
        ('mRearFlapActivated', ctypes.c_ubyte), # byte
        ('mRearFlapLegalStatus', ctypes.c_ubyte), # byte
        ('mIgnitionStarter', ctypes.c_ubyte), # byte
        ('mFrontTireCompoundName', ctypes.c_ubyte*18), # byte
        ('mRearTireCompoundName', ctypes.c_ubyte*18), # byte
        ('mSpeedLimiterAvailable', ctypes.c_ubyte), # byte
        ('mAntiStallActivated', ctypes.c_ubyte), # byte
        ('mUnused', ctypes.c_ubyte*2), # byte
        ('mVisualSteeringWheelRange', ctypes.c_float),
        ('mRearBrakeBias', ctypes.c_double),
        ('mTurboBoostPressure', ctypes.c_double),
        ('mPhysicsToGraphicsOffset', ctypes.c_float*3),
        ('mPhysicalSteeringWheelRange', ctypes.c_float),
        ('mExpansion', ctypes.c_ubyte*152), # byte
        ('mWheels', rF2Wheel*4), # byte
    ]


class rF2Telemetry(ctypes.Structure):
    _pack_ = 4
    _fields_ = [
        ('mVersionUpdateBegin', ctypes.c_uint),
        ('mVersionUpdateEnd', ctypes.c_uint),
        ('mBytesUpdatedHint', ctypes.c_int),
        ('mNumVehicles', ctypes.c_int),
        ('mVehicles', rF2VehicleTelemetry*MAX_MAPPED_VEHICLES),
    ]


class rF2ScoringInfo(ctypes.Structure):
    _pack_ = 4
    _fields_ = [
        ('mTrackName', ctypes.c_ubyte*64), # byte
        ('mSession', ctypes.c_int),
        ('mCurrentET', ctypes.c_double),
        ('mEndET', ctypes.c_double),
        ('mMaxLaps', ctypes.c_int),
        ('mLapDist', ctypes.c_double),
        ('pointer1', ctypes.c_ubyte*8), # byte
        ('mNumVehicles', ctypes.c_int),
        ('mGamePhase', ctypes.c_ubyte), # byte
        ('mYellowFlagState', ctypes.c_byte), # sbyte
        ('mSectorFlag', ctypes.c_byte*3), # sbyte
        ('mStartLight', ctypes.c_ubyte), # byte
        ('mNumRedLights', ctypes.c_ubyte), # byte
        ('mInRealtime', ctypes.c_ubyte), # byte
        ('mPlayerName', ctypes.c_ubyte*32), # byte
        ('mPlrFileName', ctypes.c_ubyte*64), # byte
        ('mDarkCloud', ctypes.c_double),
        ('mRaining', ctypes.c_double),
        ('mAmbientTemp', ctypes.c_double),
        ('mTrackTemp', ctypes.c_double),
        ('mWind', rF2Vec3),
        ('mMinPathWetness', ctypes.c_double),
        ('mMaxPathWetness', ctypes.c_double),

        ('mGameMode', ctypes.c_ubyte), # byte
        ('mIsPasswordProtected', ctypes.c_ubyte), # byte
        ('mServerPort', ctypes.c_ushort),
        ('mServerPublicIP', ctypes.c_ulong),
        ('mMaxPlayers', ctypes.c_int),
        ('mServerName', ctypes.c_ubyte*32), # byte
        ('mStartET', ctypes.c_float),
        ('mAvgPathWetness', ctypes.c_double),

        ('mExpansion', ctypes.c_ubyte*200), # byte
        ('pointer2', ctypes.c_ubyte*8), # byte
    ]


class rF2VehicleScoring(ctypes.Structure):
    _pack_ = 4
    _fields_ = [
        ('mID', ctypes.c_int),
        ('mDriverName', ctypes.c_ubyte*32), # byte
        ('mVehicleName', ctypes.c_ubyte*64), # byte
        ('mTotalLaps', ctypes.c_short),
        ('mSector', ctypes.c_byte), # sbyte
        ('mFinishStatus', ctypes.c_byte), # sbyte
        ('mLapDist', ctypes.c_double),
        ('mPathLateral', ctypes.c_double),
        ('mTrackEdge', ctypes.c_double),
        ('mBestSector1', ctypes.c_double),
        ('mBestSector2', ctypes.c_double),
        ('mBestLapTime', ctypes.c_double),
        ('mLastSector1', ctypes.c_double),
        ('mLastSector2', ctypes.c_double),
        ('mLastLapTime', ctypes.c_double),
        ('mCurSector1', ctypes.c_double),
        ('mCurSector2', ctypes.c_double),
        ('mNumPitstops', ctypes.c_short),
        ('mNumPenalties', ctypes.c_short),
        ('mIsPlayer', ctypes.c_ubyte),  # byte
        ('mControl', ctypes.c_byte), # sbyte
        ('mInPits', ctypes.c_ubyte), # byte
        ('mPlace', ctypes.c_ubyte), # byte
        ('mVehicleClass', ctypes.c_ubyte*32), # byte
        ('mTimeBehindNext', ctypes.c_double),
        ('mLapsBehindNext', ctypes.c_int),
        ('mTimeBehindLeader', ctypes.c_double),
        ('mLapsBehindLeader', ctypes.c_int),
        ('mLapStartET', ctypes.c_double),
        ('mPos', rF2Vec3),
        ('mLocalVel', rF2Vec3),
        ('mLocalAccel', rF2Vec3),
        ('mOri', rF2Vec3*3),
        ('mLocalRot', rF2Vec3),
        ('mLocalRotAccel', rF2Vec3),
        ('mHeadlights', ctypes.c_ubyte), # byte
        ('mPitState', ctypes.c_ubyte), # byte
        ('mServerScored', ctypes.c_ubyte), # byte
        ('mIndividualPhase', ctypes.c_ubyte), # byte
        ('mQualification', ctypes.c_int),
        ('mTimeIntoLap', ctypes.c_double),
        ('mEstimatedLapTime', ctypes.c_double),
        ('mPitGroup', ctypes.c_ubyte*24),  # byte
        ('mFlag', ctypes.c_ubyte),  # byte
        ('mUnderYellow', ctypes.c_ubyte),  # byte
        ('mCountLapFlag', ctypes.c_ubyte),  # byte
        ('mInGarageStall', ctypes.c_ubyte),  # byte
        ('mUpgradePack', ctypes.c_ubyte*16),  # byte
        ('mExpansion', ctypes.c_ubyte*60),  # byte
    ]


class rF2Scoring(ctypes.Structure):
    _pack_ = 4
    _fields_ = [
        ('mVersionUpdateBegin', ctypes.c_uint),
        ('mVersionUpdateEnd', ctypes.c_uint),
        ('mBytesUpdatedHint', ctypes.c_int),
        ('mScoringInfo', rF2ScoringInfo),
        ('mVehicles', rF2VehicleScoring*MAX_MAPPED_VEHICLES),
    ]

# ------------------

class rfVec3(ctypes.Structure):
    _pack_ = 1
    _fields_ = [
        ('x', ctypes.c_float),
		('y', ctypes.c_float),
		('z', ctypes.c_float)]


class rfWheel(ctypes.Structure):
    _pack_ = 1
    _fields_ = [
        ('rotation', ctypes.c_float),			# radians/sec
		('suspensionDeflection', ctypes.c_float),# meters
		('rideHeight', ctypes.c_float),		# meters
		('tireLoad', ctypes.c_float),			# Newtons
		('lateralForce', ctypes.c_float),		# Newtons
		('gripFract', ctypes.c_float),			# an approximation of what fraction of the contact patch is sliding
		('brakeTemp', ctypes.c_float),			# Celsius
		('pressure', ctypes.c_float),			# kPa
		('temperature', ctypes.c_float*3),		# Celsius, left/center/right (not to be confused with inside/center/outside!)
		('wear', ctypes.c_float),				# wear (0.0-1.0, fraction of maximum) ... this is not necessarily proportional with grip loss
		('terrainName', ctypes.c_char*16),		# the material prefixes from the TDF file
		('surfaceType', ctypes.c_int8),		# rfSurfaceType
		('flat', ctypes.c_bool),				# whether tire is flat
		('detached', ctypes.c_bool)]			# whether wheel is detached


class rfVehicleInfo(ctypes.Structure):
    _pack_ = 1
    _fields_ = [
        ('driverName', ctypes.c_char*32),		# driver name
		('vehicleName', ctypes.c_char*64),		# vehicle name
		('totalLaps', ctypes.c_short),			# laps completed
		('sector', ctypes.c_int8),				# rfSector
		('finishStatus', ctypes.c_int8),		# rfFinishStatus
		('lapDist', ctypes.c_float),			# current distance around track
		('pathLateral', ctypes.c_float),		# lateral position with respect to *very approximate* "center" path
		('trackEdge', ctypes.c_float),			# track edge (w.r.t. "center" path) on same side of track as vehiclev
		('bestSector1', ctypes.c_float),		# best sector 1
		('bestSector2', ctypes.c_float),		# best sector 2 (plus sector 1)
		('bestLapTime', ctypes.c_float),		# best lap time
		('lastSector1', ctypes.c_float),		# last sector 1
		('lastSector2', ctypes.c_float),		# last sector 2 (plus sector 1)
		('lastLapTime', ctypes.c_float),		# last lap time
		('curSector1', ctypes.c_float),		# current sector 1 if valid
		('curSector2', ctypes.c_float),		# current sector 2 (plus sector 1) if valid
		('numPitstops', ctypes.c_short),		# number of pitstops made
		('numPenalties', ctypes.c_short),		# number of outstanding penalties
		('isPlayer', ctypes.c_bool),			# is this the player's vehicle
		('control', ctypes.c_int8),			# rfControl
		('inPits', ctypes.c_bool),				# between pit entrance and pit exit (not always accurate for remote vehicles)
		('place', ctypes.c_int8),				# 1-based position
		('vehicleClass', ctypes.c_char*32),	# vehicle class
		('timeBehindNext', ctypes.c_float),	# time behind vehicle in next higher place
		('lapsBehindNext', ctypes.c_long),		# laps behind vehicle in next higher place
		('timeBehindLeader', ctypes.c_float),	# time behind leader
		('lapsBehindLeader', ctypes.c_long),	# laps behind leader
		('lapStartET', ctypes.c_float),		# time this lap was started
		('pos', rfVec3),				# world position in meters
		('localVel', rfVec3),			# velocity (meters/sec) in local vehicle coordinates
		('localAccel', rfVec3),			# acceleration (meters/sec^2) in local vehicle coordinates
		('oriX', rfVec3),				# top row of orientation matrix (also converts local vehicle vectors into world X using dot product)
		('oriY', rfVec3),				# mid row of orientation matrix (also converts local vehicle vectors into world Y using dot product)
		('oriZ', rfVec3),				# bot row of orientation matrix (also converts local vehicle vectors into world Z using dot product)
		('localRot', rfVec3),			# rotation (radians/sec) in local vehicle coordinates
		('localRotAccel', rfVec3),		# rotational acceleration (radians/sec^2) in local vehicle coordinates
		('speed', ctypes.c_float)]				# meters/sec


class rfShared(ctypes.Structure):
    _pack_ = 1
    _fields_ = [
        ('deltaTime', ctypes.c_float),			# time since last scoring update (seconds)
		('lapNumber', ctypes.c_long),			# current lap number
		('lapStartET', ctypes.c_float),		# time this lap was started
		('vehicleName', ctypes.c_char*64),		# current vehicle name
		('trackName', ctypes.c_char*64),		# current track name
		('pos', rfVec3),				# world position in meters
		('localVel', rfVec3),			# velocity (meters/sec) in local vehicle coordinates
		('localAccel', rfVec3),			# acceleration (meters/sec^2) in local vehicle coordinates
		('oriX', rfVec3),				# top row of orientation matrix (also converts local vehicle vectors into world X using dot product)
		('oriY', rfVec3),				# mid row of orientation matrix (also converts local vehicle vectors into world Y using dot product)
		('oriZ', rfVec3),				# bot row of orientation matrix (also converts local vehicle vectors into world Z using dot product)
		('localRot', rfVec3),			# rotation (radians/sec) in local vehicle coordinates
		('localRotAccel', rfVec3),		# rotational acceleration (radians/sec^2) in local vehicle coordinates
		('speed', ctypes.c_float),				# meters/sec
		('gear', ctypes.c_long),				# -1=reverse, 0=neutral, 1+=forward gears
		('engineRPM', ctypes.c_float),			# engine RPM
		('engineWaterTemp', ctypes.c_float),	# Celsius
		('engineOilTemp', ctypes.c_float),		# Celsius
		('clutchRPM', ctypes.c_float),			# clutch RPM
		('unfilteredThrottle', ctypes.c_float),# ranges  0.0-1.0
		('unfilteredBrake', ctypes.c_float),	# ranges  0.0-1.0
		('unfilteredSteering', ctypes.c_float),# ranges -1.0-1.0 (left to right)
		('unfilteredClutch', ctypes.c_float),	# ranges  0.0-1.0
		('steeringArmForce', ctypes.c_float),	# force on steering arms
		('fuel', ctypes.c_float),				# amount of fuel (liters)
		('engineMaxRPM', ctypes.c_float),		# rev limit
		('scheduledStops', ctypes.c_int8),		# number of scheduled pitstops
		('overheating', ctypes.c_bool),		# whether overheating icon is shown
		('detached', ctypes.c_bool),			# whether any parts (besides wheels) have been detached
		('dentSeverity', ctypes.c_int8*8),		# dent severity at 8 locations around the car (0=none, 1=some, 2=more)
		('lastImpactET', ctypes.c_float),		# time of last impact
		('lastImpactMagnitude', ctypes.c_float),# magnitude of last impact
		('lastImpactPos', rfVec3),		# location of last impact
		('wheel', rfWheel*4),			# rfWheelIndex

		# below this line is only updated every 0.5 seconds! (interpolated when deltaTime > 0)
		('session', ctypes.c_long),			# current session
		('currentET', ctypes.c_float),			# current time
		('endET', ctypes.c_float),				# ending time
		('maxLaps', ctypes.c_long),			# maximum laps
		('lapDist', ctypes.c_float),			# distance around track
		('numVehicles', ctypes.c_long),		# current number of vehicles
		('gamePhase', ctypes.c_int8),			# rfGamePhase
		('yellowFlagState', ctypes.c_int8),	# rfYellowFlagState
		('sectorFlag', ctypes.c_int8*3),		# whether there are any local yellows at the moment in each sector
		('startLight', ctypes.c_int8),			# start light frame (number depends on track)
		('numRedLights', ctypes.c_int8),		# number of red lights in start sequence
		('inRealtime', ctypes.c_bool),			# in realtime as opposed to at the monitor
		('playerName', ctypes.c_char*32),		# player name (including possible multiplayer override)
		('plrFileName', ctypes.c_char*64),		# may be encoded to be a legal filename
		('ambientTemp', ctypes.c_float),		# Celsius
		('trackTemp', ctypes.c_float),			# Celsius
		('wind', rfVec3),				# wind speed
		('vehicle', rfVehicleInfo*128)]	# array of vehicle scoring info
