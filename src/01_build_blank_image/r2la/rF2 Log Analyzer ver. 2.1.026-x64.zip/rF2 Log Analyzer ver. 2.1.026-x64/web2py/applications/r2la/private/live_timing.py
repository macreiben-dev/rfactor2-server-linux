import mmap
import ctypes
import time
import psutil
from gluon.storage import Storage
from collections import deque, defaultdict
import traceback
import os
import json
import la_utils
import datetime
import math
from la_sharedmemory import *


best_s1 = 10000
best_s2 = 10000
best_s3 = 10000
best_laptime = 10000

BEST_TIMES = {}

EMPTY_TELEMETRY = {
    'mFrontTireCompoundName': '',
    'mRearTireCompoundName': '',
    'mRearTireCompoundIndex': 0,
    'mFrontTireCompoundIndex': 0,

    'mFuel': 0,
    'mWear': [0, 0, 0, 0],
}

DEFAULT_LIVE_TIMINIG_SETTINGS = {
    'read_global_memory': 0,
    'show_tire_data': 1,
    'show_ai_fuel_data': 0,
    'show_ai_tire_wear': 0,
    'show_class_column': 1,
    'show_vehicle_column': 1,
    'show_mph': 0,
    'show_avg_lap_speed': 0,
    'show_iframe': 0,
    'iframe_src': "",
    'iframe_style': "",
}

LIVE_TIMING_SETTINGS = {}


with open("r2la_live_timing.log", 'w', encoding='utf-8') as f:
    f.write(u"LiveTiming process started...\n")


settings_path = os.path.join(os.getcwd(), "applications\\r2la\\live_timing_settings.json")
if not os.path.isfile(settings_path):
    with open(settings_path, 'w', encoding='utf-8') as f:
        f.write(json.dumps(DEFAULT_LIVE_TIMINIG_SETTINGS, indent=4, sort_keys=True))

try:
    with open(settings_path, encoding="utf-8") as f:
        opened_settings = json.loads(f.read())
        assert opened_settings['read_global_memory'] in (0, 1)
        assert opened_settings['show_iframe'] in (0, 1)
        assert 'iframe_src' in opened_settings
        assert 'iframe_style' in opened_settings
        LIVE_TIMING_SETTINGS.update(opened_settings)
except:
    message = traceback.format_exc()
    print (message)
    print("Error reading live_timing_settings.json. Using default Live Timing Settings")
    LIVE_TIMING_SETTINGS = DEFAULT_LIVE_TIMINIG_SETTINGS


RF2_TAG_STRINGS = {
    0: {
        "Scoring": "$rFactor2SMMP_Scoring$",
        "Telemetry": "$rFactor2SMMP_Telemetry$",
    },
    1: {
        "Scoring": "Global\$rFactor2SMMP_Scoring$",
        "Telemetry": "Global\$rFactor2SMMP_Telemetry$",
    },
}

timer = la_utils.datetime_to_timestamp(datetime.datetime.utcnow())
write_to_disk = True

try:
    print("LiveTiming process started...")
    print("Reading "+("global" if LIVE_TIMING_SETTINGS['read_global_memory'] else "local")+" memory...")
    print('Class column '+("ON" if LIVE_TIMING_SETTINGS['show_class_column'] else "OFF"))
    print('Vehicle column '+("ON" if LIVE_TIMING_SETTINGS['show_vehicle_column'] else "OFF"))
    print("Tire Compound column "+("ON" if LIVE_TIMING_SETTINGS['show_tire_data'] else "OFF"))
    print("AI Fuel column "+("ON" if LIVE_TIMING_SETTINGS['show_ai_fuel_data'] else "OFF"))
    print("AI Tire Wear column "+("ON" if LIVE_TIMING_SETTINGS['show_ai_tire_wear'] else "OFF"))
    print("Avg Lap Speed column "+("ON" if LIVE_TIMING_SETTINGS['show_avg_lap_speed'] else "OFF"))
    print("Show speed in MPH "+("ON" if LIVE_TIMING_SETTINGS['show_mph'] else "OFF"))
    print("Show iframe "+("ON" if LIVE_TIMING_SETTINGS['show_iframe'] else "OFF"))

    while True:

        server_processes = [p.info for p in psutil.process_iter(attrs=['pid', 'name']) if any(pname in p.info['name'] for pname in ('rFactor2 Dedicated.exe', 'AMS Dedicated.exe', 'rFactor Dedicated.exe'))]

        server_processes.append({"pid": "", "name": "Local rF2"})
        server_processes.append({"pid": "", "name": "Local rF1"})

        server_processes_with_data = []
        live_data_out = {}

        for s_num, server_process in enumerate(server_processes, 1):
            server_process['name'] = server_process['name']+str(server_process['pid'])
            server_process['num'] = s_num

            if 'rFactor2 Dedicated.exe' in server_process['name'] or 'Local rF2' in server_process['name']:
                scoring_buffer = mmap.mmap(0, ctypes.sizeof(rF2Scoring), RF2_TAG_STRINGS[LIVE_TIMING_SETTINGS['read_global_memory']]['Scoring']+str(server_process['pid']))
                scoring = rF2Scoring.from_buffer(scoring_buffer)

                telemetry_buffer = mmap.mmap(0, ctypes.sizeof(rF2Telemetry), RF2_TAG_STRINGS[LIVE_TIMING_SETTINGS['read_global_memory']]['Telemetry']+str(server_process['pid']))
                telemetry = rF2Telemetry.from_buffer(telemetry_buffer)

            else:
                scoring_buffer = mmap.mmap(0, ctypes.sizeof(rfShared), "$rFactorShared$"+str(server_process['pid']))
                rfShared_temp = rfShared.from_buffer(scoring_buffer)
                scoring = Storage()

                if rfShared_temp.session == 6:
                    temp_session = 9
                elif rfShared_temp.session == 7:
                    temp_session = 10
                else:
                    temp_session = rfShared_temp.session

                temp_sectorFlag = deque([1 if f==2 else 11 for f in rfShared_temp.sectorFlag])
                temp_sectorFlag.rotate(2)

                mScoringInfo = Storage(
                    mTrackName=rfShared_temp.trackName, # this is not a mistake, need bytes here, see track_name var
                    mNumVehicles=rfShared_temp.numVehicles,
                    mSession=temp_session,
                    mCurrentET=rfShared_temp.currentET,
                    mEndET=rfShared_temp.endET,
                    mMaxLaps=rfShared_temp.maxLaps,
                    mLapDist=rfShared_temp.lapDist,
                    mGamePhase=rfShared_temp.gamePhase,
                    mYellowFlagState=rfShared_temp.yellowFlagState,
                    mSectorFlag=temp_sectorFlag,
                    #'mDarkCloud': scoring.mScoringInfo.mDarkCloud,
                    mRaining=0,
                    mAmbientTemp=rfShared_temp.ambientTemp,
                    mTrackTemp=rfShared_temp.trackTemp,
                    mMinPathWetness=0,
                    mMaxPathWetness=0,
                )
                #print(server_process['name'], mScoringInfo.mTrackName, mScoringInfo.mCurrentET, mScoringInfo.mNumVehicles)
                scoring.mVehicles = [
                    Storage(
                        mID=_id,
                        mDriverName=v.driverName,
                        mVehicleName="",
                        mTotalLaps=v.totalLaps,
                        mSector=v.sector,
                        mFinishStatus=v.finishStatus,
                        mLapDist=v.lapDist,
                        mBestSector1=v.bestSector1,
                        mBestSector2=v.bestSector2,
                        mBestLapTime=v.bestLapTime,
                        mLastSector1=v.lastSector1,
                        mLastSector2=v.lastSector2,
                        mLastLapTime=v.lastLapTime,
                        mCurSector1=v.curSector1,
                        mCurSector2=v.curSector2,
                        mNumPitstops=v.numPitstops or "",
                        mIsPlayer=v.isPlayer,
                        mControl=v.control,
                        mInPits=v.inPits,
                        mPlace=v.place,
                        mVehicleClass=v.vehicleClass,
                        mTimeBehindNext=v.timeBehindNext,
                        mTimeBehindLeader=v.timeBehindLeader,
                        mLapsBehindLeader=v.lapsBehindLeader,
                        mInGarageStall=0,
                        mLocalVel=v.localVel,
                    )
                    for _id, v in enumerate(rfShared_temp.vehicle)
                ]
                scoring.mScoringInfo = mScoringInfo

                telemetry = Storage()
                telemetry.mNumVehicles = 0

            track_name = bytearray(scoring.mScoringInfo.mTrackName).decode(encoding="latin_1").split('\x00', 1)[0]
            if not track_name:
                continue


            if server_process['name'] not in BEST_TIMES:
                BEST_TIMES[server_process['name']] = {
                    'best_s1': 10000,
                    'best_s2': 10000,
                    'best_s3': 10000,
                    'best_laptime': 10000,
                    'top_speeds': defaultdict(int),
                }

            # getting tire compound data
            telemetry_vehicles = {}

            # dwitch for LIVE_TIMING_SETTINGS['show_tire_data']
            if LIVE_TIMING_SETTINGS['show_tire_data'] or LIVE_TIMING_SETTINGS['show_ai_fuel_data'] or LIVE_TIMING_SETTINGS['show_ai_tire_wear']:
                for i in range(telemetry.mNumVehicles):
                    telemetry_vehicles[telemetry.mVehicles[i].mID] = {
                        'mFrontTireCompoundName': bytearray(telemetry.mVehicles[i].mFrontTireCompoundName).decode(encoding="latin_1").split('\x00', 1)[0],
                        'mRearTireCompoundName': bytearray(telemetry.mVehicles[i].mRearTireCompoundName).decode(encoding="latin_1").split('\x00', 1)[0],
                        'mRearTireCompoundIndex': telemetry.mVehicles[i].mRearTireCompoundIndex,
                        'mFrontTireCompoundIndex': telemetry.mVehicles[i].mFrontTireCompoundIndex,
                        'mFuel': telemetry.mVehicles[i].mFuel,
                        # [front left, front right, rear left, rear right]
                        'mWear': [
                            telemetry.mVehicles[i].mWheels[0].mWear*100,
                            telemetry.mVehicles[i].mWheels[1].mWear*100,
                            telemetry.mVehicles[i].mWheels[2].mWear*100,
                            telemetry.mVehicles[i].mWheels[3].mWear*100,
                        ],
                    }

            vehicles = []

            # this is for best s1, s2, s3, laptime calculations
            s1_list = [BEST_TIMES[server_process['name']]['best_s1']]
            s2_list = [BEST_TIMES[server_process['name']]['best_s2']]
            s3_list = [BEST_TIMES[server_process['name']]['best_s3']]
            best_laptimes = [BEST_TIMES[server_process['name']]['best_laptime']]

            for i in range(scoring.mScoringInfo.mNumVehicles):
                v = scoring.mVehicles[i]

                # telemetry.mVehicles is not always in sync with mScoringInfo.mNumVehicles
                if v.mID in telemetry_vehicles:
                    telemetry = telemetry_vehicles[v.mID]
                else:
                    telemetry = EMPTY_TELEMETRY

                speed = max(BEST_TIMES[server_process['name']]['top_speeds'][v.mID], math.sqrt((v.mLocalVel.x*v.mLocalVel.x) + (v.mLocalVel.y*v.mLocalVel.y) + (v.mLocalVel.z*v.mLocalVel.z)) * 3.6)
                BEST_TIMES[server_process['name']]['top_speeds'][v.mID] = speed

                vehicle = {
                    'mID': v.mID,
                    'mDriverName': bytearray(v.mDriverName).decode(encoding="latin_1").split('\x00', 1)[0],
                    'mVehicleName': bytearray(v.mVehicleName).decode(encoding="latin_1").split('\x00', 1)[0],
                    'mTotalLaps': v.mTotalLaps,
                    'mSector': v.mSector,
                    'mFinishStatus': v.mFinishStatus,
                    'mLapDist': v.mLapDist,
                    #'mPathLateral': v.mPathLateral,
                    #'mTrackEdge': v.mTrackEdge,
                    'mBestSector1': v.mBestSector1,
                    'mBestSector2': v.mBestSector2,
                    'mBestLapTime': v.mBestLapTime,
                    'mLastSector1': v.mLastSector1,
                    'mLastSector2': v.mLastSector2,
                    'mLastLapTime': v.mLastLapTime,
                    'mCurSector1': v.mCurSector1,
                    'mCurSector2': v.mCurSector2,
                    'mNumPitstops': v.mNumPitstops or "",
                    #'mNumPenalties': v.mNumPenalties,
                    'mIsPlayer': v.mIsPlayer,
                    'mControl': v.mControl,
                    'mInPits': v.mInPits,
                    'mPlace': v.mPlace,
                    'mVehicleClass': bytearray(v.mVehicleClass).decode(encoding="latin_1").split('\x00', 1)[0],
                    'mTimeBehindNext': v.mTimeBehindNext,
                    #'mLapsBehindNext': v.mLapsBehindNext,
                    'mTimeBehindLeader': v.mTimeBehindLeader,
                    'mLapsBehindLeader': v.mLapsBehindLeader,
                    #'mLapStartET': v.mLapStartET,
                    #'mPos', v.mPos,
                    #'mLocalVel': v.mLocalVel,
                    #'mLocalAccel': v.mLocalAccel,
                    #'mOri': list(v.mOri), ?
                    #'mLocalRot': v.LocalRot,
                    #'mLocalRotAccel': v.mLocalRotAccel,
                    #'mHeadlights': v.mHeadlights,
                    #'mPitState': v.mPitState,
                    #'mServerScored': v.mServerScored,
                    #'mIndividualPhase': v.mIndividualPhase,
                    #'mQualification': v.mQualification,
                    #'mTimeIntoLap': v.mTimeIntoLap,
                    #'mEstimatedLapTime': v.mEstimatedLapTime,
                    #'mPitGroup': str(bytearray(v.mPitGroup)).split('\x00', 1)[0],
                    #'mFlag': v.mFlag,
                    #'mUnderYellow': v.mUnderYellow,
                    #'mCountLapFlag': v.mCountLapFlag,
                    'mInGarageStall': v.mInGarageStall,
                    #'mUpgradePack': v.mUpgradePack,
                    #'mExpansion': v.mExpansion,
                    "mFrontTireCompoundName": telemetry['mFrontTireCompoundName'],
                    "mRearTireCompoundName": telemetry['mRearTireCompoundName'],
                    'mRearTireCompoundIndex': telemetry['mRearTireCompoundIndex'],
                    'mFrontTireCompoundIndex': telemetry['mFrontTireCompoundIndex'],
                    'mFuel': telemetry['mFuel'],
                    'mWear': telemetry['mWear'],
                    'speed': speed,
                }
                vehicles.append(vehicle)

                if v.mBestSector1 > 0:
                    s1_list.append(v.mBestSector1)

                s2_temp = v.mBestSector2 - v.mBestSector1
                if s2_temp > 0:
                    s2_list.append(s2_temp)

                s3_temp = v.mBestLapTime - v.mBestSector2
                if s3_temp > 0:
                    s3_list.append(s3_temp)

                if v.mBestLapTime > 0:
                    best_laptimes.append(v.mBestLapTime)


            if scoring.mScoringInfo.mGamePhase in (0, 4):
                # reset best times on session start
                BEST_TIMES[server_process['name']] = {
                    'best_s1': 10000,
                    'best_s2': 10000,
                    'best_s3': 10000,
                    'best_laptime': 10000,
                    'top_speeds': defaultdict(int),
                }
            else:
                BEST_TIMES[server_process['name']]['best_s1'] = min(s1_list)
                BEST_TIMES[server_process['name']]['best_s2'] = min(s2_list)
                BEST_TIMES[server_process['name']]['best_s3'] = min(s3_list)
                BEST_TIMES[server_process['name']]['best_laptime'] = min(best_laptimes)

            vehicles = sorted(vehicles, key=lambda k: k['mPlace'])

            if scoring.mScoringInfo.mServerName is not None:
                mServerName_string = bytearray(scoring.mScoringInfo.mServerName).decode(encoding="latin_1").split('\x00', 1)[0]
            else:
                mServerName_string = ""

            if scoring.mScoringInfo.mMaxPlayers is not None:
                mMaxPlayers_int = scoring.mScoringInfo.mMaxPlayers
            else:
                mMaxPlayers_int = 0

            #print(scoring.mScoringInfo.mGameMode, scoring.mScoringInfo.mIsPasswordProtected, scoring.mScoringInfo.mServerPort, scoring.mScoringInfo.mServerPublicIP, scoring.mScoringInfo.mStartET, scoring.mScoringInfo.mAvgPathWetness)

            out = {
                'best_s1': BEST_TIMES[server_process['name']]['best_s1'],
                'best_s2': BEST_TIMES[server_process['name']]['best_s2'],
                'best_s3': BEST_TIMES[server_process['name']]['best_s3'],
                'best_laptime': BEST_TIMES[server_process['name']]['best_laptime'],
                'mScoringInfo': {
                    'mServerName': mServerName_string,
                    'mTrackName': track_name,
                    'mSession': scoring.mScoringInfo.mSession,
                    'mCurrentET': scoring.mScoringInfo.mCurrentET,
                    'mEndET': scoring.mScoringInfo.mEndET,
                    'mMaxLaps': scoring.mScoringInfo.mMaxLaps,
                    'mLapDist': scoring.mScoringInfo.mLapDist,
                    'mNumVehicles': scoring.mScoringInfo.mNumVehicles,
                    'mGamePhase': scoring.mScoringInfo.mGamePhase,
                    'mYellowFlagState': scoring.mScoringInfo.mYellowFlagState,
                    'mSectorFlag': list(bytearray(scoring.mScoringInfo.mSectorFlag)),
                    #'mDarkCloud': scoring.mScoringInfo.mDarkCloud,
                    'mRaining': scoring.mScoringInfo.mRaining,
                    'mAmbientTemp': scoring.mScoringInfo.mAmbientTemp,
                    'mTrackTemp': scoring.mScoringInfo.mTrackTemp,
                    'mMinPathWetness': scoring.mScoringInfo.mMinPathWetness,
                    'mMaxPathWetness': scoring.mScoringInfo.mMaxPathWetness,
                    #'mPlrFileName': str(bytearray(scoring.mScoringInfo.mPlrFileName)).split('\x00', 1)[0],
                },
                'mVehicles': vehicles,
                'show_ai_fuel_data': LIVE_TIMING_SETTINGS['show_ai_fuel_data'],
                'show_ai_tire_wear': LIVE_TIMING_SETTINGS['show_ai_tire_wear'],
                'show_class': LIVE_TIMING_SETTINGS['show_class_column'],
                'show_vehicle': LIVE_TIMING_SETTINGS['show_vehicle_column'],
                'show_avg_lap_speed': LIVE_TIMING_SETTINGS['show_avg_lap_speed'],
                'show_mph': LIVE_TIMING_SETTINGS['show_mph'],
                'show_iframe': LIVE_TIMING_SETTINGS['show_iframe'],
                'iframe_src': LIVE_TIMING_SETTINGS['iframe_src'],
                'iframe_style': LIVE_TIMING_SETTINGS['iframe_style'],
            }

            server_process['label_name'] = "#"+str(len(server_processes_with_data)+1)+". "+(mServerName_string or out['mScoringInfo']['mTrackName'])+" ("+str(out['mScoringInfo']['mNumVehicles'])+("/"+str(mMaxPlayers_int) if mMaxPlayers_int else "")+")"

            live_data_out[server_process['name']] = out
            server_processes_with_data.append(server_process)

        """
        if not live_data_out['Local']['mScoringInfo']['mTrackName']:
            del live_data_out['Local']
            server_processes.pop()
        """

        live_data_out['server_list'] = server_processes_with_data
        live_data_out['server_names_list'] = [s['name'] for s in server_processes_with_data]

        time_now = la_utils.datetime_to_timestamp(datetime.datetime.utcnow())
        time_diff = time_now - timer
        if time_diff > 1:
            timer = time_now
            write_to_disk = True

            if live_data_out['server_names_list']:
                live_data = db2(db2.live_data.id == 1).select().first()
                if not live_data:
                    db2.live_data.insert(scoring=live_data_out)
                else:
                    live_data.update_record(scoring=live_data_out)
                db2.commit()
                #print("db2.commit server_names_list == True")
            else:
                live_data = db2(db2.live_data.id == 1).select().first()
                if not live_data:
                    db2.live_data.insert(scoring=live_data_out)
                    db2.commit()
                    #print("db2.commit server_names_list == False + not live_data")

                live_data = db2(db2.live_data.id == 1).select().first()
                if live_data.scoring['server_names_list']:
                    live_data.update_record(scoring=live_data_out)
                    db2.commit()
                    #print("db2.commit server_names_list == False")


        time.sleep(1)

except:
    message = traceback.format_exc()
    print (message)
    with open("r2la_live_timing.log", 'a', encoding='utf-8') as f:
        f.write(message)
