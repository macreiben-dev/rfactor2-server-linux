from gluon import current
import collections
import datetime
from decimal import Decimal
import la_core
import la_utils

class Championship:
    def __init__(self, row):
        self.row = row
        db = current.db
        self.races = db(db.race.championship_id==row.id).select(orderby=db.race.id)
        self.events = [la_core.create_event(r.file_name, self.row, r, no_tables=True) if r.file_name else None for r in self.races]

    def calculate(self, keep_data=False):
        if self.row.show_unofficial:
            self.is_unofficial = any((r.is_unofficial and r.file_name for r in self.races))
        else:
            self.is_unofficial = False

        drivers = set()
        teams = set()
        classes = set()
        for num, event in enumerate(self.events, 1):
            if event:
                event.num = num
                drivers |= set(event.drivers)
                teams |= set([t for t in event.teams])
                classes |= set([class_name for class_name in event.classes])

        self.teams = list(teams)
        self.classes = list(classes)
        self.drivers = {name: {} for name in drivers}

        for name in self.drivers:
            self.drivers[name]['teams'] = {e.race_info[e.race_info['finish_positions'][name]]['team_name'] for e in self.events \
                                            if e and e.race_info['finish_positions'].get(name)}

        self.tables = {}
        self.calculateDrChampTable()
        self.calculateTeamChampTable()
        self.calculateStats(keep_data)
        if self.row.class_options != "Off":
            for class_name in self.classes:
                self.calculateDrClChampTable(class_name)

    def getTeamDrivers(self, team_name, full_names=False, class_drivers=None):
        team_drivers = set()
        for event in self.events:
            if event and event.teams.get(team_name):
                for driver in event.teams[team_name]:
                    if class_drivers is None or (class_drivers is not None and driver in class_drivers):
                        team_drivers.add(driver)
        if team_drivers and not full_names:
            team_drivers = {la_utils.small_name(driver) for driver in team_drivers}
        return team_drivers

    def calculateDrChampTable(self):
        drpts = {name: {} for name in self.drivers}
        drpts_for_resnoc = {name: {} for name in self.drivers}
        drplaces = {name: {i: 0 for i in range(1, len(self.drivers)+1)} for name in self.drivers}
        num_events_with_results = 0
        finish_status = {name: {} for name in self.drivers}

        self.dr_penalty_points = collections.defaultdict(int)
        for event in self.events:
            if event:
                num_events_with_results += 1
                for name in self.drivers:
                    pos = event.race_info['finish_positions'].get(name)
                    if pos:
                        #driver in event results
                        self.dr_penalty_points[name] += event.race.penalty_points.get(name, 0)

                        drpts[name][event.num] = event.race_info[pos]['pts']

                        if self.row.ignore_manual_pts_for_worst:
                            drpts_for_resnoc[name][event.num] = sum(event.race_info[pos]['pts_dict']['real'].values()) + sum(event.race_info[pos]['pts_dict']['fake'].values())
                        else:
                            if name in event.race.manual_points:
                                drpts_for_resnoc[name][event.num] = sum(event.race_info[pos]['pts_dict']['manual'].values()) + sum(event.race_info[pos]['pts_dict']['fake'].values())
                            else:
                                drpts_for_resnoc[name][event.num] = sum(event.race_info[pos]['pts_dict']['real'].values()) + sum(event.race_info[pos]['pts_dict']['fake'].values())

                        drplaces[name][pos] += 1
                        if not event.race_info[pos]['RaceDuration'] and not event.race_info[pos]['pts']:
                            finish_status[name][event.num] = event.race_info[pos]['FinishStatus'][:3]
                        else:
                            if name in event.race.manual_points:
                                finish_status[name][event.num] = str(la_utils.float_no_zero(sum(event.race_info[pos]['pts_dict']['manual'].values())))
                            else:
                                finish_status[name][event.num] = str(la_utils.float_no_zero(sum(event.race_info[pos]['pts_dict']['real'].values())))
                    else:
                        #driver not in event results
                        drpts[name][event.num] = self.row.pts_for_all
                        drpts_for_resnoc[name][event.num] = self.row.pts_for_all
                        finish_status[name][event.num] = '-'

        drsum = {name: 0 for name in self.drivers}
        drsumfull = {name: 0 for name in self.drivers}
        self.resnocevents = {name: [] for name in self.drivers}


        drop_difference = max(num_events_with_results - self.row.drop_worst_after_x, 0)
        # drop_worst_after_x can not be more than num_events_with_results
        drop_worst_after_x_overflow = min(num_events_with_results, self.row.drop_worst_after_x)
        for name, ptsdict in drpts_for_resnoc.items():
            # ptsdict -> {event.num: points, ...}
            for i, event_num in enumerate(sorted(ptsdict, key=ptsdict.get), 1):
                if len(self.events) > self.row.results_nocount and num_events_with_results > self.row.results_nocount:
                    if not self.row.drop_worst_after_x or drop_worst_after_x_overflow <= num_events_with_results:
                        if i > min(self.row.results_nocount, drop_difference):
                            drsum[name] += drpts[name][event_num]
                        else:
                            self.resnocevents[name].append(event_num)
                else:
                    drsum[name] += drpts[name][event_num]
                drsumfull[name] += drpts[name][event_num]

            #if self.row.subtract_penalty_points:
            #    drpts[name]['sum'] = drsum[name] - self.dr_penalty_points[name]
            #else:
            drpts[name]['sum'] = drsum[name]

            drpts[name]['sum+'] = drpts[name]['sum'] * 1000
            drpts[name]['sumfull'] = drsumfull[name]


        for name, pldict in drplaces.items():
            strPositions = '0.'
            for place, num in pldict.items():
                strPositions += str(num)
            drpts[name]['sum+'] = Decimal(int(drpts[name]['sum+'])) + Decimal(strPositions)

        self.tables['DrChampCl0'] = []
        self.tables['positions'] = {}
        graph_pydrivers = ''
        graph_pts_counter = {name: 0 for name in self.drivers}
        max_pts = 0
        sorted_drpts = sorted(drpts, key=lambda name: drpts[name]['sum+'], reverse=True)
        for i, name in enumerate(sorted_drpts, 1):
            graph_events = ''
            self.tables['positions'][name] = i
            onedriver = {}
            onedriver['name'] = name
            onedriver['teams'] = ", ".join(self.drivers[name]['teams'])
            onedriver['events'] = []
            vehicles = set()
            vehicles_per_event = {}

            for e_num, event in enumerate(self.events, 1):
                onerow = {}
                #if self.row.subtract_penalty_points and e_num == len(self.events): # this will not work if no results in event #1
                #    graph_pts_counter[name] -= self.dr_penalty_points[name]

                if event:
                    pos = event.race_info['finish_positions'].get(name)
                    if pos:
                        vehicles.add(event.race_info[pos]['car_id'])
                        vehicles_per_event[event.num] = event.race_info[pos]['car_id']
                        onerow['pts_dict'] = event.race_info[pos]['pts_dict']
                        onerow['pos'] = pos
                        finish_status_temp = event.race_info[pos]['FinishStatus']
                    else:
                        onerow['pts_dict'] = {}
                        onerow['pos'] = ''
                        finish_status_temp = ''
                        vehicles_per_event[event.num] = ''

                    onerow['pts_or_status'] = finish_status[name][event.num]
                    if event.num in self.resnocevents[name]:
                        onerow['pts_or_status'] += '*'
                    else:
                        graph_pts_counter[name] += drpts[name][event.num]

                    if name == event.race_info[1]['Name']:
                        onerow['bg'] = "cellbg_1st" #"#FFAD33"
                    elif event.race_info.get(2) and name == event.race_info[2]['Name'] and name in event.out['inpoints']:
                        onerow['bg'] = "cellbg_2nd" #"#FFD066"
                    elif event.race_info.get(3) and name == event.race_info[3]['Name'] and name in event.out['inpoints']:
                        onerow['bg'] = "cellbg_3rd" #"#FFFFB2"
                    elif finish_status_temp == 'DNS':
                        onerow['bg'] = "cellbg_dns" #"#D6F5FF"
                    elif finish_status_temp == 'DQ':
                        onerow['bg'] = "cellbg_dq" #"#999999"
                    elif finish_status_temp not in ('Finished', ''): # not in ('Finished', 'DQ', 'DNS', '')
                        onerow['bg'] = "cellbg_dnf" #"#F0D1FF"
                    elif name in event.out['inpoints']:
                        onerow['bg'] = "cellbg_in_points" #"#E0FFD6"
                    #elif onerow['pts_or_status'].rstrip('*').isalpha():
                    #    onerow['bg'] = "#F0D1FF"
                    elif onerow['pts_or_status'].rstrip('*').isdigit():
                        onerow['bg'] = "cellbg_outside_points" #"#EEE"
                    else:
                        onerow['bg'] = "cellbg_na" #"#FFF"

                    if onerow['pts_dict'] and onerow['pts_dict']['manual'] and onerow['pts_or_status'].rstrip('*').isalpha():
                        onerow['pts_or_status'] = str(la_utils.float_no_zero(sum(event.race_info[pos]['pts_dict']['manual'].values())))

                else:
                    onerow['pts_or_status'] = ''
                    onerow['bg'] = "cellbg_na" #"#FFF"
                    onerow['pos'] = ''

                graph_events = graph_events + '[' + str(e_num) + ', ' + str(graph_pts_counter[name]) + '],'

                onedriver['events'].append(onerow)

            graph_pydrivers += '{label: "' + str(i) + '. ' + name + '", data: [' + graph_events + ']},'

            onedriver['vehicles_per_event'] = vehicles_per_event
            onedriver['vehicles'] = ", ".join(vehicles)
            onedriver['sum'] = la_utils.float_no_zero(drpts[name]['sum'])
            if i == 1:
                max_pts = drpts[name]['sumfull']
                max_pts_sum = drpts[name]['sum']
                onedriver['sum_gap'] = '-'
                onedriver['sum_next'] = '-'
            else:
                onedriver['sum_gap'] = la_utils.float_no_zero(max_pts_sum - drpts[name]['sum'])
                onedriver['sum_next'] = (la_utils.float_no_zero(drpts[sorted_drpts[i-2]]['sum'] - drpts[name]['sum']) or '-')

            onedriver['sumfull'] = la_utils.float_no_zero(drpts[name]['sumfull'])
            onedriver['sum_penalty'] = la_utils.float_no_zero(self.dr_penalty_points[name])
            self.tables['DrChampCl0'].append(onedriver)
        self.tables['season_graph_Cl0'] = {'pydrivers': graph_pydrivers, 'events_num': len(self.events), 'max_pts': max_pts}

    def calculateTeamChampTable(self):
        teampoints = {t: {} for t in self.teams}
        driver_names_dict = {t: {} for t in self.teams}
        teamplaces = {t: collections.defaultdict(int) for t in self.teams}
        for event in self.events:
            if event:
                for team_name in self.teams:
                    teampoints[team_name][event.num] = 0
                    driver_names_dict[team_name][event.num] = {}
                    if event.teams.get(team_name):
                        teamdrivers = event.teams[team_name]
                        if teamdrivers:
                            if not self.row.use_class_pts:
                                if self.row.ignore_worse_for_team_tables:
                                    teamdrpts = {drname: event.race_info[event.race_info['finish_positions'][drname]]['pts'] for drname in teamdrivers
                                                 if event.race_info['finish_positions'].get(drname)
                                                 and event.num not in self.resnocevents[drname]}
                                else:
                                    teamdrpts = {drname: event.race_info[event.race_info['finish_positions'][drname]]['pts'] for drname in teamdrivers
                                                 if event.race_info['finish_positions'].get(drname)}
                            else:
                                if self.row.ignore_worse_for_team_tables:
                                    teamdrpts = {drname: event.race_info[event.race_info['finish_positions'][drname]]['class_pts'] for drname in teamdrivers
                                                 if event.race_info['finish_positions'].get(drname)
                                                 and event.num not in self.resnocevents[drname]}
                                else:
                                    teamdrpts = {drname: event.race_info[event.race_info['finish_positions'][drname]]['class_pts'] for drname in teamdrivers
                                                 if event.race_info['finish_positions'].get(drname)}

                            for i, drname in enumerate(sorted(teamdrpts, key=teamdrpts.get, reverse=True), 1):
                                pos = event.race_info['finish_positions'].get(drname)
                                if pos:
                                    teamplaces[team_name][pos] += 1
                                    if i <= self.row.pts_team_cars:
                                        teampoints[team_name][event.num] += teamdrpts[drname] if not self.row.team_with_no_points or self.row.team_with_no_points not in team_name else 0
                                        driver_names_dict[team_name][event.num][drname] = teamdrpts[drname]
                                    else:
                                        driver_names_dict[team_name][event.num]["*"+drname] = teamdrpts[drname]

        for name, ptsdict in teampoints.items():
            ptsdict['sum'] = sum(ptsdict.values())
            ptsdict['sum+'] = ptsdict['sum'] * 1000

        for name, pldict in teamplaces.items():
            strPositions = '0.'
            for place, num in pldict.items():
                strPositions += str(num)
            teampoints[name]['sum+'] = Decimal(int(teampoints[name]['sum+'])) + Decimal(strPositions)


        graph_pyteams = ''
        graph_pts_counter = {name: 0 for name in self.teams}
        max_pts = 0

        self.tables['TeamChampCl0'] = []
        sorted_teampoints = sorted(teampoints, key=lambda name: teampoints[name]['sum+'], reverse=True)
        for i, name in enumerate(sorted_teampoints, 1):
            graph_events = ''
            oneteam = {}
            oneteam['name'] = name
            teamdrivers = self.getTeamDrivers(name)
            #oneteam['driver_list'] = self.getTeamDrivers(name, full_names=True)
            if teamdrivers:
                oneteam['drivers'] = ", ".join(teamdrivers)
            else:
                oneteam['drivers'] = ''
            oneteam['events'] = []
            for e_num, event in enumerate(self.events, 1): 
                onerow = {}
                if event:
                    onerow['driver_names'] = driver_names_dict[name][event.num]
                    if teampoints[name][event.num] == 0:
                        onerow['pts'] = 0
                        onerow['bg'] = "cellbg_outside_points" #'#EEE'
                    else:
                        onerow['pts'] = la_utils.float_no_zero(teampoints[name][event.num])
                        onerow['bg'] = "cellbg_in_points" #'#E0FFD6'

                        graph_pts_counter[name] += onerow['pts']
                else:
                    onerow['pts'] = None
                    onerow['bg'] = "cellbg_na" #'#FFF'
                    onerow['driver_names'] = ''

                graph_events = graph_events + '[' + str(e_num) + ', ' + str(graph_pts_counter[name]) + '],'

                oneteam['events'].append(onerow)

            oneteam['sum'] = la_utils.float_no_zero(teampoints[name]['sum'])
            
            graph_pyteams += '{label: "' + str(i) + '. ' + name + '", data: [' + graph_events + ']},'
            
            if i == 1:
                max_pts = teampoints[name]['sum']
                max_pts_sum = teampoints[name]['sum']
                oneteam['sum_gap'] = '-'
                oneteam['sum_next'] = '-'
            else:
                oneteam['sum_gap'] = la_utils.float_no_zero(max_pts_sum - teampoints[name]['sum'])
                oneteam['sum_next'] = (la_utils.float_no_zero(teampoints[sorted_teampoints[i-2]]['sum'] - teampoints[name]['sum']) or '-')

            self.tables['TeamChampCl0'].append(oneteam)

        self.tables['season_graph_Cl0_teams'] = {'pyteams': graph_pyteams, 'events_num': len(self.events), 'max_pts': max_pts}

    def calculateDrClChampTable(self, class_name):
        class_drivers = set()

        for event in self.events:
            if event and event.classes.get(class_name):
                class_drivers |= set(event.classes[class_name].drivers)

        drpts = {name: {} for name in class_drivers}
        drpts_for_resnoc = {name: {} for name in class_drivers}
        finish_status = {name: {} for name in class_drivers}
        drplaces = {name: {i: 0 for i in range(1, len(class_drivers)+1)} for name in class_drivers}

        num_events_with_results = 0
        for event in self.events:
            if event:
                num_events_with_results += 1
                if event.classes.get(class_name):
                    for name in class_drivers:
                        if name in event.classes[class_name].drivers:
                            if event.race_info['finish_positions'].get(name):
                                pos = event.race_info['finish_positions'][name]
                                clpos = event.race_info[pos]['class_pos']
                                drpts[name][event.num] = event.race_info[pos]['class_pts']

                                if self.row.ignore_manual_pts_for_worst:
                                    drpts_for_resnoc[name][event.num] = sum(event.race_info[pos]['class_pts_dict']['real'].values()) + sum(event.race_info[pos]['class_pts_dict']['fake'].values())
                                else:
                                    if name in event.race.manual_points:
                                        drpts_for_resnoc[name][event.num] = sum(event.race_info[pos]['class_pts_dict']['manual'].values()) + sum(event.race_info[pos]['class_pts_dict']['fake'].values())
                                    else:
                                        drpts_for_resnoc[name][event.num] = sum(event.race_info[pos]['class_pts_dict']['real'].values()) + sum(event.race_info[pos]['class_pts_dict']['fake'].values())

                                drplaces[name][clpos] += 1
                                if not event.race_info[pos]['RaceDuration'] and not event.race_info[pos]['class_pts']:
                                    finish_status[name][event.num] = event.race_info[pos]['FinishStatus'][:3]
                                else:
                                    if name in event.race.manual_points:
                                        finish_status[name][event.num] = str(la_utils.float_no_zero(sum(event.race_info[pos]['class_pts_dict']['manual'].values())))
                                    else:
                                        finish_status[name][event.num] = str(la_utils.float_no_zero(sum(event.race_info[pos]['class_pts_dict']['real'].values())))
                            else:
                                #driver not in event results
                                drpts[name][event.num] = self.row.pts_for_all
                                drpts_for_resnoc[name][event.num] = self.row.pts_for_all
                                finish_status[name][event.num] = '-'
                        else:
                            drpts[name][event.num] = self.row.pts_for_all
                            drpts_for_resnoc[name][event.num] = self.row.pts_for_all

        drsum = {name: 0 for name in class_drivers}
        drsumfull = {name: 0 for name in class_drivers}
        resnocevents = {name: [] for name in class_drivers}

        drop_difference = max(num_events_with_results - self.row.drop_worst_after_x, 0)
        # drop_worst_after_x can not be more than num_events_with_results
        drop_worst_after_x_overflow = min(num_events_with_results, self.row.drop_worst_after_x)
        for name, ptsdict in drpts_for_resnoc.items():
            # ptsdict -> {event.num: points, ...}
            for i, event_num in enumerate(sorted(ptsdict, key=ptsdict.get), 1):
                if len(self.events) > self.row.results_nocount and num_events_with_results > self.row.results_nocount:
                    if not self.row.drop_worst_after_x or drop_worst_after_x_overflow <= num_events_with_results:
                        if i > min(self.row.results_nocount, drop_difference):
                            drsum[name] += drpts[name][event_num]
                        else:
                            resnocevents[name].append(event_num)
                else:
                    drsum[name] += drpts[name][event_num]
                drsumfull[name] += drpts[name][event_num]

            #if self.row.subtract_penalty_points:
            #    drpts[name]['sum'] = drsum[name] - self.dr_penalty_points[name]
            #else:
            drpts[name]['sum'] = drsum[name]

            drpts[name]['sum+'] = drpts[name]['sum'] * 1000
            drpts[name]['sumfull'] = drsumfull[name]

        for name, pldict in drplaces.items():
            strPositions = '0.'
            for place, num in pldict.items():
                strPositions += str(num)
            drpts[name]['sum+'] = Decimal(int(drpts[name]['sum+'])) + Decimal(strPositions)

        self.tables['DrChampCl'+class_name] = []
        sorted_drpts = sorted(drpts, key=lambda name: drpts[name]['sum+'], reverse=True)
        for ind, name in enumerate(sorted_drpts):
            onedriver = {}
            onedriver['name'] = name
            onedriver['teams'] = ", ".join(self.drivers[name]['teams'])
            onedriver['events'] = []
            vehicles = set()
            vehicles_per_event = {}
            for event in self.events:
                onerow = {}
                if event:
                    pos = event.race_info['finish_positions'].get(name)
                    if pos:
                        clpos = event.race_info[pos]['class_pos']
                        vehicles.add(event.race_info[pos]['car_id'])
                        vehicles_per_event[event.num] = event.race_info[pos]['car_id']
                        onerow['pts_dict'] = event.race_info[pos]['class_pts_dict']
                        onerow['pos'] = clpos
                        finish_status_temp = event.race_info[pos]['FinishStatus']
                    else:
                        clpos = 0
                        onerow['pts_dict'] = {}
                        onerow['pos'] = ''
                        finish_status_temp = ''
                        vehicles_per_event[event.num] = ''

                    onerow['pts_or_status'] = finish_status[name].get(event.num) or '-'
                    if event.num in resnocevents[name]:
                        onerow['pts_or_status'] += '*'

                    if event.classes.get(class_name) and name in event.classes[class_name].drivers:
                        if clpos == 1:
                            onerow['bg'] = "cellbg_1st"
                        elif clpos == 2 and name in event.out['clinpoints'][class_name]:
                            onerow['bg'] = "cellbg_2nd"
                        elif clpos == 3 and name in event.out['clinpoints'][class_name]:
                            onerow['bg'] = "cellbg_3rd"
                        elif finish_status_temp == 'DNS':
                            onerow['bg'] = "cellbg_dns"
                        elif finish_status_temp == 'DQ':
                            onerow['bg'] = "cellbg_dq"
                        elif finish_status_temp not in ('Finished', ''): # not in ('Finished', 'DQ', 'DNS')
                            onerow['bg'] = "cellbg_dnf"
                        elif name in event.out['clinpoints'][class_name]:
                            onerow['bg'] = "cellbg_in_points"
                        #elif onerow['pts_or_status'].rstrip('*').isalpha():
                        #    onerow['bg'] = "#F0D1FF"
                        elif onerow['pts_or_status'].rstrip('*').isdigit():
                            onerow['bg'] = "cellbg_outside_points"
                        else:
                            onerow['bg'] = "cellbg_na"
                    else:
                        onerow['bg'] = "cellbg_na"
                else:
                    onerow['bg'] = "cellbg_na"
                    onerow['pts_or_status'] = ''
                    onerow['pts_dict'] = {}
                    onerow['pos'] = ''

                onedriver['events'].append(onerow)

            onedriver['vehicles_per_event'] = vehicles_per_event
            onedriver['vehicles'] = ", ".join(vehicles)
            onedriver['sum'] = la_utils.float_no_zero(drpts[name]['sum'])
            if ind == 0:
                max_pts_sum = drpts[name]['sum']
                onedriver['sum_gap'] = '-'
                onedriver['sum_next'] = '-'
            else:
                onedriver['sum_gap'] = la_utils.float_no_zero(max_pts_sum - drpts[name]['sum'])
                onedriver['sum_next'] = (la_utils.float_no_zero(drpts[sorted_drpts[ind-1]]['sum'] - drpts[name]['sum']) or '-')

            onedriver['sumfull'] = la_utils.float_no_zero(drpts[name]['sumfull'])
            onedriver['sum_penalty'] = la_utils.float_no_zero(self.dr_penalty_points[name])
            self.tables['DrChampCl'+class_name].append(onedriver)

        if not self.teams:
            self.tables['TeamChampCl'+class_name] = []
            return

        classteams = set()
        for drname in drpts:
            for event in self.events:
                if event:
                    tname = event.getTeam(drname)
                    if tname is not None:
                        classteams.add(tname)

        teampoints = {t: {} for t in classteams}
        teamplaces = {t: {i: 0 for i in range(1, len(class_drivers)+1)} for t in classteams}
        driver_names_dict = {t: {} for t in self.teams}

        for event in self.events:
            if event:
                for team_name in classteams:
                    teampoints[team_name][event.num] = 0
                    driver_names_dict[team_name][event.num] = {}
                    if event.classes.get(class_name) and event.teams.get(team_name):
                        teamdrivers = event.teams[team_name]
                        if teamdrivers:
                            if self.row.ignore_worse_for_team_tables:
                                teamdrpts = {drname: event.race_info[event.race_info['finish_positions'][drname]]['class_pts'] for drname in teamdrivers
                                             if drname in event.classes[class_name].drivers
                                             and event.race_info['finish_positions'].get(drname)
                                             and event.num not in resnocevents[drname]}
                            else:
                                teamdrpts = {drname: event.race_info[event.race_info['finish_positions'][drname]]['class_pts'] for drname in teamdrivers
                                             if drname in event.classes[class_name].drivers
                                             and event.race_info['finish_positions'].get(drname)}

                            for i, drname in enumerate(sorted(teamdrpts, key=teamdrpts.get, reverse=True), 1):
                                pos = event.race_info['finish_positions'].get(drname)
                                if pos:
                                    clpos = event.race_info[pos]['class_pos']
                                    teamplaces[team_name][clpos] += 1
                                    if i <= self.row.pts_team_cars:
                                        driver_names_dict[team_name][event.num][drname] = teamdrpts[drname]
                                        teampoints[team_name][event.num] += teamdrpts[drname] if not self.row.team_with_no_points or self.row.team_with_no_points not in team_name else 0
                                    else:
                                        driver_names_dict[team_name][event.num]["*"+drname] = teamdrpts[drname]

        for name, ptsdict in teampoints.items():
            ptsdict['sum'] = sum(ptsdict.values())
            ptsdict['sum+'] = ptsdict['sum'] * 1000

        for name, pldict in teamplaces.items():
            strPositions='0.'
            for place, num in pldict.items():
                strPositions += str(num)
            teampoints[name]['sum+'] = Decimal(int(teampoints[name]['sum+'])) + Decimal(strPositions)

        self.tables['TeamChampCl'+class_name] = []
        sorted_teampoints = sorted(teampoints, key=lambda name: teampoints[name]['sum+'], reverse=True)
        for i, name in enumerate(sorted_teampoints, 1):
            oneteam = {}
            oneteam['name'] = name
            teamdrivers = self.getTeamDrivers(name, class_drivers=class_drivers)
            if teamdrivers:
                oneteam['drivers'] = ", ".join(teamdrivers)
            else:
                oneteam['drivers'] = ''
            oneteam['events'] = []
            for event in self.events:
                onerow = {}
                if event:
                    onerow['driver_names'] = driver_names_dict[name][event.num]
                    if teampoints[name][event.num] == 0:
                        onerow['pts'] = 0
                        onerow['bg'] = 'cellbg_outside_points'
                    else:
                        onerow['pts'] = la_utils.float_no_zero(teampoints[name][event.num])
                        onerow['bg'] = 'cellbg_in_points'
                else:
                    onerow['pts'] = None
                    onerow['bg'] = 'cellbg_na'
                    onerow['driver_names'] = ''

                oneteam['events'].append(onerow)

            oneteam['sum'] =  la_utils.float_no_zero(teampoints[name]['sum'])
            if i == 1:
                max_pts_sum = teampoints[name]['sum']
                oneteam['sum_gap'] = '-'
                oneteam['sum_next'] = '-'
            else:
                oneteam['sum_gap'] = la_utils.float_no_zero(max_pts_sum - teampoints[name]['sum'])
                oneteam['sum_next'] = (la_utils.float_no_zero(teampoints[sorted_teampoints[i-2]]['sum'] - teampoints[name]['sum']) or '-')

            self.tables['TeamChampCl'+class_name].append(oneteam)

    def calculateStats(self, keep_data=False):
        vehstats = {}
        drstats = {}
        drstatsbest = {}

        starts = [0]
        wins = [0]
        poles = [0]
        flaps = [0]
        tricks = [0]
        slams = [0]
        dnf = [1000]
        avgs = [1000]
        avgf = [1000]
        tripkm = [0]
        tripl = [0]
        triptime = [0]
        lled = [0]
        top3 = [0]
        top5 = [0]
        top10 = [0]
        inpts = [0]

        for driver in self.drivers:
            drstats[driver] = {}
            drstats[driver]['pts'] = 0

            drwins = {'num': 0, 'tracks': []}
            drpoles = {'num':0, 'tracks': []}
            drflaps = {'num':0, 'tracks': []}
            drstarts = 0
            drdns = 0
            drtricks = {'num': 0, 'tracks': []}
            drslams = {'num': 0, 'tracks': []}
            drclimbes = 0
            drdnf = 0
            dravgs = []
            dravgf = []
            drtripl = 0
            drtriptime = 0
            drtripkm = 0
            drlled = 0
            drtop3 = 0
            drtop5 = 0
            drtop10 = 0
            drinpts = 0
            for event in self.events:
                if event:
                    if driver in event.race_info['racedrlist']:
                        info = event.race_info
                        i = event.race_info['finish_positions'][driver]
                        if self.row.car_stats_options != 'Off':
                            v = info[i][self.row.car_stats_options]
                        else:
                            v = info[i]['CarType']

                        if v not in vehstats:
                            vehstats[v] = {'drivers':[], 'pts':0, 'drstarts':0, 'drdns':0, 'drwins':0, 'drpoles':0, 'drflaps':0,
                                            'drdnf':0, 'dravgs':[], 'dravgf':[], 'drtripkm':0, 'drtripl':0, 'drtriptime':0,
                                            'drlled':0, 'drtop3':0, 'drtop5':0, 'drtop10':0, 'drinpts':0}

                        drstats[driver]['pts'] += info[i]['pts']
                        vehstats[v]['pts'] += info[i]['pts']
                        if driver not in vehstats[v]['drivers']:
                            vehstats[v]['drivers'].append(driver)

                        # +5 positions during race, for ratings
                        #if info[i]['StartPosition'] - info[i]['FinishPosition'] > 5 and info[i]['FinishStatus'] == 'Finished':
                        #    drclimbes += 1

                        #HatTrick
                        hattrick = False
                        if info[1]['Name'] == driver and event.out['pole']['name'] == driver and event.out['FastestLap']['name'] == driver:
                            drtricks['num'] += 1
                            drtricks['tracks'].append(info['TrackCourse'])
                            hattrick = True
                            info['trick'] = info[1]['Name']
                        #GrandSlam
                        if hattrick and info[i]['LapsLed'] == info[1]['Laps']:
                            drslams['num'] += 1
                            drslams['tracks'].append(info['TrackCourse'])
                            info['slam'] = info[1]['Name']

                        if info[i]['FinishStatus'] != 'DNS':
                            drstarts += 1
                            vehstats[v]['drstarts'] += 1
                        if info[i]['FinishStatus'] == 'DNS':
                            drdns += 1
                            vehstats[v]['drdns'] += 1
                        if info[1]['Name'] == driver:
                            drwins['num'] += 1
                            drwins['tracks'].append(info['TrackCourse'])
                            vehstats[v]['drwins'] += 1
                        if event.out['pole']['name'] == driver:
                            drpoles['num'] += 1
                            drpoles['tracks'].append(info['TrackCourse'])
                            vehstats[v]['drpoles'] += 1
                        if event.out['FastestLap']['name'] == driver:
                            drflaps['num'] += 1
                            drflaps['tracks'].append(info['TrackCourse'])
                            vehstats[v]['drflaps'] += 1
                        if info[i]['FinishStatus'] != 'Finished' and info[i]['FinishStatus'] != 'DNS':
                            drdnf += 1
                            vehstats[v]['drdnf'] += 1
                        if event.race.noqual == False:
                            dravgs.append(info[i]['StartPosition'])
                            vehstats[v]['dravgs'].append(info[i]['StartPosition'])
                        if info[i]['FinishStatus'] == 'Finished':
                            dravgf.append(info[i]['FinishPosition'])
                            vehstats[v]['dravgf'].append(info[i]['FinishPosition'])

                        drtripkm += info[i]['Laps'] * float(info['TrackLength'])
                        vehstats[v]['drtripkm'] += info[i]['Laps'] * float(info['TrackLength'])

                        drtripl += info[i]['Laps']
                        vehstats[v]['drtripl'] += info[i]['Laps']

                        drtriptime += sum(info[i]['drracelaps'])
                        vehstats[v]['drtriptime'] += sum(info[i]['drracelaps'])

                        drlled += info[i]['LapsLed']
                        vehstats[v]['drlled'] += info[i]['LapsLed']

                        if 3 >= info[i]['FinishPosition'] > 0 and info[i]['Laps'] > info[1]['Laps'] * self.row.pts_distance / 100:
                            drtop3 += 1
                            vehstats[v]['drtop3'] += 1
                        if 5 >= info[i]['FinishPosition'] > 0 and info[i]['Laps'] > info[1]['Laps'] * self.row.pts_distance / 100:
                            drtop5 += 1
                            vehstats[v]['drtop5'] += 1
                        if 10 >= info[i]['FinishPosition'] > 0 and info[i]['Laps'] > info[1]['Laps'] * self.row.pts_distance / 100:
                            drtop10 += 1
                            vehstats[v]['drtop10'] += 1
                        if driver in event.out['inpoints']:
                            drinpts += 1
                            vehstats[v]['drinpts'] += 1

                        #drpenalties.extend(info[i]['Penalty'])

            drstats[driver]['starts'] = drstarts
            drstats[driver]['dns'] = drdns
            drstats[driver]['dnf'] = drdnf
            #drstats[driver]['climbes']=drclimbes
            drstats[driver]['wins'] = drwins
            drstats[driver]['top3'] = drtop3
            drstats[driver]['top5'] = drtop5
            drstats[driver]['top10'] = drtop10
            drstats[driver]['inpts'] = drinpts
            drstats[driver]['poles'] = drpoles
            drstats[driver]['flaps'] = drflaps
            drstats[driver]['tricks'] = drtricks
            drstats[driver]['slams'] = drslams
            drstats[driver]['lled'] = drlled
            drstats[driver]['stlist'] = dravgs
            drstats[driver]['finlist'] = dravgf
            if dravgs:
                drstats[driver]['avgs'] = sum(dravgs) / len(dravgs)
                drstats[driver]['bestst'] = min(dravgs)
            else:
                drstats[driver]['avgs'] = 0
                drstats[driver]['bestst'] = 0
            if dravgf:
                drstats[driver]['avgf'] = sum(dravgf) / len(dravgf)
                drstats[driver]['bestf'] = min(dravgf)
            else:
                drstats[driver]['avgf'] = 0
                drstats[driver]['bestf'] = 0
            #drstats[driver]['penalty']=drpenalties
            drstats[driver]['tripkm'] = round(drtripkm/1000, 3)
            drstats[driver]['tripl'] = drtripl
            drstats[driver]['triptime'] = drtriptime
            drstats[driver]['leader'] = 0

            starts.append(drstarts)
            wins.append(drwins['num'])
            poles.append(drpoles['num'])
            flaps.append(drflaps['num'])
            tricks.append(drtricks['num'])
            slams.append(drslams['num'])
            dnf.append(drdnf)
            if drstats[driver]['avgs'] >= 1:
                avgs.append(drstats[driver]['avgs'])
            if drstats[driver]['avgf'] >= 1:
                avgf.append(drstats[driver]['avgf'])
            tripkm.append(drstats[driver]['tripkm'])
            tripl.append(drtripl)
            triptime.append(drtriptime)
            lled.append(drlled)
            top3.append(drtop3)
            top5.append(drtop5)
            top10.append(drtop10)
            inpts.append(drinpts)

        drstatsbest['starts'] = max(starts)
        drstatsbest['wins'] = max(wins)
        drstatsbest['poles'] = max(poles)
        drstatsbest['flaps'] = max(flaps)
        drstatsbest['tricks'] = max(tricks) or 1
        drstatsbest['slams'] = max(slams) or 1
        drstatsbest['dnf'] = min(dnf)
        drstatsbest['avgs'] = min(avgs)
        drstatsbest['avgf'] = min(avgf)
        drstatsbest['tripkm'] = max(tripkm)
        drstatsbest['tripl'] = max(tripl)
        drstatsbest['triptime'] = max(triptime)
        drstatsbest['lled'] = max(lled)
        drstatsbest['top3'] = max(top3)
        drstatsbest['top5'] = max(top5)
        drstatsbest['top10'] = max(top10)
        drstatsbest['inpts'] = max(inpts)

        for veh in vehstats:
            if vehstats[veh]['dravgs']:
                vehstats[veh]['dravgs'] = sum(vehstats[veh]['dravgs']) / len(vehstats[veh]['dravgs'])
            if vehstats[veh]['dravgf']:
                vehstats[veh]['dravgf'] = sum(vehstats[veh]['dravgf']) / len(vehstats[veh]['dravgf'])

        hlcolor = '#e1f4ff'
        self.tables['ChampDrStats'] = []
        for dr in self.tables['DrChampCl0']:
            d = drstats[dr['name']]
            onerow = {}
            onerow['starts'] = d['starts']
            events_with_results = [1 for e in self.events if e]
            events_with_results_num = sum(events_with_results or []) or 1
            onerow['starts_percentage'] = int(round(d['starts']/events_with_results_num*100))
            onerow['bestst'] = d['bestst']
            onerow['bestf'] = d['bestf']
            #onerow['tricks'] = d['tricks']['num']
            #onerow['slams'] = d['slams']['num']
            onerow['dns'] = d['dns']
            onerow['stlist'] = d['stlist']
            onerow['finlist'] = d['finlist']
            #onerow['climbes'] = d['climbes']
            #onerow['penalty']=(0,'') #((len(d['penalty']) or ''), d['penalty'])
            onerow['name'] = la_utils.small_name(dr['name'])

            if d['tricks']['num'] == drstatsbest['tricks']:
                bg = hlcolor
            else:
                bg = ""
            onerow['tricks'] = ((d['tricks']['num'] or ''), bg, d['tricks']['num'])

            if d['slams']['num'] == drstatsbest['slams']:
                bg = hlcolor
            else:
                bg = ""
            onerow['slams'] = ((d['slams']['num'] or ''), bg, d['slams']['num'])

            if d['wins']['num'] == drstatsbest['wins']:
                bg = hlcolor
            else:
                bg = ""
            onerow['wins'] = ((d['wins']['num'] or ''), bg, d['wins']['num'])

            if d['poles']['num'] == drstatsbest['poles']:
                bg = hlcolor
            else:
                bg = ""
            onerow['poles'] = ((d['poles']['num'] or ''), bg, d['poles']['num'])

            if d['flaps']['num'] == drstatsbest['flaps']:
                bg = hlcolor
            else:
                bg = ""
            onerow['flaps'] = ((d['flaps']['num'] or ''), bg, d['flaps']['num'])

            if d['dnf'] == drstatsbest['dnf'] and d['starts'] == drstatsbest['starts']:
                bg = hlcolor
            else:
                bg = ""
            onerow['dnf'] = (d['dnf'], bg, d['dnf'])

            if d['avgs'] == drstatsbest['avgs'] and d['avgs'] >= 1:
                bg = hlcolor
            else:
                bg = ''
            onerow['avgs'] = ((str(round(d['avgs'],1)) if d['avgs'] else ''), bg, d['avgs'])

            if d['avgf'] == drstatsbest['avgf'] and d['avgf'] >= 1:
                bg = hlcolor
            else:
                bg = ''
            onerow['avgf'] = ((str(round(d['avgf'],1)) if d['avgf'] else ''), bg, d['avgf'])

            if d['tripkm'] == drstatsbest['tripkm']:
                bg = hlcolor
            else:
                bg = ''
            onerow['tripkm'] = ((str("%.3f" % d['tripkm']) if d['tripkm'] else ''), bg, d['tripkm'])

            if d['tripl'] == drstatsbest['tripl']:
                bg = hlcolor
            else:
                bg = ''
            onerow['tripl'] = (d['tripl'], bg, d['tripl'])

            if d['triptime'] == drstatsbest['triptime']:
                bg = hlcolor
            else:
                bg = ''
            onerow['triptime'] = ((str(datetime.timedelta(seconds=d['triptime']))[:-5] if d['triptime'] else ''), bg, d['triptime'])

            if d['lled'] == drstatsbest['lled']:
                bg = hlcolor
            else:
                bg = ''
            onerow['lled'] = ((d['lled'] or ''), bg, d['lled'])

            if d['top3'] == drstatsbest['top3']:
                bg = hlcolor
            else:
                bg = ''
            onerow['top3'] = ((d['top3'] or ''), bg, d['top3'])

            if d['top5'] == drstatsbest['top5']:
                bg = hlcolor
            else:
                bg = ''
            onerow['top5'] = ((d['top5'] or ''), bg, d['top5'])

            if d['top10'] == drstatsbest['top10']:
                bg = hlcolor
            else:
                bg = ''
            onerow['top10'] = ((d['top10'] or ''), bg, d['top10'])

            if d['inpts'] == drstatsbest['inpts']:
                bg = hlcolor
            else:
                bg = ''
            onerow['inpts'] = ((d['inpts'] or ''), bg, d['inpts'])

            self.tables['ChampDrStats'].append(onerow)

        if keep_data:
            if self.tables['DrChampCl0']:
                drstats[self.tables['DrChampCl0'][0]['name']]['leader'] = 1
            self.tables['drstats'] = drstats

        self.tables['ChampVehStats'] = []
        for veh in sorted(vehstats, key=lambda veh: vehstats[veh]['pts'], reverse=True):
            v = vehstats[veh]
            bg = ''
            onerow = {}
            onerow['name'] = (veh, bg)
            onerow['pts'] = (la_utils.float_no_zero(v['pts']), bg)
            onerow['wins'] = (str(v['drwins'])+"/"+str(v['drstarts']), bg)
            onerow['poles'] = (str(v['drpoles'])+"/"+str(v['drstarts']), bg)
            onerow['flaps'] = (str(v['drflaps'])+"/"+str(v['drstarts']), bg)
            onerow['dnf'] = (str(v['drdnf'])+"/"+str(v['drstarts']), bg)
            onerow['avgs'] = (str (round(v['dravgs'], 1)) if v['dravgs'] else '-', bg)
            onerow['avgf'] = (str (round(v['dravgf'], 1)) if v['dravgf'] else '-', bg)
            onerow['tripkm'] = (str (round(v['drtripkm']/1000, 3)), bg)
            onerow['tripl'] = (v['drtripl'], bg)
            onerow['triptime'] = (str(datetime.timedelta(seconds=v['drtriptime']))[:-5], bg)
            onerow['lled'] = (v['drlled'] or '', bg)
            onerow['top3'] = (v['drtop3'] or '', bg)
            onerow['top5'] = (v['drtop5'] or '', bg)
            onerow['top10'] = (v['drtop10'] or '', bg)
            onerow['inpts'] = (str(v['drinpts'])+"/"+str(v['drstarts']), bg)
            self.tables['ChampVehStats'].append(onerow)


def get_aggregate_stats(championships):
    stats = {}
    all_races_num = 0
    champ_names = []

    for row in championships:
        champ_names.append(row.name)
        #request.vars.cid = row.id

        champ = Championship(row)
        champ.calculate(keep_data=True)

        all_races_num += len(champ.events)
        for dr in champ.tables['drstats']:
            if not dr in stats:
                stats[dr] = collections.defaultdict(int)
                stats[dr]['stlist'] = []
                stats[dr]['finlist'] = []

            for key, value in champ.tables['drstats'][dr].items():
                if key in ('wins', 'poles', 'flaps', 'tricks', 'slams'):
                    stats[dr][key] += value['num']
                elif key in ('stlist', 'finlist'):
                    stats[dr][key].extend(value)
                else:
                    stats[dr][key] += value

    all_races_num = all_races_num or 1

    fake_pts_dict = collections.defaultdict(int)
    fake_pts_dict.update({1:10, 2:9, 3:8, 4:7, 5:6, 6:5, 7:4, 8:3, 9:2, 10:1})

    starts = [0]
    wins = [0]
    poles = [0]
    flaps = [0]
    tricks = [0]
    slams = [0]
    dnf = [1000]
    avgs = [1000]
    avgf = [1000]
    tripkm = [0]
    tripl = [0]
    triptime = [0]
    lled = [0]
    top3 = [0]
    top5 = [0]
    top10 = [0]
    inpts = [0]

    for dr in stats:
        stats[dr]['tripkm'] = round(stats[dr]['tripkm'], 1)

        if stats[dr]['stlist']:
            stats[dr]['avgs'] = round (float(sum(stats[dr]['stlist'])) / len(stats[dr]['stlist']), 1)
        else:
            stats[dr]['avgs'] = 0

        if stats[dr]['finlist']:
            stats[dr]['avgf'] = round (float(sum(stats[dr]['finlist'])) / len(stats[dr]['finlist']), 1)
            stats[dr]['fake_pts'] = sum([fake_pts_dict[p] for p in stats[dr]['finlist']])
        else:
            stats[dr]['avgf'] = 1000
            stats[dr]['fake_pts'] = 0

        stats[dr]['starts_percentage'] = round (stats[dr]['starts'] / float(all_races_num) * 100)

        starts.append(stats[dr]['starts'])
        wins.append(stats[dr]['wins'])
        poles.append(stats[dr]['poles'])
        flaps.append(stats[dr]['flaps'])
        dnf.append(stats[dr]['dnf'])
        tricks.append(stats[dr]['tricks'])
        slams.append(stats[dr]['slams'])
        avgs.append(stats[dr]['avgs'])
        avgf.append(stats[dr]['avgf'])
        tripkm.append(stats[dr]['tripkm'])
        tripl.append(stats[dr]['tripl'])
        triptime.append(stats[dr]['triptime'])
        lled.append(stats[dr]['lled'])
        top3.append(stats[dr]['top3'])
        top5.append(stats[dr]['top5'])
        top10.append(stats[dr]['top10'])
        inpts.append(stats[dr]['inpts'])

    hl = {}
    hl_color = '#e1f4ff'
    drstatsbest = {}
    drstatsbest['starts'] = max(starts)
    drstatsbest['wins'] = max(wins)
    drstatsbest['poles'] = max(poles)
    drstatsbest['flaps'] = max(flaps)
    drstatsbest['tricks'] = max(tricks) or 1
    drstatsbest['slams'] = max(slams) or 1
    drstatsbest['dnf'] = min(dnf)
    drstatsbest['avgs'] = min(avgs)
    drstatsbest['avgf'] = min(avgf)
    drstatsbest['tripkm'] = max(tripkm)
    drstatsbest['tripl'] = max(tripl)
    drstatsbest['triptime'] = max(triptime)
    drstatsbest['lled'] = max(lled)
    drstatsbest['top3'] = max(top3)
    drstatsbest['top5'] = max(top5)
    drstatsbest['top10'] = max(top10)
    drstatsbest['inpts'] = max(inpts)

    for dr in stats:
        hl[dr] = collections.defaultdict(str)
        if stats[dr]['starts'] == drstatsbest['starts']:
            hl[dr]['starts'] = hl_color
        if stats[dr]['wins'] == drstatsbest['wins']:
            hl[dr]['wins'] = hl_color
        if stats[dr]['poles'] == drstatsbest['poles']:
            hl[dr]['poles'] = hl_color
        if stats[dr]['flaps'] == drstatsbest['flaps']:
            hl[dr]['flaps'] = hl_color
        if stats[dr]['dnf'] == drstatsbest['dnf']:
            hl[dr]['dnf'] = hl_color
        if stats[dr]['tricks'] == drstatsbest['tricks']:
            hl[dr]['tricks'] = hl_color
        if stats[dr]['slams'] == drstatsbest['slams']:
            hl[dr]['slams'] = hl_color
        if stats[dr]['avgs'] == drstatsbest['avgs']:
            hl[dr]['avgs'] = hl_color
        if stats[dr]['avgf'] == drstatsbest['avgf']:
            hl[dr]['avgf'] = hl_color
        if stats[dr]['tripkm'] == drstatsbest['tripkm']:
            hl[dr]['tripkm'] = hl_color
        if stats[dr]['tripl'] == drstatsbest['tripl']:
            hl[dr]['tripl'] = hl_color
        if stats[dr]['triptime'] == drstatsbest['triptime']:
            hl[dr]['triptime'] = hl_color
        if stats[dr]['lled'] == drstatsbest['lled']:
            hl[dr]['lled'] = hl_color
        if stats[dr]['top3'] == drstatsbest['top3']:
            hl[dr]['top3'] = hl_color
        if stats[dr]['top3'] == drstatsbest['top3']:
            hl[dr]['top3'] = hl_color
        if stats[dr]['top5'] == drstatsbest['top5']:
            hl[dr]['top5'] = hl_color
        if stats[dr]['top10'] == drstatsbest['top10']:
            hl[dr]['top10'] = hl_color
        if stats[dr]['inpts'] == drstatsbest['inpts']:
            hl[dr]['inpts'] = hl_color

        stats[dr]['triptime'] = la_utils.strfdelta(datetime.timedelta(seconds=stats[dr]['triptime']), "{D} {H}:{M}")

    return stats, champ_names, hl
